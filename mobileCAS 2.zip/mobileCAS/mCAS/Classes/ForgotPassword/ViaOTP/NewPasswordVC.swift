//
//  NewPasswordVC.swift
//  mCollect
//
//  Created by Mac on 24/06/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import UIKit

class NewPasswordVC: UIViewController {
    
    @IBOutlet weak var staticLavel1: UILabel!
    @IBOutlet weak var staticLavel2: UILabel!
    
    @IBOutlet weak var nwPasswordView: CustomTextFieldView!
    @IBOutlet weak var confirmPasswordView: CustomTextFieldView!
    
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    var userID: String?
    var resetToken: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        setProperties()
        validateFields()
    }
    
    private func setProperties() {
        
        staticLavel1.font = CustomFont.shared().GETFONT_MEDIUM(24)
        staticLavel2.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        nwPasswordView.setProperties(placeHolder: "New Password", type: .Password, delegate: self)
        confirmPasswordView.setProperties(placeHolder: "Confirm New Password", type: .Password, delegate: self)
        
        buttonView.setProperties(nextBtnTitle: "Save", delegate: self)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches ,with: event)
        self.view.endEditing(true)
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func resetPasswordWith(securityToken : String, password : String) {
        
        let passwordOne = Cipher.sha256(userID! + password + securityToken)
        let checkSumSHA256 = Cipher.sha256(userID! + resetToken! + passwordOne + securityToken)
        
        let param : [String:String] = ["userId"       : userID!,
                                       "passwordOne"  : passwordOne,
                                       "resetToken"   : resetToken!,
                                       "userDetails"  : checkSumSHA256]
        
        Webservices.shared().POST(urlString: ServiceUrl.RESET_PASSWORD_URL, paramaters: param, success: { (header ,responseObj) in
            
            MRProgressOverlayView.dismissAllOverlays(for: self.view, animated: true)
            self.performSegue(withIdentifier: "NewPasswordVC", sender: nil)
            
        }, failure: { (error) in
            MRProgressOverlayView.dismissAllOverlays(for: self.view, animated: true)
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            MRProgressOverlayView.dismissAllOverlays(for: self.view, animated: true)
            
        })
    }
    
    func createTokenFromServerWith(password : String) {
        
        MRProgressOverlayView.showOverlayAdded(to: self.view, animated: true)
        
        Webservices.shared().getTokenFromServer(withSession: false) { (token) in
            if let token = token {
                self.resetPasswordWith(securityToken: token, password: password)
            }
            else {
                MRProgressOverlayView.dismissAllOverlays(for: self.view, animated: true)
            }
        }
    }
}

extension NewPasswordVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        if (nwPasswordView.getFieldValue().isEmpty || confirmPasswordView.getFieldValue().isEmpty || nwPasswordView.getFieldValue() != confirmPasswordView.getFieldValue()) {
            isEnabled = false
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
}

extension NewPasswordVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        
        let nwPassword = nwPasswordView.getFieldValue()
        let confirmPassword = confirmPasswordView.getFieldValue()
        
        if nwPassword == confirmPassword {
            createTokenFromServerWith(password: nwPassword)
        }
        else {
            CommonAlert.shared().showAlert(message: NSLocalizedString("New password and confirm new password does not match", comment: ""))
        }
    }
}
