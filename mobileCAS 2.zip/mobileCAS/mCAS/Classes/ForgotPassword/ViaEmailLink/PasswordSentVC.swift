//
//  PasswordSentVC.swift
//  mCAS
//
//  Created by Mac on 18/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class PasswordSentVC: UIViewController {
    
    @IBOutlet weak var staticLavel1: UILabel!
    @IBOutlet weak var staticLavel2: UILabel!
    @IBOutlet weak var staticLavel3: UILabel!
    @IBOutlet weak var iconView: UIImageView!
    @IBOutlet weak var buttonView: NextBackButtonView!

    var fromChangePassword: Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        
        // Do any additional setup after loading the view.
        setProperties()
        
        if fromChangePassword {
            staticLavel1.text = "Password Changed Successfully!"
            staticLavel2.text = "You have been logged out of the application.\nPlease login again."
            staticLavel3.text = ""
            
            iconView.image = UIImage(named: "tick_success")
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.isHidden = true
        }
    }
    
    private func setProperties() {
        staticLavel1.font = CustomFont.shared().GETFONT_MEDIUM(24)
        staticLavel2.font = CustomFont.shared().GETFONT_REGULAR(16)
        staticLavel3.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        buttonView.setProperties(nextBtnTitle: "Login", delegate: self)
    }
}

extension PasswordSentVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        AppDelegate.instance.presentLoginViewController()
    }
    
}
