//
//  LeadsListVC.swift
//  mCAS
//
//  Created by Mac on 13/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


class LeadsListVC: UIViewController {
    
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var leadsShownForLabel: UILabel!
    @IBOutlet weak var daysLeftButton: UIButton!
    @IBOutlet weak var noLeadCapturedLabel: UILabel!
    @IBOutlet weak var noLeadCapturedView: UIView!
    @IBOutlet weak var leadTopFilterView: UIView!
    @IBOutlet weak var leadTopFilterViewHeight: NSLayoutConstraint!
    
    private enum DetailOptions: String {
        case viewDetail = "View Details"
    }
    
    private var dateRangeView: DateRangeFilterView!
    private var refreshControl: UIRefreshControl!
    private var daysListArray: [DAYFILTER] = [.SevenDay, .FifteenDay, .ThirtyDay, .Range]
    private var cellOptionArray: [DetailOptions] = [.viewDetail]
    
    private var listModelArray = [LeadModelClasses.LeadModel]()
    private var filteredModelArray = [LeadModelClasses.LeadModel]()
    
    private var selectedDay: DAYFILTER = .SevenDay
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noLeadCapturedLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        leadTopFilterView.layer.masksToBounds = true
        
        leadsShownForLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        
        tableView.register(UINib.init(nibName: "CasesCell", bundle: Bundle.main), forCellReuseIdentifier: "CasesCell")
        tableView.tableFooterView = UIView()
        
        refreshControl = UIRefreshControl()
        refreshControl.tintColor = .darkGray
        refreshControl.addTarget(self, action: #selector(refreshList), for: .valueChanged)
        tableView.addSubview(refreshControl)
        
        setButtonTitleAndIcon(text: selectedDay.rawValue, up: false)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "View Leads", showBack: true, delegate: self)
            headerView.showHideSearchMikeFilterOption(showSearch: true)
            searchOnOff(isSearching: false)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideSearchMikeFilterOption()
        }
    }
    
    private func setButtonTitleAndIcon(text: String, up: Bool) {
        if up {
            daysLeftButton.setButtonTextAndRightIcon(title: text, image: "list_arrow_up")
        }
        else {
            daysLeftButton.setButtonTextAndRightIcon(title: text, image: "list_arrow_down")
            refreshList()
        }
    }
    
    @objc func refreshList() {
        listModelArray.removeAll()
        filteredModelArray.removeAll()
        
        if ReachabilityManager.isReachable() {
            fetchCases()
        }
        else {
            fetchOfflineRecords()
        }
    }
    
    private func fetchOfflineRecords() {
        
        if let userData = AppDelegate.instance.currentLoggedInUser, let leadList = userData.getOfflineLeads(), !leadList.isEmpty {
            
            let dates = CommonUtils.shared().fetchFromDateAndToDateForDayFilter(from: self.dateRangeView?.dateFromView.getFieldValue() ?? "", to: self.dateRangeView?.dateToView.getFieldValue() ?? "", selectedDay: selectedDay)
            
            for lead in leadList {
                if let data = lead.leadData as? Data {
                    CommonUtils.shared().dataToModel(data: data, type: LeadModelClasses.LeadModel.self) { model in
                        if let createdDate = model.createdDate, createdDate.isBetweenDate(startDate: dates.0, endDate: dates.1) {
                            self.listModelArray.append(model)
                        }
                    }
                }
            }
        }
        
        self.listModelArray.sort{ ( $0.primaryApplicant!.getFullName().lowercased() < $1.primaryApplicant!.getFullName().lowercased() ) }
        
        self.filteredModelArray = self.listModelArray
        setLeadListData()
    }
    
    private func fetchCases() {
        
        let dates = CommonUtils.shared().fetchFromDateAndToDateForDayFilter(from: self.dateRangeView?.dateFromView.getFieldValue() ?? "", to: self.dateRangeView?.dateToView.getFieldValue() ?? "", selectedDay: selectedDay)

        let param = ["fromDate" : dates.0,
                     "toDate"   : dates.1]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_LEAD_LIST_URL, paramaters: param, autoHandleLoader: true, allowOfflineAlert:false, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : AnyObject]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: LeadModelClasses.LeadRecords.self) { list in
                    
                    if let records = list.leads {
                        self.listModelArray.append(contentsOf: records)
                    }
                }
            }
            
            self.fetchOfflineRecords()
            
        }, failure: { (error) in
            
            self.fetchOfflineRecords()
            
        }, noNetwork: { (error) in
            
            self.fetchOfflineRecords()
        })
    }
    
    private func setLeadListData(isSearching: Bool = false) {
        self.refreshControl.endRefreshing()
        
        leadTopFilterViewHeight.constant = isSearching ? 0 : 45
        tableView.isHidden = filteredModelArray.isEmpty
        noLeadCapturedView.isHidden = !tableView.isHidden
        self.tableView.reloadData()
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        
        let st = UIStoryboard.init(name: Storyboard.LEAD, bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "CustomerTypeVC") as! CustomerTypeVC
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    @IBAction func daysLeftButtonClicked(_ sender: Any) {
        
        let listArray = daysListArray.map({ $0.rawValue })
        
        let obj = SimpleListVC.init(nibName: "SimpleListVC", bundle: nil)
        obj.setData(listArray: listArray, selectedValue: self.selectedDay.rawValue, delegate: self)
        
        if let popoverPresentationController = obj.popoverPresentationController {
            self.view.endEditing(true)
            popoverPresentationController.permittedArrowDirections = .up
            popoverPresentationController.sourceView = self.daysLeftButton
            popoverPresentationController.sourceRect = self.daysLeftButton.bounds
            popoverPresentationController.delegate = self
            present(obj, animated: true, completion: nil)
        }
    }
    
}

extension LeadsListVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CasesCell") as! CasesCell
        
        if !self.filteredModelArray.isEmpty
        {
            let model = filteredModelArray[indexPath.row]
            let customerType = model.primaryApplicant?.applicantType?.code
            let productTypeCode = model.loanDetail?.productType?.code
            
            cell.label1.text = model.primaryApplicant?.getFullName()
            cell.label2.text = "\(model.leadReferenceId ?? "") \(Constants.SEPERATOR) \(model.primaryApplicant!.mobileNumber!)"
            
            if let code = productTypeCode, code != ConstantCodes.PRODUCT_TYPE_CC, code != ConstantCodes.PRODUCT_TYPE_KCC, let loanAmount = model.loanDetail?.loanAmount {
                cell.label3.text = String(loanAmount).formatCurrency
            }
            else {
                cell.label3.text = ""
            }
            
            cell.loanTypeLabel.text = model.loanDetail?.productType?.name
            let optionArray = cellOptionArray.map({ $0.rawValue })
            let isOffline = model.isOffline ?? false
            
            cell.setProperties(showSyncButton: isOffline, cellIndex: indexPath.row, customerType: customerType, showOption: true, productTypeCode: productTypeCode, showOfflineFlag: isOffline, delegate: self, optionArray: optionArray)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        self.navigateToDetailScreen(model: filteredModelArray[indexPath.row])
    }
    
    func navigateToDetailScreen(model: LeadModelClasses.LeadModel) {
        let storyboard = UIStoryboard.init(name: Storyboard.LEAD, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "LeadDetailVC") as? LeadDetailVC {
            vc.model = model
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension LeadsListVC: CaseCellDelegate {
    
    func syncButtonAction(cellIndex: Int) {
        let model = filteredModelArray[cellIndex]
        
        LeadWS.shared().saveLead(model: model, deleteOfflineRecord: true, completion: { (leadID) in
            
            CommonAlert.shared().showAlert(message: "Lead synced successfully. Lead id is \(leadID)", okAction: { _ in
                self.refreshList()
            })
        })
    }
    
    func selectedIndex(index: Int, cellIndex: Int) {
        let item = self.cellOptionArray[index]
        if item == .viewDetail {
            self.navigateToDetailScreen(model: filteredModelArray[cellIndex])
        }
    }
}

extension LeadsListVC: HeaderDelegate {
    
    func searchOnOff(isSearching: Bool) {
        if isSearching {
            refreshControl.removeFromSuperview()
        }
        else {
            handleSearch(text: "")
            tableView.addSubview(refreshControl)
        }
        setLeadListData(isSearching: isSearching)
    }
    
    func handleSearch(text: String) {
        
        if !text.isEmpty {
            let searchText = text.lowercased()
            
            filteredModelArray = listModelArray.filter {
                return (($0.primaryApplicant!.getFullName().lowercased().contains(searchText)) || (($0.leadReferenceId!.lowercased().contains(searchText)) || ($0.primaryApplicant!.mobileNumber!.lowercased().contains(searchText))))
            }
        }
        else {
            filteredModelArray = listModelArray
        }
        tableView.reloadData()
    }    
}

extension LeadsListVC: SimpleListVCDelegate {
    
    func selectedListOption(index: Int) {
        
        DispatchQueue.main.async {
            
            self.dismiss(animated: true) {
                let item = self.daysListArray[index]
                
                if item == .Range {
                    if self.dateRangeView == nil {
                        self.dateRangeView = .fromNib()
                        self.dateRangeView.setProperties(width: self.view.frame.size.width, height: self.view.frame.size.height, delegate: self)
                        self.view.addSubview(self.dateRangeView)
                    }
                    
                    self.dateRangeView.alpha = 1
                }
                else {
                    self.selectedDay = item
                    self.setButtonTitleAndIcon(text: self.selectedDay.rawValue, up: false)
                }
            }
        }
    }
}

extension LeadsListVC: DateRangeViewDelegate {
    
    func dateRangeFilterCall(fromDate: String, toDate: String) {
        self.selectedDay = .Range
        self.setButtonTitleAndIcon(text: "\(fromDate) - \(toDate)", up: false)
    }
}

extension LeadsListVC: UIPopoverPresentationControllerDelegate {
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
    func popoverPresentationControllerDidDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) {
        popoverPresentationController.delegate = nil
    }
    
    func popoverPresentationControllerShouldDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) -> Bool {
        return true
    }
}
