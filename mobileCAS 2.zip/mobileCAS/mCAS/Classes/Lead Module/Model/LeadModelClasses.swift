//
//  LeadModelClasses.swift
//  mCAS
//
//  Created by Mac on 20/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

class LeadModelClasses {
    
    struct LeadRecords: Codable {
        let pageInfo: PageInfo?
        var leads: [LeadModel]?
    }
    
    struct LeadModel: Codable {
        var leadReferenceId: String?
        var createdDate: String?
        var city: City?
        var primaryApplicant: PrimaryApplicant?
        var loanDetail: LoanDetail?
        var status: Int?
        var isOffline: Bool?
        
        struct City: Codable {
            var code: String?
            var name: String?
        }
        
        struct PrimaryApplicant: Codable {
            var applicantType: ApplicantType?
            var firstName: String?
            var lastName: String?
            var companyName: String?
            var emailAddress: String?
            var isdCode: ISDCode?
            var designation: String?
            var dateOfBirth: String?
            var mobileNumber: String?
            
            struct ApplicantType: Codable {
                var code: String?
                var name: String?
            }
            
            struct ISDCode: Codable {
                var code: String?
                var name: String?
            }
            
            func getPersonName() -> String {
                var name = ""
                if let fName = self.firstName {
                    name = fName
                }
                if let lName = self.lastName {
                    name = "\(name) \(lName)"
                }
                return name.capitalized
            }

            func getFullName() -> String {

                if self.applicantType?.code == Constants.CUSTOMER_TYPE_CORP {
                    if let instName = self.companyName {
                        return instName.capitalized
                    }
                }
                else {
                    return getPersonName()
                }
                
                return ""
            }
        }
        
        struct LoanDetail: Codable {
            var loanAmount: Double?
            var productType: ProductType?
            var product: Product?
            
            struct ProductType: Codable {
                var code: String?
                var name: String?
            }
            
            struct Product: Codable {
                var code: String?
                var name: String?
            }
        }
    }
    
    struct LoanAmountModel {
        var amount: String
        var amountInShort: String
    }
    
}
