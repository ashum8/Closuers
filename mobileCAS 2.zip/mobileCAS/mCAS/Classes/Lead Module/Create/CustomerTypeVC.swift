//
//  CustomerTypeVC.swift
//  mCAS
//
//  Created by iss on 22/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class CustomerTypeVC: UIViewController {
    
    @IBOutlet weak var indvButton: UIButton!
    @IBOutlet weak var corpButton: UIButton!
    @IBOutlet weak var lblOR: UILabel!
    @IBOutlet weak var dividerView: UIView!
    @IBOutlet weak var indvSelectionImageView: UIImageView!
    @IBOutlet weak var corpSelectionImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        indvButton.layer.borderColor = UIColor.lightGray.cgColor
        indvButton.layer.borderWidth = 0.5
        indvButton.setCornerRadius()
        indvButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(17)
        indvButton.setTitleColor(.darkGray, for: .normal)
        indvButton.setTitleColor(Color.BLUE, for: .selected)
        indvButton.setButtonShadow()
        indvButton.setAlignmentOfButton(isTab: false)
        
        corpButton.layer.borderColor = UIColor.lightGray.cgColor
        corpButton.layer.borderWidth = 0.5
        corpButton.setCornerRadius()
        corpButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(17)
        corpButton.setTitleColor(.darkGray, for: .normal)
        corpButton.setTitleColor(Color.BLUE, for: .selected)
        corpButton.setButtonShadow()
        corpButton.setAlignmentOfButton(isTab: false)
        
        dividerView.backgroundColor = Color.LIGHTER_GRAY
        
        lblOR.backgroundColor = Color.LIGHTER_GRAY
        lblOR.layer.cornerRadius = 12
        lblOR.layer.masksToBounds = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            let navArray = AppDelegate.instance.applicationNavController.viewControllers
            let lastVC = navArray[navArray.count-2]
            headerView.showHideStepHeader(isHide: false, title: "Customer Type", step: "(1/5)", landingPage: lastVC)
            bottomView.isHidden = true
        }
    }
    
    @IBAction func customerButtonAction(_ sender: UIButton) {
        if !indvButton.isSelected {
            indvButton.isSelected = true
            corpButton.isSelected = false
            setSelectedButtonProperties()
        }
        
        let storyboard = UIStoryboard.init(name: Storyboard.LEAD, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "CreateLeadVC") as? CreateLeadVC {
            vc.customerType = .Individual
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func corporateButtonAction(_ sender: UIButton ) {
        if !corpButton.isSelected {
            corpButton.isSelected = true
            indvButton.isSelected = false
            setSelectedButtonProperties()
        }
        
        let storyboard = UIStoryboard.init(name: Storyboard.LEAD, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "CreateLeadVC") as? CreateLeadVC {
            vc.customerType = .Corporate
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    private func setSelectedButtonProperties() {
        indvButton.layer.borderColor = indvButton.isSelected ? Color.BLUE.cgColor : UIColor.lightGray.cgColor
        indvButton.layer.borderWidth = indvButton.isSelected ? 1.0 : 0.5
        
        corpButton.layer.borderColor = corpButton.isSelected ? Color.BLUE.cgColor : UIColor.lightGray.cgColor
        corpButton.layer.borderWidth = corpButton.isSelected ? 1.0 : 0.5
        
        indvSelectionImageView.isHidden = corpButton.isSelected
        corpSelectionImageView.isHidden = indvButton.isSelected
    }
}
