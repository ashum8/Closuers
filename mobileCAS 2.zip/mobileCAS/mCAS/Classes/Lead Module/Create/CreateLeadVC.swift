//
//  CreateLeadVC.swift
//  mCAS
//
//  Created by iMac on 11/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


class CreateLeadVC: UIViewController {
    
    @IBOutlet weak var firstNameView: CustomTextFieldView!
    @IBOutlet weak var companyNameView: CustomTextFieldView!
    @IBOutlet weak var companyNameViewHeight: NSLayoutConstraint!
    @IBOutlet weak var contactPersonLabel: EdgeInsetLabel!
    @IBOutlet weak var contactPersonHeight: NSLayoutConstraint!
    @IBOutlet weak var designationView: CustomTextFieldView!
    @IBOutlet weak var designationViewHeight: NSLayoutConstraint!
    @IBOutlet weak var phoneNumberView: CustomTextFieldView!
    @IBOutlet weak var emailView: CustomTextFieldView!
    @IBOutlet weak var lastNameView: CustomTextFieldView!
    
    @IBOutlet weak var countryCodeView: LOVFieldView!
    @IBOutlet weak var cityView: LOVFieldView!
    @IBOutlet weak var dateOfBirthView: CustomTextFieldView!
    @IBOutlet weak var dateOfBirthViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private let TAG_COUNTRY_CODE    = 1001
    private let TAG_CITY            = 1002
    private let TAG_NAME            = 1003
    private let TAG_COMPANY_NAME    = 1004
    private let TAG_DESIGNATION     = 1005
    
    
    enum CustomerType {
        case Individual
        case Corporate
    }
    
    private var model = LeadModelClasses.LeadModel()
    
    var selectedLOVDic: [String: DropDown] = [:]
    var customerType: CustomerType?
    var dataToSave: [String : String]!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    func setupView() {
        
        firstNameView.setProperties(placeHolder: "First Name", delegate: self, tag: TAG_NAME)
        lastNameView.setProperties(placeHolder: "Last Name", delegate: self, tag: TAG_NAME)
        emailView.setProperties(placeHolder: "Email Id", type: .Email, delegate: self)
        phoneNumberView.setProperties(placeHolder: "Phone Number", type: .Mobile, delegate: self)
        dateOfBirthView.setProperties(placeHolder: "Date of Birth", type: .DOB, delegate: self)
        
        buttonView.setProperties(showBack: true, nextBtnTitle: "Continue", delegate: self)
        
        countryCodeView.setLOVProperties(masterName: Entity.PHONE_COUNTRYCODE, title: "Country Code", tag: TAG_COUNTRY_CODE, delegate: self)
        countryCodeView.autoFillLOVBy(key: Constants.DEFAULT_COUNTRY_CODE)
        
        cityView.setLOVProperties(masterName: Entity.CITY, title: "City", tag: TAG_CITY, delegate: self)
        
        if customerType == .Corporate {
            contactPersonLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
            
            companyNameViewHeight.constant = 65
            contactPersonHeight.constant = 30
            dateOfBirthViewHeight.constant = 0
            designationViewHeight.constant = 65
            
            companyNameView.setProperties(placeHolder: "Company Name", delegate: self, tag: TAG_COMPANY_NAME)
            designationView.setProperties(placeHolder: "Designation", delegate: self, tag: TAG_DESIGNATION)
        }
        
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader(isHide: false, title: "Customer Details", step: "(2/5)")
        }
    }
}

extension CreateLeadVC: ProductTypeVCDelegate {
    
    func selected(productType: LoanType, currentStep: Int, totalStep: Int) {
        model.loanDetail?.productType?.code = productType.code
        model.loanDetail?.productType?.name = productType.name
        
        var dropDownList: [DropDown] = []
        
        //fetch the dropdownList according to master name
        CoreDataOperations.shared().fetchRecordsForMaster(masterName: Entity.PRODUCT, parentKey: productType.code) { (records) in
            
            if let records = records {
                dropDownList.append(contentsOf: records)
            }
        }
        
        let storyboard = UIStoryboard.init(name: Storyboard.LOV_LIST, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "LOVListVC") as? LOVListVC {
            vc.setData(lovType: .Other, totalStep: totalStep, currentStep: currentStep, dropDownList: dropDownList, delegate: self, title: "Product", backButtonTitle: "Back", showSearch: false)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension CreateLeadVC: LOVListDelegate {
    
    func selectedLOV(selectedObj: DropDown) {
        model.loanDetail?.product?.code = selectedObj.code
        model.loanDetail?.product?.name = selectedObj.name
        
        let storyboard = UIStoryboard.init(name: Storyboard.LEAD, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "LoanAmountVC") as? LoanAmountVC {
            if customerType == .Individual {
                vc.notAllowedProductTypes = [ConstantCodes.PRODUCT_TYPE_CC, ConstantCodes.PRODUCT_TYPE_KCC]
            }
            vc.model = self.model
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension CreateLeadVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        validateFields()
    }
}

extension CreateLeadVC: CustomTFViewDelegate {
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        if tag == TAG_NAME {
            return text.isAlphabetic && text.count <= 40
        }
        else if tag == TAG_COMPANY_NAME {
            return text.isAlphanumericAndSpace && text.count <= 100
        }
        else if tag == TAG_DESIGNATION {
            return text.isAlphanumericAndSpace && text.count <= 40
        }
        
        return true
    }
    
    
    func validateFields() {
        
        var isEnabled = true
        let email = emailView.getFieldValue()
        let phone = phoneNumberView.getFieldValue()
        
        if (firstNameView.getFieldValue().isEmpty || lastNameView.getFieldValue().isEmpty || !phone.isValidPhone || !email.isValidEmail || selectedLOVDic["\(TAG_COUNTRY_CODE)"] == nil || selectedLOVDic["\(TAG_CITY)"] == nil) {
            
            isEnabled = false
        }
        
        if customerType == .Individual {
            if (dateOfBirthView.getFieldValue().isEmpty) {
                isEnabled = false
            }
        }
        else {
            if (companyNameView.getFieldValue().isEmpty || designationView.getFieldValue().isEmpty) {
                isEnabled = false
            }
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
}

extension CreateLeadVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        
        model.leadReferenceId = "TEMP"+Date().timeStamp()
        model.createdDate = Date().getFormatedDateString(outputFormat: Constants.DATE_FORMAT_VIEW)
        model.primaryApplicant = LeadModelClasses.LeadModel.PrimaryApplicant(applicantType: LeadModelClasses.LeadModel.PrimaryApplicant.ApplicantType())
        model.loanDetail = LeadModelClasses.LeadModel.LoanDetail(productType: LeadModelClasses.LeadModel.LoanDetail.ProductType(), product: LeadModelClasses.LeadModel.LoanDetail.Product())
        
        model.primaryApplicant?.firstName = firstNameView.getFieldValue()
        model.primaryApplicant?.lastName = lastNameView.getFieldValue()
        model.primaryApplicant?.mobileNumber = phoneNumberView.getFieldValue()
        model.primaryApplicant?.emailAddress = emailView.getFieldValue()
        model.primaryApplicant?.designation = designationView.getFieldValue()
        model.primaryApplicant?.companyName = companyNameView.getFieldValue()
        model.primaryApplicant?.dateOfBirth = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: dateOfBirthView.getFieldValue())
        
        if customerType == .Individual  { model.primaryApplicant?.applicantType?.code = Constants.CUSTOMER_TYPE_INDV }
        else                            { model.primaryApplicant?.applicantType?.code = Constants.CUSTOMER_TYPE_CORP }
        
        if let cityLOV = selectedLOVDic["\(TAG_CITY)"] {
            model.city = LeadModelClasses.LeadModel.City()
            model.city?.code = cityLOV.code
            model.city?.name = cityLOV.name
        }
        
        if let countryCodeLOV = selectedLOVDic["\(TAG_COUNTRY_CODE)"] {
            model.primaryApplicant?.isdCode = LeadModelClasses.LeadModel.PrimaryApplicant.ISDCode()
            model.primaryApplicant?.isdCode?.code = countryCodeLOV.code
            model.primaryApplicant?.isdCode?.name = countryCodeLOV.name
        }
        
        let storyboard = UIStoryboard.init(name: Storyboard.LEAD, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "ProductTypeVC") as? ProductTypeVC {
            
            var notAllowedProducts: [String] = []
            
            if customerType == .Corporate {
                notAllowedProducts = [ConstantCodes.PRODUCT_TYPE_CC, ConstantCodes.PRODUCT_TYPE_KCC]
            }
            
            vc.setData(notAllowedProductList: notAllowedProducts, delegate: self, currentStep: 3, totalStep: 5)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
