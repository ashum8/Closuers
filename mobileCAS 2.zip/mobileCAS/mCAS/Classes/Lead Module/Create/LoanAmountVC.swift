//
//  LoanAmountVC.swift
//  mCAS
//
//  Created by iMac on 13/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit
import CoreData

class LoanAmountVC: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    @IBOutlet weak var loanAmtView: CustomTextFieldView!
    
    var model: LeadModelClasses.LeadModel!
    var loanAmountArray: [LeadModelClasses.LoanAmountModel] = []
    var notAllowedProductTypes: [String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        buttonView.setProperties(showBack: true, nextBtnTitle: "Save Lead", delegate: self)
        
        if !notAllowedProductTypes.isEmpty, let code = model.loanDetail?.productType?.code, notAllowedProductTypes.contains(code) {
            loanAmtView.setProperties(placeHolder: "Requested Loan Amount (Not Required)", type: .Amount, delegate: self, enabled: false)
        }
        else {
            loanAmtView.setProperties(placeHolder: "Requested Loan Amount", type: .Amount, delegate: self)
            
            setUpAmountData()
            validateFields()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader(isHide: false, title: "Loan Amount", step: "(5/5)")
        }
    }
    
    private func setUpAmountData() {
        for i in stride(from: 5, to: 55, by: +5) {
            let obj = LeadModelClasses.LoanAmountModel(amount: "\(i * 100000)", amountInShort: "\(Constants.CURRENCY_SYMBOL) \(i) L")
            loanAmountArray.append(obj)
        }
    }
    
    func showAlertWithNavigateBack(message: String) {
        CommonAlert.shared().showAlert(message: message, okAction: { _ in
            
            //Navigate to Dashboard and than to lead list screen
            if let headerView = AppDelegate.instance.headerView {
                headerView.stepsHV.navigateToFlow()
                AppDelegate.instance.tabsButtonAction(tabID: UserRoles.VIEW_LEAD)
            }
        })
    }
    
}

extension LoanAmountVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return loanAmountArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LoanAmountCollectionCell", for: indexPath) as! LoanAmountCollectionCell
        cell.setData(obj: loanAmountArray[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 65, height: 35)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        loanAmtView.setFieldValue(text: loanAmountArray[indexPath.row].amount)
        validateFields()
    }
}

extension LoanAmountVC: CustomTFViewDelegate {
    
    func validateFields() {
        let isEnabled = !loanAmtView.getFieldValue().isEmpty
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
}

extension LoanAmountVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        
        model.loanDetail?.loanAmount = Double(loanAmtView.getFieldValue())
        
        if ReachabilityManager.isReachable() {
            LeadWS.shared().saveLead(model: model, completion: { (leadID) in
                self.showAlertWithNavigateBack(message: "Lead created successfully. Lead id is \(leadID)")
            })
        }
        else {
            model.isOffline = true
            
            CommonUtils.shared().modelToData(model) { data in
                
                if let userData = AppDelegate.instance.currentLoggedInUser {
                    let context = AppDelegate.instance.getContext()
                    
                    let entityName = String(describing: CDLeadSave.self)
                    let entity = NSEntityDescription.entity(forEntityName: entityName, in: context)
                    let leadObject = NSManagedObject(entity: entity!, insertInto: context) as! CDLeadSave
                    leadObject.leadData = data as AnyObject
                    leadObject.tempLeadID = model.leadReferenceId!
                    leadObject.loginUser = userData
                    
                    AppDelegate.instance.saveContext()
                }
                
                self.showAlertWithNavigateBack(message: "Lead saved successfully in offline")
            }
        }
    }
    
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
