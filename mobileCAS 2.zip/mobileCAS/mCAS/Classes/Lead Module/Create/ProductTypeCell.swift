//
//  ProductTypeCell.swift
//  mCAS
//
//  Created by iMac on 12/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class ProductTypeCell: UICollectionViewCell {
    
    @IBOutlet weak var productTypeImageView: UIImageView!
    @IBOutlet weak var productTypeLabel: UILabel!
    @IBOutlet weak var selectedImageView: UIImageView!
    
    func setData(obj: LoanType) {
        
        productTypeLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        productTypeLabel.textColor = obj.isSelectedFlag ?  Color.BLUE : .gray
        
        productTypeLabel.lineBreakMode = .byWordWrapping
        productTypeLabel.numberOfLines = 2
        productTypeLabel.text = obj.name
        productTypeImageView.image = obj.isSelectedFlag ? UIImage(named: obj.activeIcon) : UIImage(named: obj.normalIcon)
        
        selectedImageView.isHidden = !obj.isSelectedFlag
        
        self.layer.borderWidth = obj.isSelectedFlag ? 1 : 0
        self.layer.borderColor = obj.isSelectedFlag ? Color.BLUE.cgColor : UIColor.clear.cgColor
    }
}
