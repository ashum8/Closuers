//
//  LoanAmountCollectionCell.swift
//  mCAS
//
//  Created by iMac on 13/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class LoanAmountCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var loanAmountLabel: UILabel!
    
    func setData(obj: LeadModelClasses.LoanAmountModel) {
        
        loanAmountLabel.layer.borderWidth = 1
        loanAmountLabel.layer.borderColor = UIColor.gray.cgColor
        loanAmountLabel.layer.cornerRadius = 15
        loanAmountLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        loanAmountLabel.text = obj.amountInShort
    }
}
