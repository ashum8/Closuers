//
//  LoanApplicationSearchVC.swift
//  mCAS
//
//  Created by iMac on 12/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class LoanApplicationSearchVC: UIViewController {
    
    @IBOutlet weak var mobileNumberView: CustomTextFieldView!
    @IBOutlet weak var identificationTypeLOV: LOVFieldView!
    @IBOutlet weak var identificationNumberView: CustomTextFieldView!
    @IBOutlet weak var identificationNumberViewHeight: NSLayoutConstraint!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private let TAG_IDENTIFICATION = 1000
    private let TAG_IDENTIFICATION_NUMBER = 1001
    private var selectedLOVDic: [String: DropDown] = [:]
    private var listModelArray = [ELModelClasses.LoanSearchDetailVOs]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "Search Application", showBack: true)
        }
    }
    
    private func setupView() {
        
        var optionArray = [DropDown]()
        // fetch the dropdownList according to master name
        CoreDataOperations.shared().fetchRecordsForMaster(masterName: Entity.ID_TYPE, parentKey: Constants.ID_TYPE_INDV) { (records) in
            
            if let records = records {
                
                optionArray = records.filter { ($0.code == ConstantCodes.ID_TYPE_PAN || $0.code == ConstantCodes.ID_TYPE_PASSPORT || $0.code == ConstantCodes.ID_TYPE_DL || $0.code == ConstantCodes.ID_TYPE_VOTER) }
                
                optionArray.append(DropDown(code: ConstantCodes.ID_TYPE_CODE_DOB, name: ConstantCodes.ID_TYPE_NAME_DOB))
                optionArray.append(DropDown(code: ConstantCodes.ID_TYPE_CODE_LAN, name: ConstantCodes.ID_TYPE_NAME_LAN))
                optionArray.insert(DropDown(code: ConstantCodes.LOV_TYPE_CODE_SELECT, name: ConstantCodes.LOV_TYPE_NAME_SELECT), at: 0)
            }
        }
        
        identificationTypeLOV.setLOVProperties(title: "Identification Type", tag: TAG_IDENTIFICATION, delegate: self, optionArray: optionArray)
        
        mobileNumberView.setProperties(placeHolder: "Enter Mobile Number", type: .Mobile, delegate: self)
        buttonView.setProperties(nextBtnTitle: "Search", delegate: self)
        
        validateFields()
    }
}

extension LoanApplicationSearchVC: CustomTFViewDelegate {
    
    func validateFields() {
        var isEnabled = mobileNumberView.getFieldValue().isValidPhone
        
        if let selectedObj = selectedLOVDic["\(TAG_IDENTIFICATION)"], selectedObj.code != ConstantCodes.LOV_TYPE_CODE_SELECT {
            isEnabled = !identificationNumberView.getFieldValue().isEmpty
            
            if isEnabled, selectedObj.code == ConstantCodes.ID_TYPE_PAN {
                isEnabled = (isEnabled && identificationNumberView.getFieldValue().validatePAN)
            }
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        if let selectedObj = selectedLOVDic["\(TAG_IDENTIFICATION)"], selectedObj.code != ConstantCodes.LOV_TYPE_CODE_SELECT
        {
            if selectedObj.code == ConstantCodes.ID_TYPE_AADHAR {
                return text.isNumeric && text.count <= Constants.AADHAR_LENGTH
            }
            else if selectedObj.code == ConstantCodes.ID_TYPE_PAN {
                return text.isAlphanumeric && text.count <= Constants.PAN_LENGTH
            }
            return text.isAlphanumeric && text.count <= 30
        }
        return true
    }
}

extension LoanApplicationSearchVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        
        self.listModelArray.removeAll()

        var params: [String : String]
        
        if let selectedObj = selectedLOVDic["\(TAG_IDENTIFICATION)"], selectedObj.code != ConstantCodes.LOV_TYPE_CODE_SELECT
        {
            if selectedObj.code == ConstantCodes.ID_TYPE_CODE_LAN {
                params = ["mobileNumber"    : mobileNumberView.getFieldValue(),
                          "aggrementNumber" : identificationNumberView.getFieldValue()]
            }
            else if selectedObj.code == ConstantCodes.ID_TYPE_CODE_DOB {
                params = ["mobileNumber"    : mobileNumberView.getFieldValue(),
                          "dateOfBirth"     : CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: identificationNumberView.getFieldValue(), outputFormat: Constants.DATE_FORMAT_SERVICE)]
            }
            else {
                params = ["mobileNumber"            : mobileNumberView.getFieldValue(),
                          "identificationTypeCode"  : selectedObj.code,
                          "identificationNumber"    : identificationNumberView.getFieldValue()]
            }
        }
        else {
            params = ["mobileNumber" : mobileNumberView.getFieldValue()]
        }
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_EXISTING_LOANS_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String: Any]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: ELModelClasses.ExistingLoanRecords.self) { list in
                    
                    if let records = list.loanSearchDetailVOs {
                        self.listModelArray.append(contentsOf: records)
                    }
                    
                    let storyboard = UIStoryboard.init(name: Storyboard.EXISTING_LOANS, bundle: nil)
                    
                    if let vc = storyboard.instantiateViewController(withIdentifier: "ELSearchResultVC") as? ELSearchResultVC {
                        vc.setData(arr: self.listModelArray)
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                }
            }
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            
        })
    }
}

extension LoanApplicationSearchVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if selectedObj.code != ConstantCodes.LOV_TYPE_CODE_SELECT {
            identificationNumberViewHeight.constant = 65
            
            if selectedObj.code == ConstantCodes.ID_TYPE_CODE_DOB {
                identificationNumberView.setProperties(placeHolder: "Enter Identification Number", type: .DOB, delegate: self, tag: TAG_IDENTIFICATION_NUMBER)
            }
            else {
                identificationNumberView.setProperties(placeHolder: "Enter Identification Number", delegate: self, tag: TAG_IDENTIFICATION_NUMBER)
            }
        }
        else {
            identificationNumberViewHeight.constant = 0
        }
        identificationNumberView.setFieldValue()
        identificationNumberView.setFieldPlaceHolder(placeHolder: "Enter \(CommonUtils.shared().getValidatedString(string: selectedObj.name))")
        validateFields()
    }
}

