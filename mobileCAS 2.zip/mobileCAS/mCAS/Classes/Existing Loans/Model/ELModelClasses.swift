//
//  ELModelClasses.swift
//  mCAS
//
//  Created by iMac on 12/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import Foundation

class ELModelClasses {
    
    struct ExistingLoanRecords: Codable {
        let dateDetailVOs : DateDetailVOs?
        let ba : String
        let loanSearchDetailVOs : [LoanSearchDetailVOs]?
    }
    
    struct DateDetailVOs: Codable {
        let systemDate : String
    }
    
    struct LoanSearchDetailVOs: Codable {
        let aggrementId : String
        let aggrementNumber : String
        let agreementDate : String?
        let amountFinance : String
        let amountOverdue : String
        let applicantType : String
        let balanceTenure : String
        let currencyId : String
        let currentDate : String?
        let customerId : String
        let dateOfBirth : String?
        let disbursalDate : String?
        let disbursalStatus : String
        let dueDay : String
        let effectiveRate : String
        let emailId : String
        let emiAmount : String
        let entityId : String
        let floatingFlag : String
        let frequency : String
        let indvCorpFlag : String
        let installmentUnpaid : String
        let isBirthday : String
        let lesseeId : String
        let loanLegalFlag : String
        let loanRepoFlag : String
        let loanStatus : String
        let loanType : String
        let maturityFlag : String
        let mobileNumber : String
        let nextDueDate : String?
        let panNumber : String
        let plainToken : Bool?
        let productDescription : String
        let property : String
        let soaChargeFlag : Bool?
        let soaChargeMsg : String
        let soaChargeNote : String
        let soaFlag : String
        let tenure : String
        let title : String
    }
    
    struct TransactionModel: Codable {
        let ecount : String?
        let pcount : String?
        let bcount : String?
        let emiDetailVO : [EMIDetailVO]?
        let paymentDetailVO : [PaymentDetailVO]?
        let bounceDetailVO : [BounceDetailVO]?
    }
    
    struct EMIDetailVO: Codable {
        let dueDate : String
        let installmentAmount : String
    }
    
    struct PaymentDetailVO: Codable {
        let amount : String
        let bankname : String?
        let instrumentType : String
        let paymentDate : String
        let paymentMode : String
    }
    
    struct BounceDetailVO: Codable {
        let bankName : String
        let bounceDate : String
        let chequeAmount : String
        let chequeDate : String
        let chequeNumber : String
        let description : String
        let instrumentType : String
    }
}
