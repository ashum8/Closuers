//
//  ServiceRequestVC.swift
//  mCAS
//
//  Created by Mac on 04/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class ServiceRequestVC: UIViewController {
    @IBOutlet weak var remarkView: UIView!
    @IBOutlet weak var remarkTitleLabel: UILabel!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var requestTypeLOV: LOVFieldView!
    @IBOutlet weak var requestSubTypeLOV: LOVFieldView!
    
    private let TAG_TYPE = 1000
    private let TAG_SUBTYPE = 1001
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var reqTypeArray = [DropDown]()
    private var reqSubTypeArray = [DropDown]()
    private var dataObj: ELModelClasses.LoanSearchDetailVOs!
    private var successPopView: SuccessPopupView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        requestTypeLOV.setLOVProperties(title: "Request Type", tag: TAG_TYPE, delegate: self)
        requestSubTypeLOV.setLOVProperties(title: "Request Sub Type", tag: TAG_SUBTYPE, delegate: self)
        
        remarkView.setMainViewProperties()
        remarkTitleLabel.setRemarks(title: "Remarks")
        textView.setRemarksTextView()
        
        buttonView.setProperties(nextBtnTitle: "Submit Request", delegate: self)
        fetchRequestMasters()
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            let navArray = AppDelegate.instance.applicationNavController.viewControllers
            let lastVC = navArray[navArray.count-2]
            headerView.showHideStepHeader(isHide: false, title: "Raise Request", landingPage: lastVC)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader()
        }
    }
    
    func setDate(data: ELModelClasses.LoanSearchDetailVOs) {
        self.dataObj = data
    }
    
    private func validateFields() {
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: (selectedLOVDic["\(TAG_TYPE)"] != nil && selectedLOVDic["\(TAG_SUBTYPE)"] != nil) && !textView.text.isEmpty)
    }
    
    private func fetchRequestMasters() {
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_MASTERS_RAISE_REQUEST_URL, paramaters: [:], autoHandleLoader: true, success: { (header, responseObj) in
            if let response = responseObj as? [[String: Any]]
            {
                self.reqTypeArray = response.map{
                    if let subArray = $0["requestSubTypes"] as? [[String: Any]] {
                        let parentKey = CommonUtils.shared().getValidatedString(string: $0["code"])
                        var tempSubType = [DropDown]()
                        tempSubType = subArray.map {
                            return DropDown(code: CommonUtils.shared().getValidatedString(string: $0["code"]), name: CommonUtils.shared().getValidatedString(string: $0["name"]), parentKey: parentKey)
                        }
                        self.reqSubTypeArray.append(contentsOf: tempSubType)
                    }
                    return DropDown(code: CommonUtils.shared().getValidatedString(string: $0["code"]), name: CommonUtils.shared().getValidatedString(string: $0["name"]))
                }
                
                self.requestTypeLOV.setLOVProperties(title: "Request Type", tag: self.TAG_TYPE, delegate: self, optionArray: self.reqTypeArray)
                self.requestSubTypeLOV.setLOVProperties(title: "Request Sub Type", tag: self.TAG_SUBTYPE, delegate: self, optionArray: self.reqSubTypeArray)
            }
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            
        })
    }
    
    private func submitServiceRequest() {
        
        let params = ["loanNumber"         : dataObj.aggrementNumber,
                      "queryType"          : selectedLOVDic["\(TAG_TYPE)"]?.code,
                      "querySubType"       : selectedLOVDic["\(TAG_SUBTYPE)"]?.code,
                      "queryDescription"   : textView.text!]
        
        Webservices.shared().POST(urlString: ServiceUrl.RAISE_REQUEST_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String: Any], let crmNumber = response["crmNumber"] as? String
            {
                self.openPopUp(number: crmNumber)
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            
        })
    }
    
    private func openPopUp(number: String) {
        self.successPopView = .fromNib()
        self.successPopView.setProperties(width: self.view.frame.size.width, height: self.view.frame.size.height, delegate: self, line1: "Request has been successfully raised. You can track request by Request ID ", line2: number)
        AppDelegate.instance.window?.addSubview(self.successPopView)
    }
}

extension ServiceRequestVC: UITextViewDelegate {
    
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        textView.text = textView.text?.trimmingCharacters(in: .whitespaces)
        validateFields()
        return true
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let stringValue = CommonUtils.shared().getValidatedString(string: textView.text) + text
        return stringValue.count < Constants.REMARKS_LENGTH && stringValue.isAlphanumericAndSpace && text != "\n"
    }
}

extension ServiceRequestVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        submitServiceRequest()
    }
}

extension ServiceRequestVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_TYPE {
            if let dd = selectedLOVDic["\(TAG_TYPE)"] {
                requestSubTypeLOV.resetLOVWithMaster(list: reqSubTypeArray.filter({return ($0.parentKey == dd.code) }))
                selectedLOVDic["\(TAG_SUBTYPE)"] = nil
            }
        }
        validateFields()
    }
}

extension ServiceRequestVC: SuccessPopupDelegate {
    func goToHomeAction() {
        AppDelegate.instance.applicationNavController?.popViewController(animated: true)
    }
}

