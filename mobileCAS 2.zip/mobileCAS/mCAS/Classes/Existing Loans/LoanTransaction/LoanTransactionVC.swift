//
//  LoanTransactionVC.swift
//  mCAS
//
//  Created by Mac on 04/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class LoanTransactionVC: UIViewController {
    
    @IBOutlet weak var transactionHistoryLabel: UILabel!
    @IBOutlet weak var paymentButton: UIButton!
    @IBOutlet weak var bounceButton: UIButton!
    @IBOutlet weak var emiButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var tableView: UITableView!
    
    private var paymentlistModelArray = [ELModelClasses.PaymentDetailVO]()
    private var bouncelistModelArray = [ELModelClasses.BounceDetailVO]()
    private var emilistModelArray = [ELModelClasses.EMIDetailVO]()
    private var dataObj: ELModelClasses.LoanSearchDetailVOs!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.title = "Transactions"
        noDataCapturedView.setProperties()
        transactionHistoryLabel.font = CustomFont.shared().GETFONT_MEDIUM(17)
        transactionHistoryLabel.text = "LAST 5 TRANSACTIONS HISTORY"
        paymentButton.sendActions(for: .touchUpInside)
        
        tableView.register(UINib(nibName: "PaymentBouncesTVCell", bundle: nil), forCellReuseIdentifier: "PaymentBouncesTVCell")
    }
    
    func setDate(data: ELModelClasses.LoanSearchDetailVOs) {
        self.dataObj = data
    }
    
    private func setTableViewData() {
        
        if paymentButton.isSelected {
            tableView.isHidden = paymentlistModelArray.isEmpty
        }
        else if bounceButton.isSelected {
            tableView.isHidden = bouncelistModelArray.isEmpty
        }
        else if emiButton.isSelected {
            tableView.isHidden = emilistModelArray.isEmpty
        }
        
        noDataCapturedView.isHidden = !tableView.isHidden
        tableView.reloadData()
    }
    
    @IBAction func transactionButtonAction(_ sender: UIButton) {
        
        if !sender.isSelected {
            fetchTransactions()
        }
        
        switch sender {
        case paymentButton:
            paymentButton.setSelectedSegmentButtonProperties()
            bounceButton.resetSegmentButtonProperties()
            emiButton.resetSegmentButtonProperties()
            
        case bounceButton:
            paymentButton.resetSegmentButtonProperties()
            bounceButton.setSelectedSegmentButtonProperties()
            emiButton.resetSegmentButtonProperties()
            
        case emiButton:
            paymentButton.resetSegmentButtonProperties()
            bounceButton.resetSegmentButtonProperties()
            emiButton.setSelectedSegmentButtonProperties()
            
        default:
            break
        }
    }
    
    private func fetchTransactions() {
        
        let params = ["referenceNumber"         : dataObj.aggrementNumber,
                      "agreementId"             : dataObj.aggrementId,
                      "noOfTransactionToDisplay": "5"]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_LOAN_TRANSACTIONS_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
            if let response = responseObj as? [String: Any]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: ELModelClasses.TransactionModel.self) { list in
                    if let records = list.emiDetailVO {
                        self.emilistModelArray = records
                    }
                    if let records = list.paymentDetailVO {
                        self.paymentlistModelArray = records
                    }
                    if let records = list.bounceDetailVO {
                        self.bouncelistModelArray = records
                    }
                    self.setTableViewData()
                }
                
            }
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
                self.paymentlistModelArray.removeAll()
                self.bouncelistModelArray.removeAll()
                self.emilistModelArray.removeAll()
                self.setTableViewData()
            }
            
        }, noNetwork: { (error) in
            
        })
    }
}


extension LoanTransactionVC: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if paymentButton.isSelected {
            return paymentlistModelArray.count
        }
        else if bounceButton.isSelected {
            return bouncelistModelArray.count
        }
        else if emiButton.isSelected {
            return emilistModelArray.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if paymentButton.isSelected {
            let cell = tableView.dequeueReusableCell(withIdentifier: "PaymentBouncesTVCell", for: indexPath) as! PaymentBouncesTVCell
            cell.setProperties()
            cell.dateLabel.text = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: paymentlistModelArray[indexPath.row].paymentDate)
            cell.titleLabel1.text = "Txn Amount"
            cell.valueLabel1.text = paymentlistModelArray[indexPath.row].amount.formatCurrency
            cell.titleLabel2.text = "Payment Mode"
            cell.valueLabel2.text = paymentlistModelArray[indexPath.row].paymentMode
            return cell
        }
        else if bounceButton.isSelected {
            let cell = tableView.dequeueReusableCell(withIdentifier: "PaymentBouncesTVCell", for: indexPath) as! PaymentBouncesTVCell
            cell.setProperties()
            cell.dateLabel.text = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: bouncelistModelArray[indexPath.row].bounceDate)
            
            cell.titleLabel1.text = "Cheque Number"
            cell.valueLabel1.text = bouncelistModelArray[indexPath.row].chequeNumber
            cell.titleLabel2.text = "Amount"
            cell.valueLabel2.text = bouncelistModelArray[indexPath.row].chequeAmount.formatCurrency
            cell.titleLabel3.text = "Return Date"
            cell.valueLabel3.text = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: bouncelistModelArray[indexPath.row].bounceDate)
            
            return cell
        }
        else if emiButton.isSelected {
            let cell = tableView.dequeueReusableCell(withIdentifier: "FutureEMITVCell", for: indexPath) as! FutureEMITVCell
            cell.setProperties(date: emilistModelArray[indexPath.row].dueDate, amount: emilistModelArray[indexPath.row].installmentAmount)
            return cell
        }
        
        return UITableViewCell()
    }
}
