//
//  FutureEMITVCell.swift
//  mCAS
//
//  Created by iMac on 13/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class FutureEMITVCell: UITableViewCell {
    @IBOutlet weak var dateTitleLabel: UILabel!
    @IBOutlet weak var payableTitleLabel: UILabel!
    @IBOutlet weak var dateValueLabel: UILabel!
    @IBOutlet weak var amountValueLabel: UILabel!
    @IBOutlet weak var bgview: UIView!
    
    func setProperties(date: String, amount: String) {
        bgview.setShadow()
        bgview.setCornerRadius()
        
        dateTitleLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        payableTitleLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        dateValueLabel.font = CustomFont.shared().GETFONT_MEDIUM(16)
        amountValueLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        dateTitleLabel.text = "Date"
        payableTitleLabel.text = "Payable Amount"
        dateValueLabel.text = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: date)
        amountValueLabel.text = amount.formatCurrency  
    }
}
