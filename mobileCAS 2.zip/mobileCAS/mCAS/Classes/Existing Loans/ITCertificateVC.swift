//
//  ITCertificateVC.swift
//  mCAS
//
//  Created by Mac on 04/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class ITCertificateVC: UIViewController {
    
    @IBOutlet weak var financialYearLOV: LOVFieldView!
    @IBOutlet weak var emailIdView: CustomTextFieldView!
    @IBOutlet weak var noteLabel: UILabel!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private let TAG_YEAR = 1000
    private var selectedLOVDic: [String: DropDown] = [:]
    private var dataObj: ELModelClasses.LoanSearchDetailVOs!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.title = "IT Certificate"
        
        fetchFinancialYear()
        
        financialYearLOV.setLOVProperties(title: "Financial Year", tag: TAG_YEAR, delegate: self)
        
        emailIdView.setProperties(placeHolder: "Enter Email ID", delegate: self)
        buttonView.setProperties(showBack: true, backBtnTitle: "View as PDF", showNext: true, nextBtnTitle: "Email PDF", delegate: self)
        
        noteLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        noteLabel.textColor = Color.RED
        noteLabel.text = "Note: Emails will be sent to the registered as well as entered email id's."
        
        emailIdView.setFieldValue(text: dataObj.emailId)
        validateFields()
        
    }
    
    func setDate(data: ELModelClasses.LoanSearchDetailVOs) {
        self.dataObj = data
    }
    
    private func fetchFinancialYear() {
        
        let params = ["aggrementNumber" : dataObj.aggrementNumber]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_IT_CERTIFICATE_MASTER_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String]
            {
                let arr = response.map( {DropDown(code: $0, name: $0)} )
                self.financialYearLOV.setLOVProperties(title: "Financial Year", tag: self.TAG_YEAR, delegate: self, optionArray: arr)
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            
        })
    }
}


extension ITCertificateVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        let yearDetail = getYear()
        
        let params = ["loanNumber"      : dataObj.aggrementNumber,
                      "reportFlag"      : "ITC",
                      "fromDate"        : "\(yearDetail.startYear)-04-01",
                      "toDate"          : "\(yearDetail.endYear)-03-31",
                      "mailId"          : emailIdView.getFieldValue(),
                      "ccMailId"        : dataObj.emailId,
                      "viewFlag"        : "E"]
        
        Webservices.shared().emailPdfReport(params: params)
    }
    
    func backButtonAction() {
        let yearDetail = getYear()
        
        let params = ["loanNumber"      : dataObj.aggrementNumber,
                      "reportFlag"      : "ITC",
                      "fromDate"        : "\(yearDetail.startYear)-04-01",
                      "toDate"          : "\(yearDetail.endYear)-03-31",
                      "viewFlag"        : "V"]
        
        Webservices.shared().viewPdfReport(params: params)
    }
    
    private func getYear() -> (startYear: String, endYear: String) {
        let year = selectedLOVDic["\(TAG_YEAR)"]?.name
        if let _ = year?.contains("-") {
            return (String(year!.split(separator: "-")[0]), String(year!.split(separator: "-")[1]))
        }
        
        return ("", "")
    }
}

extension ITCertificateVC: CustomTFViewDelegate {
    func validateFields() {
        let isEnable: Bool = emailIdView.getFieldValue().isValidEmail && (selectedLOVDic["\(TAG_YEAR)"] != nil)
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnable)
    }
}

extension ITCertificateVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        validateFields()
    }
}

