//
//  LoanStatementVC.swift
//  mCAS
//
//  Created by Mac on 04/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class LoanStatementVC: UIViewController {
    
    @IBOutlet weak var emailIdView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var noteLabel: UILabel!
    
    private var dataObj: ELModelClasses.LoanSearchDetailVOs!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.title = "Statement"
        
        emailIdView.setProperties(placeHolder: "Enter Email ID", delegate: self)
        emailIdView.setFieldValue(text: dataObj.emailId)
        buttonView.setProperties(showBack: true, backBtnTitle: "View as PDF", showNext: true, nextBtnTitle: "Email PDF", delegate: self)
        
        noteLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        noteLabel.textColor = Color.RED
        noteLabel.text = "Note: Emails will be sent to the registered as well as entered email id's."
        
        validateFields()
    }
    
    func setDate(data: ELModelClasses.LoanSearchDetailVOs) {
        self.dataObj = data
    }
}

extension LoanStatementVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        let params = ["loanNumber"  : dataObj.aggrementNumber,
                      "reportFlag"  : "SOA",
                      "mailId"      : emailIdView.getFieldValue(),
                      "ccMailId"    : dataObj.emailId,
                      "viewFlag"    : "E"]
        
        Webservices.shared().emailPdfReport(params: params)
    }
    
    func backButtonAction() {
        let params = ["loanNumber" : dataObj.aggrementNumber,
                      "reportFlag" : "SOA",
                      "viewFlag"   : "V"]
        
        Webservices.shared().viewPdfReport(params: params)
    }
}

extension LoanStatementVC: CustomTFViewDelegate {
    func validateFields() {
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: emailIdView.getFieldValue().isValidEmail)
    }
}

