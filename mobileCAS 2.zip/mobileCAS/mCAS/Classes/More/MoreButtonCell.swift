//
//  MoreButtonCell.swift
//  mCAS
//
//  Created by iss on 22/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class MoreButtonCell: UICollectionViewCell {
    
    @IBOutlet weak var cellButton: UIButton!
    @IBOutlet weak var bottomLine: UIView!
    @IBOutlet weak var rightLine: UIView!
    
    func setCellProperties(btnModel: ButtonModel) {
        
        // Configure the cell
        self.backgroundColor = .white
        bottomLine.backgroundColor = .lightGray
        rightLine.backgroundColor = .lightGray
        
        self.cellButton.isUserInteractionEnabled = false
        self.cellButton.setTitle(btnModel.buttonText, for: .normal)
        self.cellButton.setTitleColor(.darkGray, for: .normal)
        self.cellButton.setImage(UIImage(named: btnModel.mediumIcon), for: .normal)
        self.cellButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(15)
        self.cellButton.setAlignmentOfButton(isTab: false)
    }
}
