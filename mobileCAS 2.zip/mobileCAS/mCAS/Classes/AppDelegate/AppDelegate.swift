//
//  AppDelegate.swift
//  mCAS
//
//  Created by iMac on 17/12/19.
//  Copyright © 2019 iMac. All rights reserved.
//

import UIKit
import CoreData
import CoreTelephony
import CoreLocation


class AppDelegate: UIResponder, UIApplicationDelegate {
    
    internal var window: UIWindow?
    var isLoggedin = false
    var mainMenuArray: [ButtonModel] = []
    var currentLoggedInUser: CDUserDetails!
    var applicationNavController: UINavigationController!
    
    private var imageView = UIImageView()
    private var appInBackgroundDateTime: Date?
    
    private(set) var bottomTabbarView: BottomTabbarView?
    private(set) var headerView: HeaderView?
    
    // MARK: - CLLocationManager
    private(set) var formattedAddress: String = ""
    private(set) var gpsDictionary: [String : String] = [:]
    private var locationManager: CLLocationManager?
    
    private var networkPreviousStateActive = false
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        UserDefaults.standard.setSecret("sk.encryptedUserDefaults")
        
        intializeKeyboardManager()
        initializeLocationManager()
        
        //invalidate session in offline mode functionality
        NotificationCenter.default.addObserver(self, selector: #selector(applicationDidTimeout(notif:)), name: NSNotification.Name(TIMERUIApplication.kApplicationDidTimeoutNotification), object: nil)
        
        UIApplication.shared.ignoreSnapshotOnNextApplicationLaunch()
        
        networkPreviousStateActive = ReachabilityManager.isReachable()
        
        NotificationCenter.default.addObserver(self, selector: #selector(networkStatusChanged), name: NSNotification.Name.reachabilityChanged, object: nil)
        
        self.applicationNavController = self.window?.rootViewController as? UINavigationController
        
        return true
    }
    
    //  MARK: - APP Life cycle methods
    
    func applicationWillResignActive(_ application: UIApplication) {
        
        self.appInBackgroundDateTime = Date()
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        
        self.appInBackgroundDateTime = Date()
        self.imageView = UIImageView(frame: self.window!.bounds)
        self.imageView.image = UIImage(named: "whiteImage") // assuming whiteImage is your splash image's name
        UIApplication.shared.keyWindow?.subviews.last?.addSubview(self.imageView)
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        
        self.imageView.removeFromSuperview()
        self.locationManager?.startUpdatingLocation()
        self.locationManager?.delegate = self
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        
        let interval = Date().timeIntervalSince(self.appInBackgroundDateTime ?? Date())/60
        let timeoutvalue = TIMERUIApplication.kApplicationTimeoutInMinutes
        
        if interval >= timeoutvalue {
            CommonAlert.shared().showOfflineAlert()
        }
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.reachabilityChanged, object: nil)
        self.locationManager = nil
    }
    
    @objc public class var instance: AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    
    func getSavedUserID() -> String {
        return CommonUtils.shared().getValidatedString(string: CommonUtils.shared().getDataFromSecretUserDefault(key: UserDefaultKey.USER_ID))
    }
    
    func presentLoginViewController() {
        self.applicationNavController.popToRootViewController(animated: false)
        
        self.bottomTabbarView?.removeFromSuperview()
        self.headerView?.removeFromSuperview()
        self.bottomTabbarView = nil
        self.headerView = nil
    }
    
    func getLatitude()-> String {
        return CommonUtils.shared().getValidatedString(string: self.gpsDictionary["Latitude"])
    }
    
    func getLongitude()-> String {
        return CommonUtils.shared().getValidatedString(string: self.gpsDictionary["Longitude"])
    }
    
    func getAltitude()-> String {
        return CommonUtils.shared().getValidatedString(string: self.gpsDictionary["Altitude"])
    }
    
    func getNetworkProvider()-> String {
        let netinfo = CTTelephonyNetworkInfo()
        let carrier = netinfo.subscriberCellularProvider
        return String(carrier?.carrierName ?? "")
    }
    
    func getAccuracy()-> String {
        return CommonUtils.shared().getValidatedString(string: self.gpsDictionary["Accuracy"])
    }
    
    func getSpeed()-> String {
        return CommonUtils.shared().getValidatedString(string: self.gpsDictionary["Speed"])
    }
    
    func getTimeStamp()-> String {
        return CommonUtils.shared().getValidatedString(string: self.gpsDictionary["TimeStamp"])
    }
    
    
    // MARK: - Geocode Address
    
    private func getFormattedAddress(latitude: Double, logitude: Double) -> [String : Any]? {
        
        let urlString = "https://maps.google.com/maps/api/geocode/json?latlng=\(latitude),\(logitude)&sensor=true&key=AIzaSyCpgJS1jT5VXmONImP-Rq56nQYWirX-3jE"
        let urlFromString = URL(string: urlString)
        
        do {
            let reverseGeoString = try String(contentsOf: urlFromString!, encoding: .utf8)
            let locationResult = try JSONSerialization.jsonObject(with: Data(reverseGeoString.utf8), options: []) as? [String: Any]
            
            if CommonUtils.shared().getValidatedString(string: locationResult?["status"]) == "OK", let results = locationResult?["results"] as? [[String: Any]]
            {
                var tempDic:[String : Any]?
                
                for item in results {
                    if let arr = item["types"] as? [Any], !arr.isEmpty {
                        tempDic = item
                        break
                    }
                }
                
                if !results.isEmpty && tempDic != nil {
                    tempDic = results[0]
                }
                return tempDic
            }
        }
        catch {}
        
        return nil
    }
    
    private func setAddressComponent(dictData: [String: Any]) {
        
        var addressLineOne = ""
        
        if let addressArray = dictData["address_components"] as? NSArray {
            
            for item in addressArray {
                
                if let subDict = item as? NSDictionary, let arrType = subDict["types"] as? NSArray, arrType.count > 0  {
                    
                    if arrType.contains("premise") || arrType.contains("sublocality_level_3") || arrType.contains("sublocality_level_2") {
                        addressLineOne = addressLineOne.isEmpty ? CommonUtils.shared().getValidatedString(string: subDict["long_name"]) : "\(addressLineOne), \(CommonUtils.shared().getValidatedString(string: subDict["long_name"]))"
                    }
                    
                    if arrType.contains("sublocality_level_1") {
                        self.gpsDictionary["addressLineTwo"] = CommonUtils.shared().getValidatedString(string: subDict["long_name"])
                    }
                    
                    if arrType.contains("locality") {
                        self.gpsDictionary["city"] = CommonUtils.shared().getValidatedString(string: subDict["long_name"])
                    }
                    
                    if arrType.contains("administrative_area_level_1") {
                        self.gpsDictionary["state"] = CommonUtils.shared().getValidatedString(string: subDict["long_name"])
                    }
                    
                    if arrType.contains("country") {
                        self.gpsDictionary["country"] = CommonUtils.shared().getValidatedString(string: subDict["long_name"])
                    }
                    
                    if arrType.contains("postal_code") {
                        self.gpsDictionary["pincode"] = CommonUtils.shared().getValidatedString(string: subDict["long_name"])
                    }
                }
            }
            
            self.gpsDictionary["addressLineOne"] = addressLineOne
        }
    }
    
    //  MARK: - CLLocationManager
    
    private func initializeLocationManager() {        
        //Get User Location
        locationManager = CLLocationManager()
        locationManager?.delegate = self
        locationManager?.distanceFilter = CLLocationDistance(200.0) // Will notify the LocationManager every 200 meters
        locationManager?.desiredAccuracy = kCLLocationAccuracyBest
        locationManager?.requestWhenInUseAuthorization()
        locationManager?.startUpdatingLocation()
    }
    
    //  MARK: - IQKeyboardManager
    
    private func intializeKeyboardManager() {
        //Enabling keyboard manager
        IQKeyboardManager.shared()?.isEnabled = true
        
        IQKeyboardManager.shared()?.keyboardDistanceFromTextField = 25
        //Enabling autoToolbar behaviour. If It is set to NO. You have to manually create UIToolbar for keyboard.
        IQKeyboardManager.shared()?.isEnableAutoToolbar = true
        
        //Setting toolbar behavious to IQAutoToolbarBySubviews. Set it to IQAutoToolbarByTag to manage previous/next according to UITextField's tag property in increasing order.
        IQKeyboardManager.shared()?.toolbarManageBehaviour = IQAutoToolbarBySubviews
        
        //Resign textField if touched outside of UITextField/UITextView.
        IQKeyboardManager.shared()?.shouldResignOnTouchOutside = true
        
        //Giving permission to modify TextView's frame
        IQKeyboardManager.shared()?.canAdjustTextView = true
    }
    
    // MARK: - Network Status Messages
    
    @objc private func networkStatusChanged() {
        
        if ReachabilityManager.isReachable() && !self.networkPreviousStateActive
        {
            MRProgressOverlayView.showOverlayAdded(to: self.window, title: NSLocalizedString("You are online now.", comment: ""), mode: .checkmark, animated: true)
            self.networkPreviousStateActive = true
        }
        else if !ReachabilityManager.isReachable() && self.networkPreviousStateActive
        {
            MRProgressOverlayView.showOverlayAdded(to: self.window, title: NSLocalizedString("You are offline now.", comment: "Alert for network status."), mode: .cross, animated: true)
            self.networkPreviousStateActive = false
        }
        
        // Delay execution of my block for 2 seconds.
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            guard let self = self else {
                return
            }
            
            DispatchQueue.main.async {
                MRProgressOverlayView.dismissOverlay(for: self.window, animated: false)
            }
        }
    }
    
    // MARK: - SESSION INVALIDATE IN OFFLINE MODE
    
    @objc func applicationDidTimeout(notif: NSNotification)
    {
        CommonAlert.shared().showAlertForInvalidSession()
    }
    
    // MARK: - Core Data stack
    
    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
         */
        
        let container = NSPersistentContainer(name: "mCAS")
        
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    // MARK: - Core Data Saving support
    
    func getContext() -> NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            }
            catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    func getTopPadding() -> CGFloat {
        if #available(iOS 11.0, *) {
            if let window = UIApplication.shared.keyWindow {
                return window.safeAreaInsets.top
            }
        }
        return 20 //status bar height
    }
    
    func getBottomPadding() -> CGFloat {
        if #available(iOS 11.0, *) {
            if let window = UIApplication.shared.keyWindow {
                return window.safeAreaInsets.bottom
            }
        }
        return 0
    }
    
    //  MARK: - createBottomTabBar Methods
    
    func createBottomTabBar() {
        if self.bottomTabbarView == nil {
            let totalHeight = 55 + getBottomPadding()
            
            self.bottomTabbarView = BottomTabbarView(frame: CGRect(x: 0, y: self.window!.frame.size.height-totalHeight, width: self.window!.frame.size.width, height: totalHeight))
            self.applicationNavController.view.addSubview(self.bottomTabbarView!)
        }
    }
    
    func getSpecificVC(targetClass: AnyClass) -> UIViewController? {
        for controller in AppDelegate.instance.applicationNavController.viewControllers.reversed() {
            if controller.isKind(of: targetClass.self) {
                return controller
            }
        }
        
        return nil
    }
    
    func intializeViewController(viewControllerIdentifier: String) -> UIViewController {
        let storyboard = UIStoryboard.init(name: Storyboard.MAIN, bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: viewControllerIdentifier)
    }
    
    // MARK: - createHeaderControlView
    
    func createHeaderView() {
        if self.headerView == nil {
            let topPadding = getTopPadding()
            
            self.headerView = HeaderView(frame: CGRect(x: 0, y: 0, width: self.window!.frame.size.width, height: Constants.HEADER_HEIGHT+topPadding))
            self.applicationNavController.view.addSubview(self.headerView!)
        }
    }
    
    func tabsButtonAction(tabID: String) {
        
        if tabID == UserRoles.HOME_DASHBOARD {
            self.applicationNavController.pushViewController(self.intializeViewController(viewControllerIdentifier: "DashboardViewController"), animated: false)
        }
        else if tabID == UserRoles.MORE {
            self.applicationNavController.pushViewController(self.intializeViewController(viewControllerIdentifier: "MoreViewController"), animated: false)
        }
        else if tabID == UserRoles.CALC {
            let storyboard = UIStoryboard(name: Storyboard.EMI_CALCULATOR, bundle: nil)
            self.applicationNavController.pushViewController(storyboard.instantiateInitialViewController()!, animated: false)
        }
        else if tabID == UserRoles.RATE_INITIATION {
            let storyboard = UIStoryboard(name: Storyboard.RATE_APPROVAL, bundle: nil)
            self.applicationNavController.pushViewController(storyboard.instantiateInitialViewController()!, animated: false)
        }
        else if tabID == UserRoles.RATE_APPROVAL {
            let storyboard = UIStoryboard(name: Storyboard.RATE_APPROVAL, bundle: nil)
            self.applicationNavController.pushViewController(storyboard.instantiateViewController(withIdentifier: "RateApproveHomeVC"), animated: false)
        }
        else if tabID == UserRoles.CHANGE_PASSWORD {
            self.applicationNavController.pushViewController(self.intializeViewController(viewControllerIdentifier: "ChangePasswordVC"), animated: false)
        }
        else if tabID == UserRoles.CAPTURE_LEAD {
            let storyboard = UIStoryboard(name: Storyboard.LEAD, bundle: nil)
            self.applicationNavController.pushViewController(storyboard.instantiateViewController(withIdentifier: "CustomerTypeVC"), animated: false)
        }
        else if tabID == UserRoles.VIEW_LEAD {
            let storyboard = UIStoryboard(name: Storyboard.LEAD, bundle: nil)
            self.applicationNavController.pushViewController(storyboard.instantiateViewController(withIdentifier: "LeadsListVC"), animated: false)
        }
        else if tabID == UserRoles.STATUS_ENQUIRY {
            let storyboard = UIStoryboard(name: Storyboard.STATUS_ENQUIRY, bundle: nil)
            self.applicationNavController.pushViewController(storyboard.instantiateViewController(withIdentifier: "LoanApplicationVC"), animated: false)
        }
        else if tabID == UserRoles.SOURCING {
            let storyboard = UIStoryboard(name: Storyboard.SOURCING, bundle: nil)
            self.applicationNavController.pushViewController(storyboard.instantiateViewController(withIdentifier: "SourcingListVC"), animated: false)
        }
        else if tabID == UserRoles.CREATE_APPLICATION {
            let storyboard = UIStoryboard(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "SourcingListVC") as? SourcingListVC {
                vc.setData(jumpToCreateApp: true)
                self.applicationNavController.pushViewController(vc, animated: false)
            }
        }
        else if tabID == UserRoles.EXISTING_LOANS {
            let storyboard = UIStoryboard(name: Storyboard.EXISTING_LOANS, bundle: nil)
            self.applicationNavController.pushViewController(storyboard.instantiateViewController(withIdentifier: "LoanApplicationSearchVC"), animated: false)
        }
        else if tabID == UserRoles.FIELD_VERIFY {
            let storyboard = UIStoryboard(name: Storyboard.FI, bundle: nil)
            self.applicationNavController.pushViewController(storyboard.instantiateViewController(withIdentifier: "FIHomeVC"), animated: false)
        }
    }
}

extension AppDelegate: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        
        if let err = error as? CLError, err.code == .denied {
            manager.stopUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if !locations.isEmpty {
            
            let newLocation = locations[0]
            var altitude = ""
            if newLocation.verticalAccuracy > 0 {
                altitude = String(format: "%f", newLocation.altitude)
            }
            
            var speed = ""
            if newLocation.speed > 0 {
                speed = String(format: "%f", newLocation.speed)
            }
            
            var accuracy = ""
            if (newLocation.altitude > 0) {
                accuracy = String(format: "%f", newLocation.horizontalAccuracy)
            }
            
            self.gpsDictionary["Latitude"] = String(format: "%f", newLocation.coordinate.latitude)
            self.gpsDictionary["Longitude"] = String(format: "%f", newLocation.coordinate.longitude)
            self.gpsDictionary["Altitude"] = altitude
            self.gpsDictionary["Speed"] = speed
            self.gpsDictionary["Accuracy"] = accuracy
            self.gpsDictionary["TimeStamp"] = String(format: "%lld", newLocation.timestamp.timeIntervalSince1970)
            
            DispatchQueue.global(qos: .background).async {
                
                if let tempDic = self.getFormattedAddress(latitude: newLocation.coordinate.latitude, logitude: newLocation.coordinate.longitude) {
                    self.setAddressComponent(dictData: tempDic)
                    self.formattedAddress = CommonUtils.shared().getValidatedString(string: tempDic["formatted_address"])
                }
                
                if (Constants.ENABLE_LOCATION_UPDATE_IN_BG) {
                    //[self updateLocationOnServer];
                }
            }
        }
    }
}

