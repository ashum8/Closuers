//
//  OnlineSearchModel.swift
//  mCAS
//
//  Created by Mac on 06/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

struct OSTableModel  {
    var dequeIdentifier: String?
    var cellHeight: CGFloat = 0.0
    var isVisible = false
}
