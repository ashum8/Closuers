//
//  OSAppIDTableCell.swift
//  mCAS
//
//  Created by iMac on 28/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class OSAppIDTableCell: GenericTableViewCell, UITextFieldDelegate {
    
    //SK Change - should use CustomTextField
    @IBOutlet weak var simpleSearchTextField: JVFloatLabeledTextField!
    @IBOutlet weak var searchButton: UIButton!
    
    func setProperties() {
        
        simpleSearchTextField.setCornerRadius()
        simpleSearchTextField.layer.borderColor = UIColor.lightGray.cgColor
        simpleSearchTextField.layer.borderWidth = 1.0
        simpleSearchTextField.autocapitalizationType = .allCharacters
        simpleSearchTextField.keyboardType = .default
        
        searchButton.setButtonProperties()
        simpleSearchTextField.font = CustomFont.shared().GETFONT_REGULAR(15)
    }
    
    @IBAction func searchButtonClicked(_ sender: Any) {
        
        if !(simpleSearchTextField.text!.isAlphanumeric) || simpleSearchTextField.text!.isEmpty {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter valid Application Id", comment: ""))
        }
        else {
            simpleSearchTextField.resignFirstResponder()
            
            if let viewController = self.getViewController() as? OnlineSearchVC {
                viewController.searchServiceCall(txtSearch: simpleSearchTextField.text!.uppercased())
            }
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField.disableDoubleSpacePeriodIssue(shouldChangeCharactersRange: range, replacementString: string) == false {
            return false
        }
        
        if let text = textField.text, let textRange = Range(range, in: text), !string.isEmpty {
            let updatedText = text.replacingCharacters(in: textRange, with: string)
            return (updatedText.isAlphanumeric && updatedText.count <= Constants.APPLICATION_ID_LENGTH)
        }
        
        return true
    }
    
}
