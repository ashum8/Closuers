//
//  OSDOBTableCell.swift
//  mCAS
//
//  Created by iMac on 28/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class OSDOBTableCell: GenericTableViewCell, UITextFieldDelegate  {
    
    //SK Change - should use CustomTextField
    @IBOutlet weak var customerNameTextField: JVFloatLabeledTextField!
    @IBOutlet weak var dateOfBirthTextField: JVFloatLabeledTextField!
    @IBOutlet weak var searchButton: UIButton!
    
    var selectedDate: Date?
    
    func setProperties() {
        
        self.selectedDate = Date()
        
        self.customerNameTextField.setCornerRadius()
        self.customerNameTextField.layer.borderColor = UIColor.lightGray.cgColor
        self.customerNameTextField.layer.borderWidth = 1.0
        
        self.dateOfBirthTextField.setCornerRadius()
        self.dateOfBirthTextField.layer.borderColor = UIColor.lightGray.cgColor
        self.dateOfBirthTextField.layer.borderWidth = 1.0
        
        self.customerNameTextField.placeholder = NSLocalizedString("Customer/Company Name", comment: "")
        self.dateOfBirthTextField.placeholder = NSLocalizedString("DOB/DOI", comment: "")
        
        self.searchButton.setButtonProperties()
        customerNameTextField.font = CustomFont.shared().GETFONT_REGULAR(15)
        dateOfBirthTextField.font = CustomFont.shared().GETFONT_REGULAR(15)  
    }
    
    
    @IBAction func searchButtonClicked(_ sender: Any) {
        
        var alertMessage = ""
        
        if !self.customerNameTextField.text!.isAlphabeticAndSpace {
            alertMessage = NSLocalizedString("Please enter valid \(self.customerNameTextField.placeholder!)", comment: "")
        }
        
        if self.customerNameTextField.text!.count < 3 {
            alertMessage = NSLocalizedString("Please enter at least 3 character in \(self.customerNameTextField.placeholder!)", comment: "")
        }
        
        if self.dateOfBirthTextField.text == "" {
            alertMessage = NSLocalizedString("Please enter \(self.dateOfBirthTextField.placeholder!)", comment: "")
        }
        
        if !alertMessage.isEmpty {
            CommonAlert.shared().showAlert(message: NSLocalizedString(alertMessage, comment: ""))
        }
        else {
            self.customerNameTextField.resignFirstResponder()
        }
        
    }
    
    @IBAction func selectDateOfBirth(_ sender: Any) {
        
        //Show Date Picker
//        let actionSheetPicker = ActionSheetDatePicker.init(title: NSLocalizedString("Choose DOB/DOI", comment: ""), datePickerMode: .date, selectedDate: self.selectedDate, minimumDate: nil, maximumDate: Date(), target: self, action: #selector(dateOfBirthWasSelected(selectedDate:)), origin: sender)
//
//        actionSheetPicker?.hideCancel = false
//        actionSheetPicker?.show()
    }
    
    @objc func dateOfBirthWasSelected(selectedDate: Date) {
        self.selectedDate = selectedDate
        self.dateOfBirthTextField.text = selectedDate.getFormatedDateString(outputFormat: Constants.DATE_FORMAT_VIEW)
    }
    
    //   MARK: - UITextField delegate methods
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == self.customerNameTextField {
            return true
        }
        return false
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField.disableDoubleSpacePeriodIssue(shouldChangeCharactersRange: range, replacementString: string) == false {
            return false
        }
        
        if let text = textField.text, let textRange = Range(range, in: text), !string.isEmpty {
            let updatedText = text.replacingCharacters(in: textRange, with: string)
            return (textField == self.customerNameTextField && updatedText.isAlphabeticAndSpace)
        }
        
        return true
    }
}
