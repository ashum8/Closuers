//
//  LOVOptionCell.swift
//  mCAS
//
//  Created by Mac on 02/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

@objc protocol LOVOptionCellDelegate {
    func buttonSelectAction(tag: NSInteger, btn: UIButton)
}

class LOVOptionCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var checkButton: UIButton!
    @objc weak var delegate: LOVOptionCellDelegate?
    
    func setProperties(title: String, isSelected: Bool, isMultiSelectionEnabled: Bool = false, delegate: LOVOptionCellDelegate? = nil)  {
        self.backgroundColor = .white
        self.selectionStyle = .none
        self.delegate = delegate
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        titleLabel.numberOfLines = 0
        titleLabel.lineBreakMode = .byWordWrapping
        titleLabel.text = title
        checkButton.isSelected = isSelected
        
        if isMultiSelectionEnabled {
            checkButton.setImage(UIImage(named: "unchecked"), for: .normal)
            checkButton.setImage(UIImage(named: "checked"), for: .selected)
        }
        else {
            checkButton.setImage(UIImage(named: "uncheckedcircle"), for: .normal)
            checkButton.setImage(UIImage(named: "checkedcircle"), for: .selected)
        }
    }
    
    @IBAction func checkButtonAction(_ sender: UIButton) {
        delegate?.buttonSelectAction(tag: self.tag, btn: sender)
    }
    
}
