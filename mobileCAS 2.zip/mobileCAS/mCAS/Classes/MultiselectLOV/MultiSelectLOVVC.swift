//
//  MultiSelectLOVVC.swift
//  mCAS
//
//  Created by Mac on 02/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

protocol MultiselectLOVDelegate {
    func setRespectiveCodeArray(list: [DropDown], masterType: MASTERTYPE?)
}

class MultiSelectLOVVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private var searchOptionArray: [DropDown] = []
    private var optionsArray: [DropDown] = []
    private var preSelectedArray: [String] = []
    private var masterType: MASTERTYPE?
    private var delegate: MultiselectLOVDelegate?
    private var isMultiSelectionEnabled = true
    
    private var offset = 0
    private var reachedEndOfItems = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        tableView.tableFooterView = UIView()
        
        searchBar.setProperties()
        
        if isMultiSelectionEnabled {
            buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Done", delegate: self)
        }
        else {
            buttonView.isHidden = true
        }
        
        if masterType == .Approver || masterType == .Recommender {
            
            if masterType == .Approver {
                offset = CommonRAData.shared().approverMasterModelArray.count
            }
            else {
                offset = CommonRAData.shared().recommenderMasterModelArray.count
            }
            
            if offset == 0 { fetchUsersByCriteria() }
            else { lazyLoadTableDataOffline() }
        }
        else if masterType == .ReasonToApprove || masterType == .ReasonToReject || masterType == .ReasonToInitiate {
            self.setTableData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        searchBar.resignFirstResponder()
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader()
        }
    }
    
    func setData(delegate: MultiselectLOVDelegate, masterType: MASTERTYPE?, preSelectedArray: [String], isMultiSelectionEnabled: Bool? = true) {
        self.delegate = delegate
        self.masterType = masterType
        self.preSelectedArray = preSelectedArray
        self.isMultiSelectionEnabled = isMultiSelectionEnabled!
    }
    
    private func lazyLoadTableDataOffline() {
        
        MRProgressOverlayView.showOverlayAdded(to: self.view, animated: true)
        
        var list: [RAModelClasses.User] = []
        let count = 30
        
        if masterType == .Approver {
            list = CommonRAData.shared().approverMasterModelArray
            CommonRAData.shared().approverMasterModelArray = Array(list[0..<min(count,list.count)])
        }
        else {
            list = CommonRAData.shared().recommenderMasterModelArray
            CommonRAData.shared().recommenderMasterModelArray = Array(list[0..<min(count,list.count)])
        }
        setTableData()
        
        if count < list.count {
            //Lazy load table data
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
                guard let self = self else {
                    return
                }
                
                DispatchQueue.main.async {
                    if self.masterType == .Approver {
                        list.removeSubrange(0...count)
                        CommonRAData.shared().approverMasterModelArray.append(contentsOf: list)
                    }
                    else {
                        list.removeSubrange(0...count)
                        CommonRAData.shared().recommenderMasterModelArray.append(contentsOf: list)
                    }
                    self.setTableData()
                }
            }
        }
        
        MRProgressOverlayView.dismissOverlay(for: self.view, animated: true)
    }
    
    private func fetchUsersByCriteria() {
        
        guard !reachedEndOfItems && (masterType == .Approver || masterType == .Recommender) else {
            return
        }
        
        var code = ""
        
        if masterType == .Approver {
            code = "MOB_WAIVER_APPROVER"
        }
        else if masterType == .Recommender {
            code = "MOB_WAIVER_RECOMMENDER"
        }
        
        let param = [["role" : code,
                      "pageInfo"  : ["requestPageSize"  : 50,
                                     "requestStartIndex" : offset]]]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_USERS_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let mainObj = responseObj as? [[String : AnyObject]], let response = mainObj.first {
                
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: RAModelClasses.MultiselectLOVUserModel.self) { list in
                    let masters = list.users ?? []
                    
                    if self.masterType == .Approver {
                        CommonRAData.shared().approverMasterModelArray.append(contentsOf: masters)
                    }
                    else if self.masterType == .Recommender {
                        CommonRAData.shared().recommenderMasterModelArray.append(contentsOf: masters)
                    }
                    
                    if let pageInfo = list.pageInfoVO, let pageSize = pageInfo.requestPageSize {
                        if masters.count < pageSize {
                            self.reachedEndOfItems = true
                        }
                        self.offset += pageSize
                    }
                    self.setTableData()
                }
            }
            
        }, failure: { (error) in
            
            if error == ServiceUrl.ALERT_NO_DATA {
                self.reachedEndOfItems = true
            }
            
        },
           noNetwork: { (error) in })
    }
    
    @objc private func setTableData() {
        
        if masterType == .Approver || masterType == .Recommender {
            var list: [RAModelClasses.User] = []
            
            if masterType == .Approver {
                list = CommonRAData.shared().approverMasterModelArray
            }
            else {
                list = CommonRAData.shared().recommenderMasterModelArray
            }
            
            if !optionsArray.isEmpty {
                list.removeSubrange(0...optionsArray.count)
            }
            
            for item in list {
                
                if let code = item.code, let fullName = item.fullName, code.lowercased() != AppDelegate.instance.getSavedUserID().lowercased() {
                    
                    let dd = DropDown(code: code, name: fullName, listDisplayValue: "\(fullName) (\(code))", isSelectedFlag: preSelectedArray.contains(code))
                    optionsArray.append(dd)
                }
            }
        }
        else if masterType == .ReasonToApprove || masterType == .ReasonToReject || masterType == .ReasonToInitiate {

            var subReasonFilter = ""
            
            if masterType == .ReasonToApprove {
                subReasonFilter = "APPROVE"
            }
            else if masterType == .ReasonToReject {
                subReasonFilter = "REJECT"
            }
            else {
                subReasonFilter = "Waiver Initiation"
            }
            
            for item in CommonRAData.shared().reasonMasterArray {
                
                if let code = item["code"], let name = item["name"], let masterType = item["masterType"] {
                    
                    if (masterType == subReasonFilter) || (masterType.lowercased() == "other") {
                        let dd = DropDown(code: code, name: name, isSelectedFlag: preSelectedArray.contains(code))
                        optionsArray.append(dd)
                    }
                }
            }
        }
        else {
            optionsArray = []
        }
        
        handleSearchResult()
        setHeaderAndDoneButton()
    }
    
    private func setHeaderAndDoneButton() {
        let filteredArray = optionsArray.filter { $0.isSelectedFlag == true }
        
        if let headerView = AppDelegate.instance.headerView, var title = masterType?.rawValue {
            
            if masterType == .ReasonToInitiate || masterType == .ReasonToApprove || masterType == .ReasonToReject {
                title = "Reason"
            }
            
            if filteredArray.isEmpty {
                headerView.showHideWhiteHeader(isHide: false, hideCloseButton: isMultiSelectionEnabled, line1: "Select \(title)(s)", line2: "")
            }
            else {
                headerView.showHideWhiteHeader(isHide: false, hideCloseButton: isMultiSelectionEnabled, line1: "Select \(title)(s)", line2: "\(filteredArray.count) selected")
            }
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: !filteredArray.isEmpty)
    }
}

extension MultiSelectLOVVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchOptionArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "LOVOptionCell") as! LOVOptionCell
        cell.tag = 1000+indexPath.row
        let dd = searchOptionArray[indexPath.row]
        
        cell.setProperties(title: dd.listDisplayValue, isSelected: dd.isSelectedFlag, isMultiSelectionEnabled: isMultiSelectionEnabled, delegate: self)
        
        // Check if the last row number is the same as the last current data element and user is not searching
        if indexPath.row == optionsArray.count - 1, searchBar.text?.count == 0 {
            fetchUsersByCriteria()
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}

extension MultiSelectLOVVC: LOVOptionCellDelegate {
    
    func buttonSelectAction(tag: NSInteger, btn: UIButton) {
        
        btn.isSelected = !btn.isSelected

        let searchDic = searchOptionArray[tag-1000]
        
        if isMultiSelectionEnabled {
            searchDic.isSelectedFlag = btn.isSelected
            searchOptionArray[tag-1000] = searchDic
            
            let index = optionsArray.firstIndex {$0.code == searchDic.code}
            
            if let index = index  {
                optionsArray[index] = searchDic
            }
            setHeaderAndDoneButton()
        }
        else {
            searchOptionArray = searchOptionArray.map { (dic) -> DropDown in
                dic.isSelectedFlag = (dic.code == searchDic.code)
                return dic
            }
            
            optionsArray = optionsArray.map { (dic) -> DropDown in
                dic.isSelectedFlag = (dic.code == searchDic.code)
                return dic
            }
            
            nextButtonAction()
        }
    }
}

extension MultiSelectLOVVC: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        handleSearchResult()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        handleSearchResult()
    }
    
    //on keyboard clear button this method is called
    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {
        handleSearchResult()
        return true
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        searchBar.resignFirstResponder()
        handleSearchResult()
    }
    
    private func handleSearchResult() {
        if let text = searchBar.text, !text.isEmpty {
            searchOptionArray = optionsArray.filter { ($0.listDisplayValue.lowercased().contains(text.lowercased())) }
        }
        else {
            searchOptionArray = optionsArray
        }
        
        tableView.reloadData()
    }
}

extension MultiSelectLOVVC: NextBackButtonDelegate {
    
    func nextButtonAction() {        
        let filteredArray = optionsArray.filter { $0.isSelectedFlag == true }
        delegate?.setRespectiveCodeArray(list: filteredArray, masterType: masterType)
        
        self.navigationController?.popViewController(animated: false)
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: false)
    }
    
}
