//
//  ChangePasswordVC.swift
//  mCAS
//
//  Created by Mac on 17/07/18.
//  Copyright © 2018 Nucleus. All rights reserved.
//

import UIKit

class ChangePasswordVC: UIViewController {
    
    @IBOutlet weak var staticLavel1: UILabel!
    @IBOutlet weak var staticLavel2: UILabel!
    
    @IBOutlet weak var oldPasswordView: CustomTextFieldView!
    @IBOutlet weak var nwPasswordView: CustomTextFieldView!
    @IBOutlet weak var confirmNwPasswordView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private var loaderOverlay: MRProgressOverlayView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        staticLavel1.font = CustomFont.shared().GETFONT_MEDIUM(24)
        staticLavel2.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        buttonView.setProperties(nextBtnTitle: "Change Password", delegate: self)
        oldPasswordView.setProperties(placeHolder: "Old Password", type: .Password, delegate: self)
        nwPasswordView.setProperties(placeHolder: "New Password", type: .Password, delegate: self)
        confirmNwPasswordView.setProperties(placeHolder: "Confirm Password", type: .Password, delegate: self)
        
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "Change Password", showBack: true)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "PasswordSentVC" {
            if let controller = segue.destination as? PasswordSentVC {
                controller.fromChangePassword = true
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches ,with: event)
        self.view.endEditing(true)
    }
    
    private func getTokenService()  {
        
        loaderOverlay = MRProgressOverlayView.showOverlayAdded(to: self.view, animated: true)
        loaderOverlay.titleLabelText = NSLocalizedString("Please wait...", comment:"")
        
        Webservices.shared().getTokenFromServer(withSession: true) { (token) in
            if let token = token {
                self.callChangePasswordService(token: token)
            }
            else {
                self.loaderOverlay.dismiss(true)
            }
        }
    }
    
    private func callChangePasswordService(token: String) {
        
        let oldPassword = oldPasswordView.getFieldValue()
        let nwPassword = nwPasswordView.getFieldValue()
        
        let encryptedPassword = Cipher.encrypt(oldPassword, withToken: token)
        let encryptednwPassword = Cipher.encrypt(nwPassword, withToken: token)
        let username = AppDelegate.instance.getSavedUserID()
        
        let param : [String:String] = ["username"       : username,
                                       "oldPassword"    : encryptedPassword,
                                       "password"       : encryptednwPassword]
        
        Webservices.shared().POST(urlString: ServiceUrl.CHANGE_PASSWORD_URL, paramaters: param, success: { (header ,responseObj) in
            
            Webservices.shared().logoutFromServer(username: username, allowOfflineAlert: false) { _ in }
            self.updateOfflineData(token: token, encryptedPassword: encryptednwPassword)
            
            self.loaderOverlay.dismiss(true)
            
            self.performSegue(withIdentifier: "PasswordSentVC", sender: nil)
            
        }, failure: { (error) in
            self.loaderOverlay.dismiss(true)
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            self.loaderOverlay.dismiss(true)
            
        })
    }
    
    func updateOfflineData(token: String, encryptedPassword: String) {
        
        //update old password and token for offline login
        if let userData = AppDelegate.instance.currentLoggedInUser {
            userData.encryptedpassword = encryptedPassword
            userData.token = token
            AppDelegate.instance.saveContext()
        }
    }
}

extension ChangePasswordVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        let oldPassword = oldPasswordView.getFieldValue()
        let nwPassword = nwPasswordView.getFieldValue()
        
        if let userData = AppDelegate.instance.currentLoggedInUser, let token = userData.token {
            let encryptedPassword = Cipher.encrypt(oldPassword, withToken: token)
            
            if userData.encryptedpassword != encryptedPassword {
                CommonAlert.shared().showAlert(message: NSLocalizedString("Invalid old password", comment: ""))
            }
            else if nwPassword == oldPassword {
                CommonAlert.shared().showAlert(message: NSLocalizedString("New password and old password can not be same", comment: ""))
            }
            else if nwPasswordView.getFieldValue() != confirmNwPasswordView.getFieldValue() {
                CommonAlert.shared().showAlert(message: NSLocalizedString("New password and confirm new password does not match", comment: ""))
            }
            else {
                self.getTokenService()
            }
        }
        else {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Please login again to change password", comment: ""))
        }
    }
}

extension ChangePasswordVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        if (oldPasswordView.getFieldValue().isEmpty || nwPasswordView.getFieldValue().isEmpty || confirmNwPasswordView.getFieldValue().isEmpty) {
            isEnabled = false
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
}
