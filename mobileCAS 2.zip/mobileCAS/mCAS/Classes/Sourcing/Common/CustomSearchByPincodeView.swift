//
//  CustomSearchByPincodeView.swift
//  mCAS
//
//  Created by iMac on 18/03/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol CSByPincodeDelegate {
    func CSBPValidation()
}
class CustomSearchByPincodeView: UIView {
    
    @IBOutlet var containerView: UIView!
    @IBOutlet weak var searchByPincodeButton: UIButton!
    @IBOutlet weak var searchByPincodeButtonHeight: NSLayoutConstraint!
    @IBOutlet weak var countryLOV: LOVFieldView!
    @IBOutlet weak var countryLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var stateLOV: LOVFieldView!
    @IBOutlet weak var stateLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var cityLOV: LOVFieldView!
    @IBOutlet weak var cityLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var pincodeView: CustomPincodeView!
    @IBOutlet weak var pincodeViewHeight: NSLayoutConstraint!
    
    private let TAG_COUNTRY             = 1001
    private let TAG_STATE               = 1002
    private let TAG_CITY                = 1003
    
    private(set) var selectedLOVDic: [String: DropDown] = [:]
    private var seachByPincodeView: SearchByPinCodeView!
    
    private var delegate: CSByPincodeDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomSearchByPincodeView", owner: self, options: nil)
        containerView.fixInView(self)
    }
    
    func setProperties(delegate: CSByPincodeDelegate) {
        
        self.delegate = delegate
        searchByPincodeButton.layer.masksToBounds = true
       
        SourcingCommonUtil.shared().setSearchByPincodeButtonProperties(btn: searchByPincodeButton)
        countryLOV.setLOVProperties(masterName: Entity.COUNTRY, title: "Country", tag: TAG_COUNTRY, delegate: self)
        stateLOV.setLOVProperties(masterName: Entity.STATE, title: "State", tag: TAG_STATE, delegate: self)
        cityLOV.setLOVProperties(masterName: Entity.CITY, title: "City", tag: TAG_CITY, delegate: self)
        pincodeView.setProperties(delegate: self)
    }
    
    @IBAction func searchByPincodeButtonAction(_ sender: Any) {
        
        if CommonUtils.shared().checkForReachabilityMode() {
            if self.seachByPincodeView == nil {
                let navArray = AppDelegate.instance.applicationNavController.viewControllers
                let lastVC = navArray.last
                self.seachByPincodeView = .fromNib()
                self.seachByPincodeView.setProperties(width: lastVC!.view.frame.size.width, height: lastVC!.view.frame.size.height, delegate: self)
                lastVC?.view.addSubview(self.seachByPincodeView)
            }
            self.seachByPincodeView.pincodeTextFieldView.setFieldValue()
            self.seachByPincodeView.alpha = 1
        }
    }
    
    func validateCSBPFields() -> Bool {
        var isEnabled = true
        if (selectedLOVDic["\(TAG_COUNTRY)"] == nil || selectedLOVDic["\(TAG_STATE)"] == nil || selectedLOVDic["\(TAG_CITY)"] == nil || pincodeView.getFieldValue().isEmpty) {
            
            isEnabled = false
        }
        return isEnabled
    }
    
    func getSelectedCountry() -> (String, String) {
        return (CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_COUNTRY)"]?.code), CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_COUNTRY)"]?.name))
    }

    func getSelectedState() -> (String, String) {
        return (CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_STATE)"]?.code), CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_STATE)"]?.name))
    }
    
    func getSelectedCity() -> (String, String) {
        return (CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_CITY)"]?.code), CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_CITY)"]?.name))
    }

    func getSelectedPincode() -> (String, String) {
        return (pincodeView.getFieldKeyValue(), pincodeView.getFieldValue())
    }
    
    func hideAllFields(isHide: Bool = true) {
        
        countryLOV.resetLOVWithParentKey()
        stateLOV.resetLOVWithParentKey()
        cityLOV.resetLOVWithParentKey()
        pincodeView.setFieldValue()
        
        searchByPincodeButtonHeight.constant = isHide ? 0 : 40
        countryLOVHeight.constant = isHide ? 0 : 65
        stateLOVHeight.constant = isHide ? 0 : 65
        cityLOVHeight.constant = isHide ? 0 : 65
        pincodeViewHeight.constant = isHide ? 0 : 65
    }
    
    func setAutoFillValues(countryKey: String? = nil, stateKey: String? = nil, cityKey: String? = nil, pincode: String = "") {
        countryLOV.autoFillLOVBy(key: countryKey)
        stateLOV.autoFillLOVBy(key: stateKey)
        cityLOV.autoFillLOVBy(key: cityKey)
        pincodeView.setFieldValue(text: pincode)
    }
}

extension CustomSearchByPincodeView: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        if btntag == TAG_COUNTRY {
            if let dd = selectedLOVDic["\(TAG_COUNTRY)"] {
                stateLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_STATE)"] = nil
                
                cityLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_CITY)"] = nil
                
                pincodeView.setFieldValue()
            }
        }
        else if btntag == TAG_STATE {
            if let dd = selectedLOVDic["\(TAG_STATE)"] {
                cityLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_CITY)"] = nil
                
                pincodeView.setFieldValue()
            }
        }
        else if btntag == TAG_CITY {
            if let dd = selectedLOVDic["\(TAG_CITY)"] {
                pincodeView.setCity(code: dd.code)
            }
        }
        delegate?.CSBPValidation()
    }
}

extension CustomSearchByPincodeView: CustomPincodeDelegate {
    func validatePincode() {
        delegate?.CSBPValidation()
    }
}

extension CustomSearchByPincodeView: SBPincodeDelegate {
    func getSelectedOption(countryCode: String, stateCode: String, cityCode: String, pincode: String) {
        
        countryLOV.autoFillLOVBy(key: countryCode)
        stateLOV.autoFillLOVBy(key: stateCode)
        cityLOV.autoFillLOVBy(key: cityCode)
        pincodeView.setFieldValue(text: pincode)
        delegate?.CSBPValidation()
    }
}
