//
//  SearchByPinCodeView.swift
//  mCAS
//
//  Created by iMac on 12/03/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol SBPincodeDelegate {
    func getSelectedOption(countryCode: String, stateCode: String, cityCode: String, pincode: String)
}

class SearchByPinCodeView: UIView {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var popupView: UIView!
    @IBOutlet weak var pincodeTextFieldView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private var delegate: SBPincodeDelegate?
    
    func setProperties(width: CGFloat, height: CGFloat, delegate: SBPincodeDelegate) {
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        
        // Do any additional setup after loading the view.
        self.delegate = delegate
        
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        
        closeButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(25)
        popupView.layer.cornerRadius = 8
        
        pincodeTextFieldView.setProperties(placeHolder: "Search by Pincode", type: .Number, delegate: self)
        buttonView.setProperties(nextBtnTitle: "Done", delegate: self)
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        self.alpha = 0
    }
    
}

extension SearchByPinCodeView: CustomTFViewDelegate {
    func validateFields() {
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: !pincodeTextFieldView.getFieldValue().isEmpty)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        return text.count <= 6
    }
}

extension SearchByPinCodeView: NextBackButtonDelegate {
    
    func nextButtonAction() {

        if pincodeTextFieldView.getFieldValue().count < 6 {
            CommonAlert.shared().showAlert(message: "Please enter valid pincode.")
            return
        }
        
        let param = ["zipcode" : pincodeTextFieldView.getFieldValue()]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_ALL_DETAILBYZIP_MASTER_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String: Any]
            {
                self.closeButton.sendActions(for: .touchUpInside)
                if let country = response["country"] as? [String: String], let state = response["state"] as? [String: String], let city = response["city"]  as? [String: String] {
                    self.delegate?.getSelectedOption(countryCode: CommonUtils.shared().getValidatedString(string: country["code"]), stateCode: CommonUtils.shared().getValidatedString(string: state["code"]), cityCode: CommonUtils.shared().getValidatedString(string: city["code"]), pincode: self.pincodeTextFieldView.getFieldValue())
                }
            }
            
        }, failure: { (error) in
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
        }, noNetwork: { (error) in
        })
        
    }
}
