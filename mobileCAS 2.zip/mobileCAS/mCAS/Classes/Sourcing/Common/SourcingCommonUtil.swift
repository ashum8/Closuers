//
//  SourcingCommonUtil.swift
//  mCAS
//
//  Created by Mac on 03/03/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

enum ApplicantType {
    case Individual
    case Corporate
}

class SourcingCommonUtil: NSObject {
    
    private static var instance: SourcingCommonUtil?
    let maxAmount           = 10000000.00
    let maxPercentage       = 100.00
    let maxQuantity         = 100
    let maxLimitEMIAmount   = 100000.00
    let maxLimitRate        = 100.00
    let maxLimitTenure      = 240

    private enum suffix: String {
        case th = "th"
        case st = "st"
        case nd = "nd"
        case rd = "rd"
    }
    
    static func shared() -> SourcingCommonUtil{
        if instance == nil {
            instance = SourcingCommonUtil()
        }
        return instance!
    }
    
    func generateApplicationID() -> String {
        //Fetch 30 digit applicationID
        return CommonUtils.shared().getDeviceID() + Date().timeStamp()
    }
    
    func generateCustomerID(tempAppID: String, isPrimary: Bool = false) -> String {
        
        if isPrimary {
            return tempAppID + "0001"
        }
        else {
            return tempAppID + Date().timeStamp().suffix(4)
        }
    }
    
    func getFormattedEmplyementMasterList(list: [SourcingModelClasses.EmploymentModel]) -> [DropDown] {
        
        return sortEmploymentBasedOnOccupationType(list: list).map({
            let model = $0
            var displayValue = ""
            var employerName = ""
            
            //There will be only for cases - SEP, SENP, Salaried, Others
            if model.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SAL.lowercased() {
                if let name = model.otherEmployerName, !name.isEmpty {
                    displayValue = name
                }
                else {
                    displayValue = displayValue + CommonUtils.shared().getValidatedString(string: model.employerName?.name)
                }
                employerName = displayValue
                displayValue = displayValue + " (\(CommonUtils.shared().getValidatedString(string: model.industry?.name)))"
            }
            else if model.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_OTH.lowercased() {
                employerName = CommonUtils.shared().getValidatedString(string: model.occupationType?.name)
                displayValue = CommonUtils.shared().getValidatedString(string: model.natureOfOccupation?.name)
            }
            else if model.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SENP.lowercased() {
                displayValue = CommonUtils.shared().getValidatedString(string: model.organizationName)
                employerName = displayValue
                displayValue = displayValue + " (\(CommonUtils.shared().getValidatedString(string: model.natureOfBusiness?.name)))"
            }
            else if model.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SEP.lowercased() {
                displayValue = CommonUtils.shared().getValidatedString(string: model.organizationName)
                employerName = displayValue
                displayValue = displayValue + " (\(CommonUtils.shared().getValidatedString(string: model.natureOfProfession?.name)))"
            }
            else {
                employerName = CommonUtils.shared().getValidatedString(string: model.employerName?.name)
                displayValue = CommonUtils.shared().getValidatedString(string: model.employerName?.name)
            }
            
            displayValue = displayValue + "\n\(CommonUtils.shared().getValidatedString(string: model.occupationType?.name))"
            
            return DropDown(id: CommonUtils.shared().getValidatedString(string: model.employmentId), code: CommonUtils.shared().getValidatedString(string: model.occupationType?.code), name: displayValue, lovDisplayValue: employerName)
        })
    }
    
    func setSearchByPincodeButtonProperties(btn: UIButton) {
        
        let attributedString = NSAttributedString(string: "Search by Pincode", attributes:[
            .font               : CustomFont.shared().GETFONT_MEDIUM(19),
            .foregroundColor    : Color.BLUE,
            .underlineStyle     : 1.0
        ])
        
        btn.setAttributedTitle(attributedString, for: .normal)
        btn.layer.masksToBounds = true
        btn.imageEdgeInsets = UIEdgeInsets(top: 10, left: 0, bottom: 0, right: 10)
        btn.titleEdgeInsets = UIEdgeInsets(top: 10, left: 0, bottom: 0, right: 5)
    }
    
    func getFormattedDay(day: String) -> String {
        var appendString = ""
        
        switch day {
        case "1", "21", "31" : appendString = suffix.st.rawValue
        case "2", "22": appendString = suffix.nd.rawValue
        case "3", "23": appendString = suffix.rd.rawValue
        default: appendString = suffix.th.rawValue
        }
        
        return "\(day)\(appendString)"
    }
    
    
    func sortEmploymentBasedOnOccupationType(list: [SourcingModelClasses.EmploymentModel]) -> [SourcingModelClasses.EmploymentModel] {
        
        return list.sorted(by: { (Obj1, Obj2) -> Bool in
            return (CommonUtils.shared().getValidatedString(string: Obj1.occupationType?.name).localizedCaseInsensitiveCompare(CommonUtils.shared().getValidatedString(string: Obj2.occupationType?.name)) == .orderedAscending)
        })
    }
}
