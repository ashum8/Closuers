//
//  SDOptionView.swift
//  mCAS
//
//  Created by iMac on 30/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

protocol SDOptionViewDelegate {
    func buttonAction(tag: Int)
}

class SDOptionView: UIView {
    
    @IBOutlet var containerView: UIView!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var progressLabel: UILabel!
    @IBOutlet weak var progressView: UIView!
    
    //SK Change
    @IBOutlet weak var buttonBottomMargin: NSLayoutConstraint!
    
    private var delegate: SDOptionViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("SDOptionView", owner: self, options: nil)
        containerView.fixInView(self)
    }
    
    func setProperties(title: String, image: String, delegate: SDOptionViewDelegate, tag: Int, removeBottomMargin: Bool = false) {
        
        self.setShadow()
        self.tag = tag
        self.delegate = delegate
        
        button.setTitle(title, for: .normal)
        button.setImage(UIImage(named: "\(image)_active"), for: .normal)
        button.setImage(UIImage(named: image), for: .disabled)
        button.setTitleColor(.darkGray, for: .normal)
        button.setTitleColor(.lightGray, for: .disabled)
        button.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(17)
        button.titleLabel?.numberOfLines = 2
        button.setAlignmentOfButton(isTab: false)
        
        progressLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        
        buttonBottomMargin.constant = removeBottomMargin ? 0 : 30
    }
    
    func setOptionEnable(isEnabled: Bool = true) {
        self.isUserInteractionEnabled = isEnabled
        button.isEnabled = isEnabled
    }
    
    func setProgress(color: UIColor = .clear, title: String = "") {
        progressView.backgroundColor = color
        progressLabel.textColor = color
        progressLabel.text = title
    }
    
    @IBAction func btnClicked(_ sender: Any) {
        delegate?.buttonAction(tag: self.tag)
    }
}
