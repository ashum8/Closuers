//
//  SourcingDashboardVC.swift
//  mCAS
//
//  Created by Ashutosh Mishra on 29/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class SourcingDashboardVC: UIViewController {
    
    @IBOutlet weak var addDetailView: SDOptionView!
    @IBOutlet weak var applicantDetailView: SDOptionView!
    @IBOutlet weak var addCollateralDetailView: SDOptionView!
    @IBOutlet weak var uploadDocumentView: SDOptionView!
    @IBOutlet weak var sideMenuView: SideMenuView!
    @IBOutlet weak var sideMenuLeftMargin: NSLayoutConstraint!
    @IBOutlet weak var sideMenuBGView: UIView!
    
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var titleLabel: UILabel!
    
    private var applicationType: DropDown!
    private var productCategory: LoanType!
    private var applicationID: String!
    private var modelData: SourcingModelClasses.SourcingModel?
    private var branchCode: String?
    private var productCode: String?
    
    private let addDetailTag = 100
    private let applicantDetailTag = 101
    private let collateralDetailTag = 102
    private let uploadDocumentTag = 103
    
    //Slider TableView Grid
    private let NEED_ANALYSIS               = "NEED_ANALYSIS"
    private let CHECKS_VERIFICATION         = "CHECKS_VERIFICATION"
    private let CHECK_ELIGIBILITY           = "CHECK_ELIGIBILITY"
    private let PERSONAL_DISCUSSION         = "PERSONAL_DISCUSSION"
    private let PROCESSING_FEES             = "PROCESSING_FEES"
    private let REFERENCE_DETAIL            = "REFERENCE_DETAIL"
    
    private var listModelArray = [ButtonModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            headerView.showHideStepHeader(isHide: false, landingPage: AppDelegate.instance.getSpecificVC(targetClass: SourcingListVC.self))
            bottomView.isHidden = true
        }
        
        handleCollateralOption()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader()
        }
    }
    
    func updateEditMode(branchCode: String, productCode: String) {
        self.branchCode = branchCode
        self.productCode = productCode
    }
    
    func setData(productCategory: LoanType, applicationType: DropDown, modelData: SourcingModelClasses.SourcingModel? = nil) {
        self.productCategory = productCategory
        self.applicationType = applicationType
        self.modelData = modelData
        
        if let modelData = modelData {
            self.branchCode = modelData.loanDetail?.branch?.code
            self.productCode = modelData.loanDetail?.product?.code
            self.applicationID = modelData.neutronReferenceNumber
        }
        else {
            self.applicationID = SourcingCommonUtil.shared().generateApplicationID()
        }
    }
    
    private func setupView() {
        
        setTableViewData()
        
        addDetailView.setProperties(title: "Loan Details", image: "sourcing_dashboard_loan_details", delegate: self, tag: addDetailTag)
        
        applicantDetailView.setProperties(title: "Applicant Details", image: "sourcing_dashboard_individual_icon", delegate: self, tag: applicantDetailTag)
        
        addCollateralDetailView.setProperties(title: "Add Collateral Detail", image: "sourcing_dashboard_collateral", delegate: self, tag: collateralDetailTag)
        
        uploadDocumentView.setProperties(title: "Upload Documents", image: "sourcing_dashboard_upload_doc", delegate: self, tag: uploadDocumentTag)
        uploadDocumentView.setOptionEnable(isEnabled: false)
        
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(22)
        
        buttonView.setProperties(nextBtnTitle: "Review and Submit", delegate: self)
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: true)
        
        sideMenuView.setProperties(delegate: self, arrList: listModelArray)
    }
    
    private func handleCollateralOption() {
        
        let productType = self.productCategory.code
        
        //If branch is available means loan details already filled
        if let branch = self.branchCode, !branch.isEmpty, productType != ConstantCodes.PRODUCT_TYPE_CC, productType != ConstantCodes.PRODUCT_TYPE_PF {
            addCollateralDetailView.setOptionEnable(isEnabled: true)
        }
        else {
            addCollateralDetailView.setOptionEnable(isEnabled: false)
        }
    }
    
    private func setTableViewData() {
        
        listModelArray.append(ButtonModel(buttonText: "Need Analysis", buttonID: NEED_ANALYSIS, buttonImage: "side_drawer_need_analysis", order: 1))
        
        listModelArray.append(ButtonModel(buttonText: "Checks and Verifications", buttonID: CHECKS_VERIFICATION, buttonImage: "side_drawer_checks_verification", order: 2))
        
        listModelArray.append(ButtonModel(buttonText: "Check Eligibility", buttonID: CHECK_ELIGIBILITY, buttonImage: "side_drawer_check_eligibility", order: 3))
        
        listModelArray.append(ButtonModel(buttonText: "Personal Discussion", buttonID: PERSONAL_DISCUSSION, buttonImage: "side_drawer_pd_discussion", order: 4))
        
        listModelArray.append(ButtonModel(buttonText: "Processing Fees", buttonID: PROCESSING_FEES, buttonImage: "side_drawer_processing_fees", order: 5))
        
        listModelArray.append(ButtonModel(buttonText: "Referance Detail", buttonID: REFERENCE_DETAIL, buttonImage: "side_drawer_reference_details", order: 6))
    }
}

extension SourcingDashboardVC: SDOptionViewDelegate {
    
    func buttonAction(tag: Int) {
        
        switch tag
        {
        case addDetailTag:
            let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "SourcingLoanDetailVC") as? SourcingLoanDetailVC {
                vc.setData(productCategory: self.productCategory, applicationType: self.applicationType, applicationID: self.applicationID, isEditMode: (self.branchCode != nil))
                self.navigationController?.pushViewController(vc, animated: true)
            }
            
        case applicantDetailTag:
            let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "ApplicantListVC") as? ApplicantListVC {
                vc.setData(productCategory: self.productCategory, applicationType: self.applicationType, applicationID: self.applicationID)
                self.navigationController?.pushViewController(vc, animated: true)
            }
            
        case collateralDetailTag:
            let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "CollateralListVC") as? CollateralListVC {
                vc.setData(productCategory: self.productCategory, applicationType: self.applicationType, applicationID: self.applicationID, branchCode: self.branchCode!, productCode: self.productCode!)
                self.navigationController?.pushViewController(vc, animated: true)
            }
            
        case uploadDocumentTag:
            print("upload document")
            
        default:
            break
        }
    }
}

extension SourcingDashboardVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "ReviewAndSignVC") as? ReviewAndSignVC {
            vc.setData(applicationId: self.applicationID)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension SourcingDashboardVC: SideMenuDelegate {
    
    func showHideSideMenu(button: UIButton) {
        button.isSelected = !button.isSelected
        
        self.sideMenuBGView.isHidden = !button.isSelected
        
        if button.isSelected {
            self.sideMenuLeftMargin.constant = 0
            UIView.animate(withDuration: 0.3) {
                self.view.layoutIfNeeded()
                self.sideMenuBGView.alpha = 0.5
            }
        }
        else {
            self.sideMenuLeftMargin.constant = 125
            UIView.animate(withDuration: 0.3) {
                self.view.layoutIfNeeded()
                self.sideMenuBGView.alpha = 0
            }
        }
    }
    
    func selectedSideMenuItem(index: Int, button: UIButton) {
        
        showHideSideMenu(button: button)
        
        let btnModel = listModelArray[index]
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
	switch btnModel.buttonID {
        case NEED_ANALYSIS:
            print("NEED_ANALYSIS")
            
        case CHECKS_VERIFICATION:
            print("CHECKS_VERIFICATION")
            
        case CHECK_ELIGIBILITY:
            print("CHECK_ELIGIBILITY")
            
        case PERSONAL_DISCUSSION:
            print("PERSONAL_DISCUSSION")
            
        case PROCESSING_FEES:
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "ProcessingFeesListVC") as? ProcessingFeesListVC {
                vc.setData(applicationID: applicationID)
                self.navigationController?.pushViewController(vc, animated: false)
            }
            
        case REFERENCE_DETAIL:
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "ReferenceDetailListVC") as? ReferenceDetailListVC {
                vc.setData(applicationID: applicationID)
                self.navigationController?.pushViewController(vc, animated: false)
            }
            
        default:
            break
        }
    }
}


/*
 
 mcas/master/notecode
 
 {"blockConfigCode":"NoteCodeMasterData"}
 
 {"noteCodes":[{"noteCodeProductTypes":null,"noteCode":"NoteCode","noteCodeId":5000062,"noteCodeDescription":"Note Code","noteCodeProducts":null},{"noteCodeProductTypes":[{"productTypeCode":"CON_VEH"},{"productTypeCode":"PF"},{"productTypeCode":"CL"},{"productTypeCode":"HL"},{"productTypeCode":"LAP"},{"productTypeCode":"CC"},{"productTypeCode":"CV"},{"productTypeCode":"MHL"},{"productTypeCode":"FE"},{"productTypeCode":"EDU"},{"productTypeCode":"AGRL"},{"productTypeCode":"KCC"},{"productTypeCode":"SHG"},{"productTypeCode":"JLG"},{"productTypeCode":"CEQ"},{"productTypeCode":"OMNI"},{"productTypeCode":"GL"},{"productTypeCode":"FAS"}],"noteCode":"XXMTNC","noteCodeId":5000180,"noteCodeDescription":"ok","noteCodeProducts":null},{"noteCodeProductTypes":[{"productTypeCode":"CON_VEH"},{"productTypeCode":"PF"},{"productTypeCode":"CL"},{"productTypeCode":"HL"},{"productTypeCode":"LAP"},{"productTypeCode":"CC"},{"productTypeCode":"CV"},{"productTypeCode":"MHL"},{"productTypeCode":"FE"},{"productTypeCode":"EDU"},{"productTypeCode":"AGRL"},{"productTypeCode":"KCC"},{"productTypeCode":"SHG"},{"productTypeCode":"JLG"},{"productTypeCode":"CEQ"},{"productTypeCode":"OMNI"},{"productTypeCode":"GL"},{"productTypeCode":"FAS"}],"noteCode":"test","noteCodeId":5000000,"noteCodeDescription":"test","noteCodeProducts":[{"productCode":"ABL"},{"productCode":"AAL"},{"productCode":"AL_VAP_Q"},{"productCode":"AL_LEASE"},{"productCode":"LEASE_CV"},{"productCode":"MUL_A_VA"},{"productCode":"MUL_AUTO"},{"productCode":"RAL"},{"productCode":"RMC"},{"productCode":"WP_CAR"},{"productCode":"AHL"},{"productCode":"AHL_Mult"},{"productCode":"AHV"},{"productCode":"HL_LIMIT"},{"productCode":"HL_OD"},{"productCode":"RHL"},{"productCode":"WP_HL"},{"productCode":"GOLD"},{"productCode":"CORP_CC"},{"productCode":"japncard"},{"productCode":"Po_Colla"},{"productCode":"Pl_Colla"},{"productCode":"PL_COLMU"},{"productCode":"PL_VAP_Q"},{"productCode":"PL_Limit"},{"productCode":"PL_OD"},{"productCode":"PL"},{"productCode":"PLDT"},{"productCode":"PL_Multi"},{"productCode":"SPL"},{"productCode":"CDMAV"},{"productCode":"CDL"},{"productCode":"CDMA"},{"productCode":"CDLV"},{"productCode":"M_VAP_Q"},{"productCode":"MBD"},{"productCode":"MBC"},{"productCode":"MHL"},{"productCode":"MAD"},{"productCode":"MUL"},{"productCode":"ACP"},{"productCode":"ACC"},{"productCode":"BLAIBMOR"},{"productCode":"BL_VAP_Q"},{"productCode":"ACVDW"},{"productCode":"CV_VAP_Q"},{"productCode":"Mul_CV_V"},{"productCode":"CV_LEASE"},{"productCode":"MUL_CV"},{"productCode":"RCV"},{"productCode":"RCC"},{"productCode":"TMAV"},{"productCode":"FE_LEASE"},{"productCode":"TRL"},{"productCode":"TRLVAPQC"},{"productCode":"TMA"},{"productCode":"EDU"},{"productCode":"EDU_USD"},{"productCode":"Test"},{"productCode":"Agri_Uns"},{"productCode":"Agri_Sec"},{"productCode":"KCC_ST"},{"productCode":"KCC_Plus"},{"productCode":"KCC"},{"productCode":"SHG"},{"productCode":"JLG_Secu"},{"productCode":"JLG"},{"productCode":"CEQ"},{"productCode":"CEQMulC"},{"productCode":"CEQVAP"},{"productCode":"CEQMULTD"},{"productCode":"OMNIHLPL"},{"productCode":"OmniNeo"},{"productCode":"Omni_VAP"},{"productCode":"GL_OD"},{"productCode":"GL"},{"productCode":"FASTest"},{"productCode":"FAS"}]},{"noteCodeProductTypes":null,"noteCode":"CMSNote_01","noteCodeId":5000080,"noteCodeDescription":"CMSNoteCode","noteCodeProducts":null},{"noteCodeProductTypes":[{"productTypeCode":"CON_VEH"},{"productTypeCode":"PF"},{"productTypeCode":"CL"},{"productTypeCode":"HL"},{"productTypeCode":"LAP"},{"productTypeCode":"CC"},{"productTypeCode":"CV"},{"productTypeCode":"MHL"},{"productTypeCode":"FE"},{"productTypeCode":"EDU"},{"productTypeCode":"AGRL"},{"productTypeCode":"KCC"},{"productTypeCode":"SHG"},{"productTypeCode":"JLG"},{"productTypeCode":"CEQ"},{"productTypeCode":"OMNI"},{"productTypeCode":"GL"},{"productTypeCode":"FAS"}],"noteCode":"oRfcNC","noteCodeId":5000100,"noteCodeDescription":"ok","noteCodeProducts":null},{"noteCodeProductTypes":[{"productTypeCode":"CON_VEH"},{"productTypeCode":"PF"},{"productTypeCode":"CL"},{"productTypeCode":"HL"},{"productTypeCode":"LAP"},{"productTypeCode":"CC"},{"productTypeCode":"CV"},{"productTypeCode":"MHL"},{"productTypeCode":"FE"},{"productTypeCode":"EDU"},{"productTypeCode":"AGRL"},{"productTypeCode":"KCC"},{"productTypeCode":"SHG"},{"productTypeCode":"JLG"},{"productTypeCode":"CEQ"},{"productTypeCode":"OMNI"},{"productTypeCode":"GL"},{"productTypeCode":"FAS"}],"noteCode":"VCkUNC","noteCodeId":5000020,"noteCodeDescription":"ok","noteCodeProducts":null},{"noteCodeProductTypes":null,"noteCode":"test1","noteCodeId":5000120,"noteCodeDescription":"test1","noteCodeProducts":null},{"noteCodeProductTypes":[{"productTypeCode":"CON_VEH"},{"productTypeCode":"PF"},{"productTypeCode":"CL"},{"productTypeCode":"HL"},{"productTypeCode":"LAP"},{"productTypeCode":"CC"},{"productTypeCode":"CV"},{"productTypeCode":"MHL"},{"productTypeCode":"FE"},{"productTypeCode":"EDU"},{"productTypeCode":"AGRL"},{"productTypeCode":"KCC"},{"productTypeCode":"SHG"},{"productTypeCode":"JLG"},{"productTypeCode":"CEQ"},{"productTypeCode":"OMNI"},{"productTypeCode":"GL"},{"productTypeCode":"FAS"}],"noteCode":"RHMcNC","noteCodeId":5000160,"noteCodeDescription":"ok","noteCodeProducts":null}]}
 
 
 
 
 
 
 
 
 
 mcas/personaldiscussion/getform
 
 {"productType":"FE"}
 
 {"name":"ModelPDForm_FE","screenId":"PDForm_FE","forms":[{"code":"0First Member","name":"first","fields":[{"name":"name1","label":"Name:","maxLength":"50","fieldId":"name1","fieldType":"TEXT","dataType":"AN","mandatory":false,"readonly":false,"visible":false},{"name":"Field001","label":"messages","maxLength":"5","fieldId":"Field001","fieldType":"TEXT","dataType":"NUMBER","mandatory":false,"readonly":false,"visible":false},{"name":"Field_numdec","label":"messages","maxLength":"10","fieldId":"Field_numdec","fieldType":"TEXT","dataType":"ND","mandatory":false,"readonly":false,"visible":false}],"label":"first","type":"PANEL"},{"code":"13 first","name":"3_first","fields":[{"mandatory":false,"readonly":false,"visible":true,"subForm":{"fields":[{"name":"name","label":"Name:","maxLength":"50","fieldId":"name","fieldType":"TEXT","dataType":"AN","mandatory":false,"readonly":false,"visible":false},{"name":"dropDown_1","label":"dropDown_1","fieldId":"dropDown_1","fieldType":"DROPDOWN","dataType":"AN","mandatory":false,"readonly":false,"dropDownFields":[{"code":"value","name":"name"},{"code":"value1","name":"name1"}],"visible":false}]}}],"label":"3_first","type":"MULTI_ENTRY"},{"code":"2","fields":[{"name":"dateOfBirth","label":"Date Of Birth","fieldId":"dateOfBirth","fieldType":"CALENDER","dataType":"AN","mandatory":false,"readonly":false,"visible":false}],"type":"PANEL"}]}
 
 
 
 mcas/personaldiscussion/saveform
 
 {"tempApplicationId":"759891003191372331584004268618","fields":[{"fieldId":"name1","value":"uwjsbsvsbbsbsbsbbsbsbbsbsbsb ;;*;;*;*;*;++#+2+))((","formId":"first","dataType":"AN","fieldType":"TEXT"},{"fieldId":"Field001","value":"95988","formId":"first","dataType":"NUMBER","fieldType":"TEXT"},{"fieldId":"Field_numdec","value":"9598588484","formId":"first","dataType":"ND","fieldType":"TEXT"},{"fieldId":"13 first","value":"[[{\"fieldId\":\"name\",\"value\":\"sec\",\"dataType\":\"AN\",\"fieldType\":\"TEXT\"},{\"fieldId\":\"dropDown_1\",\"value\":\"value1\",\"dataType\":\"AN\",\"fieldType\":\"DROPDOWN\"}],[{\"fieldId\":\"name\",\"value\":\"tg\",\"dataType\":\"AN\",\"fieldType\":\"TEXT\"},{\"fieldId\":\"dropDown_1\",\"value\":\"value\",\"dataType\":\"AN\",\"fieldType\":\"DROPDOWN\"}],[{\"fieldId\":\"name\",\"value\":\"sec\",\"dataType\":\"AN\",\"fieldType\":\"TEXT\"},{\"fieldId\":\"dropDown_1\",\"value\":\"value1\",\"dataType\":\"AN\",\"fieldType\":\"DROPDOWN\"}]]","formId":"3_first","dataType":"","fieldType":"MULTI_ENTRY"},{"fieldId":"dateOfBirth","value":"2020-03-21","formId":"","dataType":"AN","fieldType":"CALENDER"}]}
 
 {"type":"SYSTEM","cause":"EXCEPTION"}
 
 
 
 
 mcas/needanalysis/getform
 
 {"productType":"HL"}
 
 {"screenId":"NeedAnalysis","forms":[{"name":"NeedQue2","fields":[{"code":"Q01","label":"How much money do you need?","fieldType":"NUMERIC_DECIMAL","neoFieldType":"AMOUNT","mandatory":false,"readonly":false,"visible":true},{"code":"Q02","label":"How will you repay the loan? .","fieldType":"TEXT","neoFieldType":"TEXT","mandatory":false,"readonly":false,"visible":true},{"code":"Q03","label":"Can you put up any collateral?","fieldType":"DROPDOWN","neoFieldType":"BOOLEAN","mandatory":false,"readonly":false,"dropDownFields":[{"code":"true","name":"true"},{"code":"false","name":"false"}],"visible":true},{"code":"Q06","label":"This is header","fieldType":"HEADING","neoFieldType":"HEADER","mandatory":false,"readonly":false,"visible":true},{"code":"Q05","label":"When is the repayment date","fieldType":"CALENDER","neoFieldType":"DATE","mandatory":false,"readonly":false,"futureDateAllowed":true,"visible":true},{"code":"Q04","label":"How will you repay the loan?","fieldType":"DROPDOWN","neoFieldType":"CUSTOM_LOV","mandatory":false,"readonly":false,"dropDownFields":[{"code":"CHEQUE","name":"cheque"},{"code":"CASH","name":"cash"}],"visible":true}],"label":"NeedQue2","referenceType":"GROUP_LEVEL"}]}
 
 {"type":"VALIDATION","cause":"EXCEPTION","errorEntries":[{"errorCode":"FORM_NOT_FOUND","errorMessage":"Form maintenance is Missing"}]}
 
 
 
 
 mcas/needanalysis/getdata
 
 {"neutronReferenceNumber":"320187449441200312032020112423"}
 
 {"forms":{"forms":[{"fields":[{"code":"Q02","value":"vdvvd","mandatory":false,"readonly":false,"visible":true},{"code":"Q01","value":"9499","mandatory":false,"readonly":false,"visible":true},{"code":"Q04","value":"CHEQUE","mandatory":false,"readonly":false,"visible":true},{"code":"Q03","value":"false","mandatory":false,"readonly":false,"visible":true},{"code":"Q05","value":"2020-03-21","mandatory":false,"readonly":false,"visible":true}]}]}}
 
 
 
 mcas/needanalysis/saveform
 
 {"neutronReferenceNumber":"320187449441200312032020112423","forms":{"forms":[{"fields":[{"code":"Q02","value":"vdvvd","neoFieldType":"TEXT"},{"code":"Q01","value":"9499","neoFieldType":"AMOUNT"},{"code":"Q04","value":"CHEQUE","neoFieldType":"CUSTOM_LOV"},{"code":"Q03","value":"false","neoFieldType":"BOOLEAN"},{"code":"Q05","value":"2020-03-21","neoFieldType":"DATE"}]}]}}
 
 {"completed":true}
 
 
 
 
 
 
 */
