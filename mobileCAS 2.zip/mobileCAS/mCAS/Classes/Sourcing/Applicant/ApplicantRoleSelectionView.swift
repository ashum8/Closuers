//
//  ApplicantRoleSelectionView.swift
//  mCAS
//
//  Created by iMac on 06/03/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol ApplicantRoleDelegate {
    func setSelectedApplicant(role: String)
}

class ApplicantRoleSelectionView: UIView {
    
    @IBOutlet weak var closeButton: UIButton!
    
    @IBOutlet weak var guarantorButton: UIButton!
    @IBOutlet weak var guarantorLabel: UILabel!
    
    @IBOutlet weak var coApplicantButton: UIButton!
    @IBOutlet weak var coApplicantLabel: UILabel!
    
    private var delegate: ApplicantRoleDelegate?
    
    
    func setProperties(width: CGFloat, height: CGFloat, delegate: ApplicantRoleDelegate) {
        
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        
        closeButton.setPlusButtonProperties()
        closeButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(32)
        
        setButtonProperty(btn: guarantorButton)
        setButtonProperty(btn: coApplicantButton)
        
        guarantorLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        coApplicantLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        
        self.delegate = delegate
    }
    
    private func setButtonProperty(btn: UIButton) {
        btn.layer.cornerRadius = 20
        btn.backgroundColor = Color.BLUE
        btn.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(30)
        btn.setButtonShadow()
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        self.alpha = 0
    }
    
    @IBAction func guarantorButtonAction(_ sender: Any) {
        delegate?.setSelectedApplicant(role: Constants.APPLICANT_ROLE_CODE_GUARANTOR)
        closeButton.sendActions(for: .touchUpInside)
    }
    
    @IBAction func coApplicantButtonAction(_ sender: Any) {
        delegate?.setSelectedApplicant(role: Constants.APPLICANT_ROLE_CODE_COAPPL)
        closeButton.sendActions(for: .touchUpInside)
    }
}
