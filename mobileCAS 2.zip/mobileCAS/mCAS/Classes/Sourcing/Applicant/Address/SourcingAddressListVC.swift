//
//  SourcingAddressListVC.swift
//  mCAS
//
//  Created by iMac on 24/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class SourcingAddressListVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var headerTitleView: SourcingTitleView!
    @IBOutlet weak var addressTypeView: UIView!
    @IBOutlet weak var correspondenceAddrButton: UIButton!
    @IBOutlet weak var permanentAddrButton: UIButton!
    @IBOutlet weak var officeAddrButton: UIButton!
    
    private enum DetailOptions: String {
        case edit = "Edit"
        case delete = "Delete"
    }
    
    private var addressListModelArray = [SourcingModelClasses.AddressModel]()
    private var cellOptionArray: [DetailOptions] = [.edit, .delete]
    
    private var customerType: ApplicantType!
    private var applicationID: String!
    private var customerID: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
        fetchList()
    }
    
    private func setupView() {
        
        tableView.register(UINib(nibName: "SourcingAddressTVCell", bundle: nil), forCellReuseIdentifier: "SourcingAddressTVCell")
        tableView.tableFooterView = UIView()
        
        headerTitleView.setProperties(title: "Address")
        
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties(title: "Current Permanent and Office Address is required.")
        
        correspondenceAddrButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(17)
        permanentAddrButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(17)
        officeAddrButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(17)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader(isHide: false, title: "Add Applicant")
        }
    }
    
    private func setListData() {
        tableView.isHidden = addressListModelArray.isEmpty
        addressTypeView.isHidden = addressListModelArray.isEmpty
        noDataCapturedView.isHidden = !tableView.isHidden
        self.tableView.reloadData()
        
        buttonView.setProperties(showBack: true, nextBtnTitle: self.addressListModelArray.isEmpty ? "Skip" : "Continue", delegate: self)
        
        if !addressTypeView.isHidden {
            correspondenceAddrButton.isSelected = !addressListModelArray.filter({ $0.communicationAddress == true}).isEmpty
            
            permanentAddrButton.isSelected = !addressListModelArray.filter({ $0.sameAsPermanentAddr == true || $0.addressType?.code?.lowercased() == ConstantCodes.ADDRESS_TYPE_PERM.lowercased()}).isEmpty
            
            officeAddrButton.isSelected = !addressListModelArray.filter({ $0.sameAsOfficeAddr == true}).isEmpty
        }
    }
    
    func setData(type: ApplicantType, applicationID: String, customerID: String) {
        self.customerType = type
        self.applicationID = applicationID
        self.customerID = customerID
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        moveToAddAddress()
    }
    
    func fetchList() {
        
        let param = ["neutronCustRefNumber" : customerID]
        
        addressListModelArray.removeAll()
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_ALL_ADDRESS_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [[String: Any]]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: [SourcingModelClasses.AddressModel].self) { list in
                    self.addressListModelArray.append(contentsOf: list)
                }
            }
            self.setListData()
            
        }, failure: { (error) in
            
            self.setListData()
            
        }, noNetwork: { (error) in
            self.setListData()
        })
    }
    
    private func moveToAddAddress(index: Int? = nil) {
        var data: SourcingModelClasses.AddressModel?
        
        if let index = index {
            data = addressListModelArray[index]
        }
        
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "AddAddressVC") as? AddAddressVC {
            vc.setData(applicationID: applicationID, customerID: customerID, dataObj: data)
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
    
    private func deleteDataRow(index: Int) {
        
        let param = ["neutronReferenceNumber"                : applicationID,
                     "neutronCustRefNumber"                  : customerID,
                     "neutronAddressId"                      : addressListModelArray[index].neutronAddressId]
        
        Webservices.shared().POST(urlString: ServiceUrl.DELETE_ADDRESS_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                self.addressListModelArray.remove(at: index)
                self.setListData()
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
}

extension SourcingAddressListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return addressListModelArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let model = addressListModelArray[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SourcingAddressTVCell", for: indexPath) as! SourcingAddressTVCell
        cell.setProperties(optionArray: cellOptionArray.map({ $0.rawValue }), cellIndex: indexPath.row, delegate: self, showStatus: true)
        cell.label1.text = model.addressType?.name
        cell.label2.text = model.getFullAddress()
        
        cell.tag1.removeStatusLabelProperties()
        cell.tag2.removeStatusLabelProperties()
        cell.tag3.removeStatusLabelProperties()
        cell.tag4.removeStatusLabelProperties()
        
        var tagArr = [cell.tag1, cell.tag2, cell.tag3 ,cell.tag4]
        for lbl in tagArr {
            lbl?.text = ""
        }
        if model.sameAsPermanentAddr ?? false {
            tagArr[0]?.text = "PERMANENT"
            tagArr[0]?.setStatusLabelProperties(borderColor: Color.SKY_BLUE)
            tagArr.remove(at: 0)
        }
        if model.communicationAddress ?? false{  
            tagArr[0]?.text = "CORRESPONDENCE"
            tagArr[0]?.setStatusLabelProperties(borderColor: Color.SKY_BLUE)
            tagArr.remove(at: 0)
        }
        if model.sameAsOfficeAddr ?? false{
            tagArr[0]?.text = "OFFICE"
            tagArr[0]?.setStatusLabelProperties(borderColor: Color.SKY_BLUE)
            tagArr.remove(at: 0)
        }
        if model.sameAsResidentialAddr ?? false{
            tagArr[0]?.text = "RESIDENTIAL"
            tagArr[0]?.setStatusLabelProperties(borderColor: Color.SKY_BLUE)
            tagArr.remove(at: 0)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        moveToAddAddress(index: indexPath.row)
    }
}

extension SourcingAddressListVC : NextBackButtonDelegate {
    func nextButtonAction() {
        
        if !addressListModelArray.isEmpty, correspondenceAddrButton.isSelected == false {
            CommonAlert.shared().showAlert(message: "Please mark one address as correspondence address.")
            return
        }
        if customerType == .Corporate {
            if let obj = AppDelegate.instance.getSpecificVC(targetClass: ApplicantListVC.self) as? ApplicantListVC {
                AppDelegate.instance.applicationNavController.popToViewController(obj, animated: true)
            }
        }
        else {
            let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = st.instantiateViewController(withIdentifier: "IncomeListVC") as? IncomeListVC {
                vc.setData(applicationID: applicationID, customerID: customerID)
                AppDelegate.instance.applicationNavController.pushViewController(vc, animated: true)
            }
        }
        
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension SourcingAddressListVC : AddressListCellDelegate {
    func selectedIndex(index: Int, cellIndex: Int) {
        let item = self.cellOptionArray[index]
        if item == .edit {
            moveToAddAddress(index: cellIndex)
        }
        else if item == .delete {
            CommonAlert.shared().showAlert(message: "Are you sure you want to delete address details?", cancelTitle: "Cancel" , okAction: { _ in
                self.deleteDataRow(index: cellIndex)
            })
        }
    }
}
