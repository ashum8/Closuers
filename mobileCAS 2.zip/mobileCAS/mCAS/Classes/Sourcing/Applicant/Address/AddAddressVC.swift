//
//  AddAddressVC.swift
//  mCAS
//
//  Created by iMac on 27/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddAddressVC: UIViewController {
    
    @IBOutlet weak var addressTypeLOV: LOVFieldView!
    @IBOutlet weak var residenceStatusLOV: LOVFieldView!
    @IBOutlet weak var residenceLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var addressL1View: CustomTextFieldView!
    @IBOutlet weak var addressL2View: CustomTextFieldView!
    @IBOutlet weak var addressL3View: CustomTextFieldView!
    @IBOutlet weak var landmarkView: CustomTextFieldView!
    @IBOutlet weak var checkBoxButton: UIButton!
    @IBOutlet weak var residenceTypeLOV: LOVFieldView!
    @IBOutlet weak var residenceTypeLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var documentRefView: LOVFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var addressDurationView: DurationView!
    @IBOutlet weak var cityDurationView: DurationView!
    @IBOutlet weak var currentLocationButton: UIButton!
    @IBOutlet weak var sameAsTitleLabel: UILabel!
    @IBOutlet weak var sameAsButton1: UIButton!
    @IBOutlet weak var sameAsButton2: UIButton!
    @IBOutlet weak var searchByPincodeView: CustomSearchByPincodeView!
    
    @IBOutlet weak var sameAsAddressView: UIView!
    @IBOutlet weak var sameAsAddressViewHeight: NSLayoutConstraint!
    
    private let TAG_ADDRESS = 1000
    private let TAG_DOCUMENT = 1004
    private let TAG_RESIDENCE = 1005
    private let TAG_RESIDENCE_TYPE = 1006
    
    private let TAG_ADDRESS_LANDMARK = 1006
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var applicationID: String!
    private var customerID: String!
    private var dataObj: SourcingModelClasses.AddressModel!
    private var seachByPincodeView: SearchByPinCodeView!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    private func setupView() {
        
        addressTypeLOV.setLOVProperties(masterName: Entity.ADDTYPE, title: "Address Type", tag: TAG_ADDRESS, delegate: self)
        residenceStatusLOV.setLOVProperties(masterName: Entity.RESTYP, title: "Residence Status", tag: TAG_RESIDENCE, delegate: self)
//        documentRefView.setLOVProperties(masterName: Entity.CITY, title: "Document Refered", tag: TAG_DOCUMENT, delegate: self, enable: false)
        residenceTypeLOV.setLOVProperties(masterName: Entity.RESIDENCETYPE, title: "Residence Type", tag: TAG_RESIDENCE_TYPE, delegate: self)
        
        addressL1View.setProperties(placeHolder: "Address Line 1", delegate: self, tag: TAG_ADDRESS_LANDMARK)
        addressL2View.setProperties(placeHolder: "Address Line 2 (Optional)", delegate: self, tag: TAG_ADDRESS_LANDMARK)
        addressL3View.setProperties(placeHolder: "Address Line 3 (Optional)", delegate: self, tag: TAG_ADDRESS_LANDMARK)
        landmarkView.setProperties(placeHolder: "Landmark", delegate: self, tag: TAG_ADDRESS_LANDMARK)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        checkBoxButton.setCheckboxProperties(title: "Use this as correspondence address", isSelected: false)
        
        addressDurationView.setProperties(title: "Duration at Current Address", delegate: self)
        cityDurationView.setProperties(title: "Duration at Current City", delegate: self)
        
        setLocationButtonProperties()
        
        sameAsTitleLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        sameAsButton1.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        sameAsButton2.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        sameAsAddressView.layer.masksToBounds = true
        
        searchByPincodeView.setProperties(delegate: self)
        
        fillDataInEditMode(dataObj: dataObj)
    }    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Address")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader()
        }
    }
    
    func setData(applicationID: String, customerID: String, dataObj: SourcingModelClasses.AddressModel? = nil) {
        self.applicationID = applicationID
        self.customerID = customerID
        self.dataObj = dataObj
    }
    
    @IBAction func checkBoxButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }

    @IBAction func currentLocationButtonAction(_ sender: Any) {
        addressL1View.setFieldValue(text: AppDelegate.instance.gpsDictionary["addressLineOne"])
        addressL2View.setFieldValue(text: AppDelegate.instance.gpsDictionary["addressLineTwo"])
        searchByPincodeView.countryLOV.autoFillLOVBy(value: AppDelegate.instance.gpsDictionary["country"])
        searchByPincodeView.stateLOV.autoFillLOVBy(value: AppDelegate.instance.gpsDictionary["state"])
        searchByPincodeView.cityLOV.autoFillLOVBy(value: AppDelegate.instance.gpsDictionary["city"])
        searchByPincodeView.pincodeView.setFieldValue(text: AppDelegate.instance.gpsDictionary["pincode"])

        validateFields()
    }
    
    private func setLocationButtonProperties() {
        currentLocationButton.setCornerRadius()
        currentLocationButton.layer.borderWidth = 1
        currentLocationButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(18)
        currentLocationButton.setTitleColor(Color.BLUE, for: .normal)
        currentLocationButton.layer.borderColor = Color.BLUE.cgColor
        currentLocationButton.backgroundColor = .white
    }
    
    @IBAction func sameAsButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    private func fillDataInEditMode(dataObj: SourcingModelClasses.AddressModel?) {
        
        if let data = dataObj {
            addressTypeLOV.autoFillLOVBy(key: data.addressType?.code)
            addressTypeLOV.enableLOV(isEnable: false)
            
            residenceStatusLOV.autoFillLOVBy(key: data.residentialStatus?.code)
            
            residenceTypeLOV.autoFillLOVBy(key: data.residenceType?.code)
            
            addressL1View.setFieldValue(text: data.unit)
            addressL2View.setFieldValue(text: data.streetNo)
            addressL3View.setFieldValue(text: data.streetName)
            landmarkView.setFieldValue(text: data.landmark)
        
            searchByPincodeView.setAutoFillValues(countryKey: data.country?.code, stateKey: data.state?.code, cityKey: data.city?.code, pincode: CommonUtils.shared().getValidatedString(string:data.postalCode?.name))
            
            checkBoxButton.isSelected = data.communicationAddress ?? false
            
            if let year = data.numberOfYearsAtAddress, let month = data.numberOfMonthsAtAddress {
                addressDurationView.setFieldValue(year: "\(year)", month: "\(month)")
            }
            
            if let year = data.numberOfYearsAtCity, let month = data.numberOfMonthsAtCity {
                cityDurationView.setFieldValue(year: "\(year)", month: "\(month)")
            }
            
            if data.addressType?.code?.lowercased() == ConstantCodes.ADDRESS_TYPE_PERM.lowercased() {
                sameAsButton1.isSelected = data.sameAsOfficeAddr ?? false
                sameAsButton2.isSelected = data.sameAsResidentialAddr ?? false
            }
            else if data.addressType?.code?.lowercased() == ConstantCodes.ADDRESS_TYPE_RES.lowercased() {
                sameAsButton1.isSelected = data.sameAsPermanentAddr ?? false
                sameAsButton2.isSelected = data.sameAsOfficeAddr ?? false
            }
            else {
                sameAsButton1.isSelected = data.sameAsOfficeAddr ?? false
            }
            
            buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Update", delegate: self)
        }
        validateFields()
    }
    
    
    private func refreshFieldData() {
        residenceStatusLOV.resetLOVWithParentKey(key: "")
        residenceTypeLOV.resetLOVWithParentKey(key: "")
        selectedLOVDic["\(TAG_RESIDENCE)"] = nil
        selectedLOVDic["\(TAG_RESIDENCE_TYPE)"] = nil
    }
    
}

extension AddAddressVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        if (selectedLOVDic["\(TAG_ADDRESS)"] == nil || addressL1View.getFieldValue().isEmpty || landmarkView.getFieldValue().isEmpty  || addressDurationView.yearView.getFieldValue().isEmpty || addressDurationView.monthView.getFieldValue().isEmpty || cityDurationView.yearView.getFieldValue().isEmpty || cityDurationView.monthView.getFieldValue().isEmpty) {
            
            isEnabled = false
        }
        
        isEnabled = isEnabled && searchByPincodeView.validateCSBPFields()
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_ADDRESS_LANDMARK:
            return text.validateStringWithRegex(regx: "^[A-Z-a-z0-9,.() #@$*%-_\\/:?]{1,40}$")
        default:
            return true
        }
    }
}

extension AddAddressVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_ADDRESS {
            
            switch selectedObj.code {
                
            case ConstantCodes.ADDRESS_TYPE_PERM:
                residenceLOVHeight.constant = 65
                sameAsAddressViewHeight.constant = 86
                residenceTypeLOVHeight.constant = 65
                sameAsButton2.isHidden = false
                sameAsButton1.setCheckboxProperties(title: "Office")
                sameAsButton2.setCheckboxProperties(title: "Residence")
                
            case ConstantCodes.ADDRESS_TYPE_OFC:
                residenceLOVHeight.constant = 0
                sameAsAddressViewHeight.constant = 0
                residenceTypeLOVHeight.constant = 0
                
            case ConstantCodes.ADDRESS_TYPE_RES:
                residenceLOVHeight.constant = 65
                sameAsAddressViewHeight.constant = 86
                residenceTypeLOVHeight.constant = 65
                sameAsButton2.isHidden = false
                sameAsButton1.setCheckboxProperties(title: "Permanent")
                sameAsButton2.setCheckboxProperties(title: "Office")
                
            default:
                sameAsButton2.isHidden = true
                sameAsButton1.setCheckboxProperties(title: "Office")
                sameAsAddressViewHeight.constant = 86
                residenceLOVHeight.constant = 0
                residenceTypeLOVHeight.constant = 0
            }
        }
        
        validateFields()
    }
}

extension AddAddressVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        if let yearInAdd = Int(addressDurationView.yearView.getFieldValue()), let yearInCity = Int(cityDurationView.yearView.getFieldValue()) {
            
            if yearInCity < yearInAdd {
                CommonAlert.shared().showAlert(message: "Duration at city must be greater than or equal to Duration at address.")
                return
            }
            else if yearInCity == yearInAdd {
                if let monthInAdd = Int(addressDurationView.monthView.getFieldValue()), let monthInCity = Int(cityDurationView.monthView.getFieldValue()) {
                    if monthInCity < monthInAdd {
                        CommonAlert.shared().showAlert(message: "Duration at city must be greater than or equal to duration at address.")
                        return
                    }
                }
            }
        }
        
        var sameAsPermanentAddr = false
        var sameAsOfficeAddr = false
        var sameAsResidentialAddr = false
        let fromScan = false 
        
        if selectedLOVDic["\(TAG_ADDRESS)"]?.code?.lowercased() == ConstantCodes.ADDRESS_TYPE_PERM.lowercased() {
            sameAsOfficeAddr = sameAsButton1.isSelected
            sameAsResidentialAddr = sameAsButton2.isSelected
        }
        else if selectedLOVDic["\(TAG_ADDRESS)"]?.code?.lowercased() == ConstantCodes.ADDRESS_TYPE_RES.lowercased() {
            sameAsPermanentAddr = sameAsButton1.isSelected
            sameAsOfficeAddr = sameAsButton2.isSelected
        }
        else {
            sameAsOfficeAddr = sameAsButton1.isSelected
        }
        
        var addressID = ""
        
        if let dataObj = dataObj {
            addressID = dataObj.neutronAddressId!
        }
        else {
            addressID = "\(CommonUtils.shared().getValidatedString(string: self.customerID))_\(CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_ADDRESS)"]?.code))"
        }
        
        let param: [String : Any] = ["neutronReferenceNumber"   : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                     "neutronCustRefNumber"     : CommonUtils.shared().getValidatedString(string: self.customerID),
                                     "addressDetails"           : [["neutronAddressId"          : CommonUtils.shared().getValidatedString(string: addressID),
                                                                    "addressType"               : ["code":selectedLOVDic["\(TAG_ADDRESS)"]?.code,"name":selectedLOVDic["\(TAG_ADDRESS)"]?.name],
                                                                    "unit"                      : addressL1View.getFieldValue(),
                                                                    "streetNo"                  : addressL2View.getFieldValue(),
                                                                    "streetName"                : addressL3View.getFieldValue(),
                                                                    "landmark"                  : landmarkView.getFieldValue(),
                                                                    "country"                   : ["code"   :   searchByPincodeView.getSelectedCountry().0,
                                                                                                   "name"   :   searchByPincodeView.getSelectedCountry().1],
                                                                    "state"                     : ["code"   :   searchByPincodeView.getSelectedState().0,
                                                                                                   "name"   :   searchByPincodeView.getSelectedState().1],
                                                                    "city"                      : ["code"   :   searchByPincodeView.getSelectedCity().0,
                                                                                                   "name"   :   searchByPincodeView.getSelectedCity().1],
                                                                    "postalCode"                : ["code"   :   searchByPincodeView.getSelectedPincode().0,
                                                                                                   "name"   :   searchByPincodeView.getSelectedPincode().1],
                                                                    "residenceType"             : ["code":selectedLOVDic["\(TAG_RESIDENCE_TYPE)"]?.code,"name":selectedLOVDic["\(TAG_RESIDENCE_TYPE)"]?.name],
                                                                    "residentialStatus"         : ["code":selectedLOVDic["\(TAG_RESIDENCE)"]?.code,"name":selectedLOVDic["\(TAG_RESIDENCE)"]?.name],
                                                                    "numberOfMonthsAtAddress"   : addressDurationView.monthView.getFieldValue(),
                                                                    "numberOfYearsAtAddress"    : addressDurationView.yearView.getFieldValue(),
                                                                    "numberOfMonthsAtCity"      : cityDurationView.monthView.getFieldValue(),
                                                                    "numberOfYearsAtCity"       : cityDurationView.yearView.getFieldValue(),
                                                                    "communicationAddress"      : checkBoxButton.isSelected,
                                                                    "sameAsPermanentAddr"       :sameAsPermanentAddr,
                                                                    "sameAsOfficeAddr"          :sameAsOfficeAddr,
                                                                    "sameAsResidentialAddr"     :sameAsResidentialAddr,
                                                                    "fromScan"                  :fromScan]]]
        
        
        Webservices.shared().POST(urlString: ServiceUrl.SAVE_ADDRESS_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                if let obj = AppDelegate.instance.getSpecificVC(targetClass: SourcingAddressListVC.self) as? SourcingAddressListVC {
                    obj.fetchList()
                }
                self.navigationController?.popViewController(animated: true)
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
        
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension AddAddressVC: CustomDVDelegate {    
    func validateYearMonth() {
        self.validateFields()
    }
}

extension AddAddressVC: CustomPincodeDelegate {
    func validatePincode() {
        self.validateFields()
    }
}

extension AddAddressVC: CSByPincodeDelegate {
    func CSBPValidation() {
        validateFields()
    }
}
