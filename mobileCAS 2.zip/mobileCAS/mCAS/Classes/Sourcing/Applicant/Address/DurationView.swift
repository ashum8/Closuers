//
//  DurationView.swift
//  mCAS
//
//  Created by iMac on 28/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol CustomDVDelegate {
    func validateYearMonth()
}

class DurationView: UIView {
    
    @IBOutlet var containerView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var yearView: CustomTextFieldView!
    @IBOutlet weak var monthView: CustomTextFieldView!
    
    private var delegate: CustomDVDelegate?
    
    private let TAG_YEAR = 1000
    private let TAG_MONTH = 1001
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("DurationView", owner: self, options: nil)
        containerView.fixInView(self)
    }
    
    func setProperties(title: String, delegate: CustomDVDelegate? = nil) {
        yearView.setProperties(placeHolder: "Year", type: .Number, delegate: self, tag: TAG_YEAR)
        monthView.setProperties(placeHolder: "Month", type: .Number, delegate: self, tag: TAG_MONTH)
        titleLabel.font = CustomFont.shared().GETFONT_MEDIUM(17)
        
        titleLabel.text = title
        self.delegate = delegate
    }
    
    func setFieldValue(year: String, month: String) {
        yearView.setFieldValue(text: year)
        monthView.setFieldValue(text: month)
    }
}

extension DurationView: CustomTFViewDelegate {
    func validateFields() {
        delegate?.validateYearMonth()
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        switch tag {
        case TAG_YEAR:
            return Int(text) ?? 0 <= 100 && text.count <= 3
            
        case TAG_MONTH:
            return Int(text) ?? 0 <= 11 && text.count <= 2
            
        default:
            return true
        }
    }
}
