//
//  AddApplicantModesVC.swift
//  mCAS
//
//  Created by Ashutosh Mishra on 05/03/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddApplicantModesVC: UIViewController {
    @IBOutlet weak var aadhaarView: SDOptionView!
    @IBOutlet weak var karzaView: SDOptionView!
    @IBOutlet weak var ocrView: SDOptionView!
    @IBOutlet weak var scanCodeView: SDOptionView!
    @IBOutlet weak var manuallyView: SDOptionView!
    @IBOutlet weak var orLabel: EdgeInsetLabel!
    @IBOutlet weak var headingLabel: UILabel!
    
    private let aadhaarTag = 1000
    private let karzaTag = 1001
    private let ocrTag = 1002
    private let scanCodeTag = 1003
    private let manuallyTag = 1004
    
    private var selectApplicantTypeView: ApplicantTypeSelectionView!
    
    private var applicationID: String!
    private var applicationType: DropDown!
    private var productCategory: LoanType!
    private var applicantRoleCode: String!
    private var primaryApplicantType: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        aadhaarView.setProperties(title: "Aadhar eKYC", image: "tab_icon_reports", delegate: self, tag: aadhaarTag, removeBottomMargin: true)
        karzaView.setProperties(title: "Karza", image: "tab_icon_reports", delegate: self, tag: karzaTag, removeBottomMargin: true)
        ocrView.setProperties(title: "OCR", image: "tab_icon_reports", delegate: self, tag: ocrTag, removeBottomMargin: true)
        scanCodeView.setProperties(title: "Scan Code", image: "tab_icon_reports", delegate: self, tag: scanCodeTag, removeBottomMargin: true)
        manuallyView.setProperties(title: "manually", image: "tab_icon_reports", delegate: self, tag: manuallyTag, removeBottomMargin: true)
        
        headingLabel.font = CustomFont.shared().GETFONT_REGULAR(18)
        
        orLabel.backgroundColor = Color.LIGHTER_GRAY
        orLabel.textColor = .gray
        orLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        orLabel.layer.cornerRadius = 20
        orLabel.layer.masksToBounds = true
    }
    
    func setData(productCategory: LoanType, applicationType: DropDown, applicationID: String, applicantRoleCode: String, primaryApplicantType: String? = nil) {
        self.productCategory = productCategory
        self.applicationType = applicationType
        self.applicationID = applicationID
        self.applicantRoleCode = applicantRoleCode
        self.primaryApplicantType = primaryApplicantType
    }
}

extension AddApplicantModesVC: SDOptionViewDelegate {
    
    func buttonAction(tag: Int) {
        
        switch tag
        {
        case aadhaarTag:
            print("aadhaarTag")
            
        case karzaTag:
            print("karzaTag")
            
        case ocrTag:
            print("ocrTag")
            
        case scanCodeTag:
            print("scanCodeTag")
            
        case manuallyTag:
            if self.selectApplicantTypeView == nil {
                self.selectApplicantTypeView = .fromNib()
                self.selectApplicantTypeView.setProperties(width: self.view.frame.size.width, height: self.view.frame.size.height, delegate: self)
                self.view.addSubview(self.selectApplicantTypeView)
            }
            self.selectApplicantTypeView.alpha = 1
            
        default:
            break
        }
    }
}

extension AddApplicantModesVC: ApplicantTypeDelegate {
    
    func getSelectedOption(customerType: ApplicantType) {
        selectApplicantTypeView.alpha = 0
        
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "ApplicantPersonalDetailVC") as? ApplicantPersonalDetailVC {
            vc.setData(type: customerType, productCategory: productCategory, applicationType: applicationType, applicationID: applicationID, applicantRoleCode: applicantRoleCode, primaryApplicantType: primaryApplicantType)
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
}
