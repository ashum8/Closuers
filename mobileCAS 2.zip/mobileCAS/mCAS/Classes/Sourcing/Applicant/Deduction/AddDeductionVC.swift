//
//  AddDeductionVC.swift
//  mCAS
//
//  Created by iMac on 28/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddDeductionVC: UIViewController {
    
    @IBOutlet weak var employmentTypeLOV: LOVFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var frequencyLOV: LOVFieldView!
    @IBOutlet weak var frequencyLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var amountView: CustomTextFieldView!
    @IBOutlet weak var amountViewHeight: NSLayoutConstraint!
    @IBOutlet weak var percentageView: CustomTextFieldView!
    @IBOutlet weak var percentageViewHeight: NSLayoutConstraint!
    @IBOutlet weak var netAmountView: CustomTextFieldView!
    @IBOutlet weak var netAmountViewHeight: NSLayoutConstraint!
    @IBOutlet weak var employmentStatusLabel: EdgeInsetLabel!
    @IBOutlet weak var year1View: CustomTextFieldView!
    @IBOutlet weak var year1ViewHeight: NSLayoutConstraint!
    @IBOutlet weak var year2View: CustomTextFieldView!
    @IBOutlet weak var year2ViewHeight: NSLayoutConstraint!
    @IBOutlet weak var year3View: CustomTextFieldView!
    @IBOutlet weak var year3ViewHeight: NSLayoutConstraint!
    @IBOutlet weak var deductionTypeLOV: LOVFieldView!
    
    
    private let TAG_EMPLOYMENT  = 1000
    private let TAG_DEDUCTION   = 1001
    private let TAG_FREQUENCY   = 1002
    private let TAG_AMOUNT      = 1003
    private let TAG_PERCENTAGE  = 1004
    
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var applicationID: String!
    private var customerID: String!
    private var dataObj: SourcingModelClasses.EmploymentModel!
    
    private var employmentModelArray = [SourcingModelClasses.EmploymentModel]()
    
    private var dropDownList = [DropDown]()
    private var deductionID: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        self.dropDownList = SourcingCommonUtil.shared().getFormattedEmplyementMasterList(list: self.employmentModelArray)

        employmentStatusLabel.removeStatusLabelProperties()
        
        employmentTypeLOV.setLOVProperties(title: "Employment Type", tag: self.TAG_EMPLOYMENT, delegate: self, optionArray: self.dropDownList)
        
        deductionTypeLOV.setLOVProperties(masterName: Entity.INCOME_EXPENSE_HEAD, title: "Deduction Type", tag: TAG_DEDUCTION, delegate: self, parentKey: "deduction")
        
        frequencyLOV.setLOVProperties(masterName: Entity.FREQUENCY, title: "Frequency", tag: TAG_FREQUENCY, delegate: self)
        
        amountView.setProperties(placeHolder: "Amount", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        
        year1View.setProperties(placeHolder: "Year 1", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        year2View.setProperties(placeHolder: "Year 2", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        year3View.setProperties(placeHolder: "Year 3 (Current Year)", type: .Amount, delegate: self, tag: TAG_AMOUNT)

        netAmountView.setProperties(placeHolder: "Net Amount", enabled: false)
        
        percentageView.setProperties(placeHolder: "Percentage (%)", type: .Decimal, delegate: self, tag: TAG_PERCENTAGE)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        fillDataInEditMode(dataObj: dataObj)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Deduction")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader()
        }
    }
    
    func setData(applicationID: String, customerID: String, dataObj: SourcingModelClasses.EmploymentModel? = nil, employmentModelArray: [SourcingModelClasses.EmploymentModel], deductionID: String? = nil) {
        self.applicationID = applicationID
        self.customerID = customerID
        self.dataObj = dataObj
        self.employmentModelArray = employmentModelArray
        
        if let id = deductionID {
            self.deductionID = id
        }
        else {
            self.deductionID = SourcingCommonUtil.shared().generateApplicationID()
        }
    }
    
    private func fillDataInEditMode(dataObj: SourcingModelClasses.EmploymentModel?) {
        
        if let data = dataObj
        {
            employmentTypeLOV.autoFillLOVBy(key: data.occupationType?.code)
            employmentTypeLOV.enableLOV(isEnable: false)

            if let deductionArr = data.deductionDetails, !deductionArr.isEmpty {
                if let id = deductionID {
                    let obj = deductionArr.filter({$0.deductionId == id}).first
                    deductionTypeLOV.autoFillLOVBy(key: obj?.deductionType?.code)
                    frequencyLOV.autoFillLOVBy(key: obj?.deductionFrequency?.code)
                    
                    if data.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SENP.lowercased() || data.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SEP.lowercased() {
                        if let year1 = obj?.year1Deduction, let year2 = obj?.year2Deduction, let year3 = obj?.year3Deduction {
                            year1View.setFieldValue(text: "\(year1)")
                            year2View.setFieldValue(text: "\(year2)")
                            year3View.setFieldValue(text: "\(year3)")
                        }
                    }
                    else {
                        if let amount = obj?.grossAmount {
                            amountView.setFieldValue(text: "\(amount)")
                        }
                        netAmountView.setFieldValue(text: obj?.netAmount)
                        percentageView.setFieldValue(text: obj?.percentage)
                    }
                }
            }
            
            buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Update", delegate: self)
        }
        validateFields()
    }

    private func refreshFieldData() {
        deductionTypeLOV.resetLOVWithParentKey()
        frequencyLOV.resetLOVWithParentKey()
        year1View.setFieldValue()
        year2View.setFieldValue()
        year3View.setFieldValue()
        amountView.setFieldValue()
        percentageView.setFieldValue()
        netAmountView.setFieldValue()
    }
    
}

extension AddDeductionVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        
        if let cost = Double(amountView.getFieldValue()), let percentage = Double(percentageView.getFieldValue()) {
            netAmountView.setFieldValue(text: "\((cost*percentage) / 100 )".formatCurrency)
        }
        
        if selectedLOVDic["\(TAG_EMPLOYMENT)"]?.code.lowercased() == ConstantCodes.EMP_TYPE_SENP.lowercased() || selectedLOVDic["\(TAG_EMPLOYMENT)"]?.code.lowercased() == ConstantCodes.EMP_TYPE_SEP.lowercased() {
            isEnabled = !(selectedLOVDic["\(TAG_EMPLOYMENT)"] == nil || selectedLOVDic["\(TAG_DEDUCTION)"] == nil || year1View.getFieldValue().isEmpty || year2View.getFieldValue().isEmpty || year3View.getFieldValue().isEmpty)
        }
        else {
            isEnabled = !(selectedLOVDic["\(TAG_EMPLOYMENT)"] == nil || selectedLOVDic["\(TAG_DEDUCTION)"] == nil || selectedLOVDic["\(TAG_FREQUENCY)"] == nil || amountView.getFieldValue().isEmpty || percentageView.getFieldValue().isEmpty)
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            let amount = Double(text) ?? 0
            return amount <= SourcingCommonUtil.shared().maxAmount && amount > 0

        case TAG_PERCENTAGE:
            return Double(text) ?? 0 <= SourcingCommonUtil.shared().maxPercentage && Double(text) ?? 0 > 0
            
        default:
            return true
        }
    }
}

extension AddDeductionVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_EMPLOYMENT {
            
            refreshFieldData()
            
            let empObjArr = employmentModelArray.filter({ $0.employmentId == selectedLOVDic["\(TAG_EMPLOYMENT)"]?.id})
            
            if !empObjArr.isEmpty {
                let obj = empObjArr.first
                employmentStatusLabel.setStatusLabelProperties(borderColor: Color.SKY_BLUE)
                employmentStatusLabel.text = obj?.occupationType?.name
            }
            
            if selectedObj.code.lowercased() == ConstantCodes.EMP_TYPE_SENP.lowercased() || selectedObj.code.lowercased() == ConstantCodes.EMP_TYPE_SEP.lowercased() {
                frequencyLOVHeight.constant = 0
                amountViewHeight.constant = 0
                percentageViewHeight.constant = 0
                netAmountViewHeight.constant = 0
                
                year1ViewHeight.constant = 65
                year2ViewHeight.constant = 65
                year3ViewHeight.constant = 65
            }
            else {
                frequencyLOVHeight.constant = 65
                amountViewHeight.constant = 65
                percentageViewHeight.constant = 65
                netAmountViewHeight.constant = 65
                
                year1ViewHeight.constant = 0
                year2ViewHeight.constant = 0
                year3ViewHeight.constant = 0
            }
        }
        validateFields()
    }
}

extension AddDeductionVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        var paramEmployment: [String : Any] = [:]
        
        let empObjArr = employmentModelArray.filter({ $0.employmentId == selectedLOVDic["\(TAG_EMPLOYMENT)"]?.id})
        
        if !empObjArr.isEmpty, let obj = empObjArr.first {
            
            var deductionDetailsArr = [[String: Any]]()
            
            if let deductionArr = obj.deductionDetails, !deductionArr.isEmpty {
                
                let arr = deductionArr.filter({
                    return ((obj.occupationType?.code == selectedLOVDic["\(TAG_EMPLOYMENT)"]?.code) && ($0.deductionType?.code == selectedLOVDic["\(TAG_DEDUCTION)"]?.code))
                    
                })
                
                if !arr.isEmpty && (dataObj == nil) {
                    CommonAlert.shared().showAlert(message: "Duplicate data found!")
                    return
                }
            }
            
            var paramDeduction: [String : Any] = [:]
            
            paramDeduction["deductionId"]       = deductionID

            if selectedLOVDic["\(TAG_EMPLOYMENT)"]?.code.lowercased() == ConstantCodes.EMP_TYPE_SENP.lowercased() || selectedLOVDic["\(TAG_EMPLOYMENT)"]?.code.lowercased() == ConstantCodes.EMP_TYPE_SEP.lowercased() {
                paramDeduction["year1Deduction"]          = year1View.getFieldValue()
                paramDeduction["year2Deduction"]          = year2View.getFieldValue()
                paramDeduction["year3Deduction"]          = year3View.getFieldValue()
            }
            else {
                paramDeduction["grossAmount"]              = amountView.getFieldValue()
                paramDeduction["percentage"]               = percentageView.getFieldValue()
                paramDeduction["netAmount"]                = netAmountView.getFieldValue()
                paramDeduction["deductionFrequency"]    = ["code": selectedLOVDic["\(TAG_FREQUENCY)"]?.code ?? "",                                        "name": selectedLOVDic["\(TAG_FREQUENCY)"]?.code ?? ""]
            }
            
            paramDeduction["deductionType"]     = ["code": selectedLOVDic["\(TAG_DEDUCTION)"]?.code ?? "",
                                                   "name": selectedLOVDic["\(TAG_DEDUCTION)"]?.name ?? ""]
            
            deductionDetailsArr.append(paramDeduction)
                        
            paramEmployment["employmentId"]             = obj.employmentId
            paramEmployment["majorOccupation"]          = obj.majorOccupation
            paramEmployment["otherEmployerName"]        = obj.otherEmployerName
            
            paramEmployment["occupationType"]           = ["code": obj.occupationType?.code ?? "", "name": obj.occupationType?.name ?? ""]
            
            if let code = obj.employerName?.code, let name = obj.employerName?.name {
                paramEmployment["employerName"]         = ["code": code, "name": name]
            }
            
            if let code = obj.industry?.code, let name = obj.industry?.name {
                paramEmployment["industry"]         = ["code": code, "name": name]
            }

            if let code = obj.natureOfBusiness?.code, let name = obj.natureOfBusiness?.name {
                paramEmployment["natureOfBusiness"]         = ["code": code, "name": name]
            }
            
            if let code = obj.natureOfProfession?.code, let name = obj.natureOfProfession?.name {
                paramEmployment["natureOfProfession"]         = ["code": code, "name": name]
            }
            
            if let code = obj.natureOfOccupation?.code, let name = obj.natureOfOccupation?.name {
                paramEmployment["natureOfOccupation"]         = ["code": code, "name": name]
            }
            
            paramEmployment["employedFrom"]         = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: obj.employedFrom, outputFormat: Constants.DATE_FORMAT_SERVICE)
            
            paramEmployment["organizationName"]     = obj.organizationName
            paramEmployment["registrationNumber"]   = obj.registrationNumber
            
            paramEmployment["deductionDetails"]        = deductionDetailsArr
            
            let param: [String : Any] = ["neutronReferenceNumber"   : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                         "neutronCustRefNumber"     : CommonUtils.shared().getValidatedString(string: self.customerID),
                                         "employmentDetails"        : [paramEmployment]]
            
            Webservices.shared().POST(urlString: ServiceUrl.SAVE_DEDUCTION_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
                
                if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                    
                    if let obj = AppDelegate.instance.getSpecificVC(targetClass: DeductionListVC.self) as? DeductionListVC {
                        obj.fetchList()
                    }
                    self.navigationController?.popViewController(animated: true)
                }
                
            }, failure: { (error) in
                
                if let error = error {
                    CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
                }
                
            }, noNetwork: { (error) in
            })
        }
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

