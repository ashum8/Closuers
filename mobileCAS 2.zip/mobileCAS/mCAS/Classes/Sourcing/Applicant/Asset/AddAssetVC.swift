//
//  AddAssetVC.swift
//  mCAS
//
//  Created by iMac on 29/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddAssetVC: UIViewController {
    
    @IBOutlet weak var assetCategoryLOV: LOVFieldView!
    @IBOutlet weak var assetTypeLOV: LOVFieldView!
    @IBOutlet weak var assetValueView: CustomTextFieldView!
    @IBOutlet weak var assetDescriptionView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var applicationID: String!
    private var customerID: String!
    private var dataObj: SourcingModelClasses.AssetModel!
    
    private let TAG_CATEGORY = 1000
    private let TAG_TYPE = 1001
    private let TAG_AMOUNT = 10000
    private let TAG_DESCRIPTION = 10001
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        assetCategoryLOV.setLOVProperties(masterName: Entity.INCOME_ASSET_CATEGORY, title: "Asset Category", tag: TAG_CATEGORY, delegate: self)
        assetTypeLOV.setLOVProperties(masterName: Entity.INCOME_ASSET_TYPE, title: "Asset Type", tag: TAG_TYPE, delegate: self)
        
        assetValueView.setProperties(placeHolder: "Amount", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        
        assetDescriptionView.setProperties(placeHolder: "Asset Description", type: .Text, delegate: self, tag: TAG_DESCRIPTION)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        fillDataInEditMode(dataObj: dataObj)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Asset")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader()
        }
    }
    
    func setData(applicationID: String, customerID: String, dataObj: SourcingModelClasses.AssetModel? = nil) {
        self.applicationID = applicationID
        self.customerID = customerID
        self.dataObj = dataObj
    }
    
    private func fillDataInEditMode(dataObj: SourcingModelClasses.AssetModel?) {
        if let data = dataObj {
            
            if let dataCode = data.incomeAssetCategory?.code, !dataCode.isEmpty {
                assetCategoryLOV.autoFillLOVBy(key: dataCode)
            }
            
            assetTypeLOV.autoFillLOVBy(key: data.incomeAssetType?.code)
            
            if let amount = data.incomeAssetValue {
                assetValueView.setFieldValue(text: "\(amount)")
            }
            
            assetDescriptionView.setFieldValue(text: data.incomeAssetDescription)
            
            buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Update", delegate: self)
        }
        validateFields()
    }
}

extension AddAssetVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_CATEGORY {
            if let dd = selectedLOVDic["\(TAG_CATEGORY)"] {
                assetTypeLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_TYPE)"] = nil
            }
        }
        
        validateFields()
    }
}

extension AddAssetVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        if (selectedLOVDic["\(TAG_CATEGORY)"] == nil || selectedLOVDic["\(TAG_TYPE)"] == nil || assetValueView.getFieldValue().isEmpty || assetDescriptionView.getFieldValue().isEmpty ) {
            
            isEnabled = false
        }
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            let amount = Double(text) ?? 0.0
            return amount <= SourcingCommonUtil.shared().maxAmount && amount > 0
            
        case TAG_DESCRIPTION:
            return text.count < Constants.REMARKS_LENGTH && text.isAlphanumericAndSpace
            
        default:
            return true
        }
    }
}

extension AddAssetVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        var assetID = ""
        if let dataObj = dataObj {
            assetID = dataObj.assetId!
        }
        else {
            assetID = "\(CommonUtils.shared().getValidatedString(string: self.customerID))_\(CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_CATEGORY)"]?.code))"
        }
        
        let param: [String : Any] = ["neutronReferenceNumber"   : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                     "neutronCustRefNumber"     : CommonUtils.shared().getValidatedString(string: self.customerID),
                                     "incomeAssetDetails"       : [["assetId" : CommonUtils.shared().getValidatedString(string: assetID),
                                                                    "incomeAssetCategory"             : ["code":selectedLOVDic["\(TAG_CATEGORY)"]?.code,"name":selectedLOVDic["\(TAG_CATEGORY)"]?.name],
                                                                    "incomeAssetType"                  : ["code":selectedLOVDic["\(TAG_TYPE)"]?.code,"name":selectedLOVDic["\(TAG_TYPE)"]?.name],
                                                                    "incomeAssetValue"                 : assetValueView.getFieldValue(),
                                                                    "incomeAssetDescription"           : assetDescriptionView.getFieldValue()]]]
        
        Webservices.shared().POST(urlString: ServiceUrl.SAVE_ASSET_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                if let obj = AppDelegate.instance.getSpecificVC(targetClass: AssetsListVC.self) as? AssetsListVC {
                    obj.fetchList()
                }
                self.navigationController?.popViewController(animated: true)
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
