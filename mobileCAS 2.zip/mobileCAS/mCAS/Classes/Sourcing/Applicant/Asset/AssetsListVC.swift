//
//  AssetsListVC.swift
//  mCAS
//
//  Created by iMac on 29/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AssetsListVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var headerTitleView: SourcingTitleView!
    
    private enum DetailOptions: String {
        case edit = "Edit"
        case delete = "Delete"
    }
    
    private var dataModelArray = [SourcingModelClasses.AssetModel]()
    private var cellOptionArray: [DetailOptions] = [.edit, .delete]
    private var applicationID: String!
    private var customerID: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
        fetchList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader(isHide: false, title: "Add Applicant")
        }
    }
    
    private func setupView() {
        
        headerTitleView.setProperties(title: "Assets")
        
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties(title: "Add Asset details here.", image: "asset_placeholder")
        
        tableView.register(UINib(nibName: "SourcingCommonListCell", bundle: nil), forCellReuseIdentifier: "SourcingCommonListCell")
        tableView.tableFooterView = UIView()
        
    }
    
    func setData(applicationID: String, customerID: String) {
        self.applicationID = applicationID
        self.customerID = customerID
    }
    
    private func setListData() {
        tableView.isHidden = dataModelArray.isEmpty
        noDataCapturedView.isHidden = !tableView.isHidden
        self.tableView.reloadData()
        buttonView.setProperties(showBack: true, nextBtnTitle: self.dataModelArray.isEmpty ? "Skip" : "Continue", delegate: self)
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        moveToDetailPage()
    }
    
    func fetchList() {
        
        let param = ["neutronCustRefNumber" : customerID]
        
        dataModelArray.removeAll()
        Webservices.shared().POST(urlString: ServiceUrl.GET_ALL_ASSET_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [[String: Any]]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: [SourcingModelClasses.AssetModel].self) { list in
                    self.dataModelArray.append(contentsOf: list)
                }
            }
            self.setListData()
            
        }, failure: { (error) in
            
            self.setListData()
            
        }, noNetwork: { (error) in
            self.setListData()
        })
    }
    
    private func moveToDetailPage(index: Int? = nil) {
        var data: SourcingModelClasses.AssetModel?
        
        if let index = index {
            data = dataModelArray[index]
        }
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "AddAssetVC") as? AddAssetVC {
            vc.setData(applicationID: applicationID, customerID: customerID, dataObj: data)
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
    
    private func deleteDataRow(index: Int) {
        
        let param = ["neutronReferenceNumber"                : applicationID,
                     "neutronCustRefNumber"                  : customerID,
                     "assetId"                               : dataModelArray[index].assetId]
        
        Webservices.shared().POST(urlString: ServiceUrl.DELETE_ASSET_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                self.dataModelArray.remove(at: index)
                self.setListData()
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
    
}

extension AssetsListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataModelArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SourcingCommonListCell", for: indexPath) as! SourcingCommonListCell
        cell.setProperties(optionArray: cellOptionArray.map({ $0.rawValue }), cellIndex: indexPath.row, delegate: self)
        let model = dataModelArray[indexPath.row]
        cell.label1.text = model.incomeAssetCategory?.name
        
        var amount = ""
        if let data = model.incomeAssetValue {
            amount = "\(data)".formatCurrency
        }
        cell.label2.text = "\(model.incomeAssetType?.name ?? "") \(Constants.SEPERATOR) \(amount)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        moveToDetailPage(index: indexPath.row)
    }
}

extension AssetsListVC : NextBackButtonDelegate {
    func nextButtonAction() {
        let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = st.instantiateViewController(withIdentifier: "LiabilityListVC") as? LiabilityListVC  {
            vc.setData(applicationID: applicationID, customerID: customerID)
            AppDelegate.instance.applicationNavController.pushViewController(vc, animated: true)
        }
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension AssetsListVC : CommonListCellDelegate {
    func selectedIndex(index: Int, cellIndex: Int, cellSection: Int) {
        let item = self.cellOptionArray[index]
        if item == .edit {
            moveToDetailPage(index: cellIndex)
        }
        else if item == .delete {
            CommonAlert.shared().showAlert(message: "Are you sure you want to delete asset details?", cancelTitle: "Cancel" , okAction: { _ in
                self.deleteDataRow(index: cellIndex)
            })
        }
    }
}
