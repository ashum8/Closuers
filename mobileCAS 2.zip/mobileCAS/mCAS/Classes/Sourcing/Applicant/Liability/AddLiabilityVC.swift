//
//  AddLiabilityVC.swift
//  mCAS
//
//  Created by iMac on 29/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddLiabilityVC: UIViewController {
    
    @IBOutlet weak var liabiltyTypeLOV: LOVFieldView!
    @IBOutlet weak var loanTypeLOV: LOVFieldView!
    @IBOutlet weak var institutionLOV: LOVFieldView!
    @IBOutlet weak var sanctionAmountView: CustomTextFieldView!
    @IBOutlet weak var principleOutstandingView: CustomTextFieldView!
    @IBOutlet weak var emiStartDateView: CustomTextFieldView!
    @IBOutlet weak var installmentFrequencyLOV: LOVFieldView!
    @IBOutlet weak var installmentAmountView: CustomTextFieldView!
    @IBOutlet weak var closedDateView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private let TAG_LIABILITY = 1000
    private let TAG_LOAN = 1001
    private let TAG_INSTITUTION = 1002
    private let TAG_LIABILITY_FREQUENCY = 1003
    
    private var selectedLOVDic: [String: DropDown] = [:]
    
    private let TAG_AMOUNT          = 10000
    private let TAG_EMI_AMOUNT      = 10001
    
    private var applicationID: String!
    private var customerID: String!
    private var dataObj: SourcingModelClasses.LiabilityModel!
    
    private let LIABILITY_TYPE_NAME = "Loans"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    private func setupView() {
        
        
        liabiltyTypeLOV.setLOVProperties(masterName: Entity.LIABILITY_TYPE, title: "Liability Type", tag: TAG_LIABILITY, autoFillValue: LIABILITY_TYPE_NAME, delegate: self, enable: false)
        loanTypeLOV.setLOVProperties(masterName: Entity.EXTERNAL_LOAN_TYPE, title: "Loan Type", tag: TAG_LOAN, delegate: self)
        institutionLOV.setLOVProperties(masterName: Entity.EXTERNAL_BANKS, title: "Institution", tag: TAG_INSTITUTION, delegate: self)
        installmentFrequencyLOV.setLOVProperties(masterName: Entity.LIABILITY_FREQUENCY, title: "Installment Frequency", tag: TAG_LIABILITY_FREQUENCY, delegate: self)
        
        sanctionAmountView.setProperties(placeHolder: "Sanction Amount", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        principleOutstandingView.setProperties(placeHolder: "Principle Outstanding", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        
        let stDate = Date().addingTimeInterval(-1*24*60*60)
        emiStartDateView.setProperties(placeHolder: "Emi Start Date", type: .DATE, delegate: self, maximumDate: stDate)
        
        installmentAmountView.setProperties(placeHolder: "Installment Amount", type: .Amount, delegate: self, tag: TAG_EMI_AMOUNT)
        
        let endDate = Date().addingTimeInterval(1*24*60*60)
        closedDateView.setProperties(placeHolder: "Closed Date", type: .DATE, delegate: self, minimumDate: endDate, maximumDate: nil)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        fillDataInEditMode(dataObj: dataObj)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Liability")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader()
        }
    }
    
    func setData(applicationID: String, customerID: String, dataObj: SourcingModelClasses.LiabilityModel? = nil) {
        self.applicationID = applicationID
        self.customerID = customerID
        self.dataObj = dataObj
    }
    
    private func fillDataInEditMode(dataObj: SourcingModelClasses.LiabilityModel?) {
        if let data = dataObj {
            
            if let dataCode = data.liabilityType?.code, !dataCode.isEmpty {
                liabiltyTypeLOV.enableLOV(isEnable: false)
                liabiltyTypeLOV.autoFillLOVBy(key: dataCode)
            }
            
            loanTypeLOV.autoFillLOVBy(key: data.externalProduct?.code)
            
            institutionLOV.autoFillLOVBy(key: data.institution?.code)
            
            installmentFrequencyLOV.autoFillLOVBy(key: data.frequencyForLiability?.code)
            
            
            if let amount = data.sanctionedAmount {
                sanctionAmountView.setFieldValue(text: "\(amount)")
            }
            
            if let outstanding = data.balance {
                principleOutstandingView.setFieldValue(text: "\(outstanding)")
            }
            
            if let insAmount = data.installmentAmount {
                installmentAmountView.setFieldValue(text: "\(insAmount)")
            }
            
            emiStartDateView.setFieldValue(text: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: data.emiStartDate))
            
            closedDateView.setFieldValue(text: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: data.closedDate))
            
            buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Update", delegate: self)
            
        }
        validateFields()
    }
    
}

extension AddLiabilityVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        validateFields()
    }
}

extension AddLiabilityVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        if (selectedLOVDic["\(TAG_LIABILITY)"] == nil || selectedLOVDic["\(TAG_LOAN)"] == nil || selectedLOVDic["\(TAG_INSTITUTION)"] == nil || sanctionAmountView.getFieldValue().isEmpty || principleOutstandingView.getFieldValue().isEmpty || emiStartDateView.getFieldValue().isEmpty || selectedLOVDic["\(TAG_LIABILITY_FREQUENCY)"] == nil || installmentAmountView.getFieldValue().isEmpty || closedDateView.getFieldValue().isEmpty ) {
            
            isEnabled = false
        }
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            let amount = Double(text) ?? 0.0
            return amount <= SourcingCommonUtil.shared().maxAmount && amount > 0

        case TAG_EMI_AMOUNT:
            let amount = Double(text) ?? 0.0
            return amount <= SourcingCommonUtil.shared().maxLimitEMIAmount && amount > 0
            
        default:
            return true
        }
    }
}

extension AddLiabilityVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        if let outstanding = Int(principleOutstandingView.getFieldValue()), let sanction = Int(sanctionAmountView.getFieldValue()), outstanding < sanction {
            CommonAlert.shared().showAlert(message: "Principle outstanding amount should be greater than sanction amount.")
            return
        }
        
        if let emi = Int(installmentAmountView.getFieldValue()), let sanction = Int(sanctionAmountView.getFieldValue()), emi > sanction {
            CommonAlert.shared().showAlert(message: "Installment amount should be less than sanction amount.")
            return
        }
        
        if let fromDate = CustomDateFormatter.shared().getRespectiveDateFromString(inputString: emiStartDateView.getFieldValue()),
            let toDate = CustomDateFormatter.shared().getRespectiveDateFromString(inputString: closedDateView.getFieldValue())
        {
            if fromDate.getDaysDifference(toDate: toDate) < 1 {
                CommonAlert.shared().showAlert(message: "closed date must be greater than start emi date.")
                return
            }
        }
        
        var liabilityID = ""
        if let dataObj = dataObj {
            liabilityID = dataObj.liabilityId!
        }
        else {
            liabilityID = SourcingCommonUtil.shared().generateApplicationID()
        }
        
        let param: [String : Any] = ["neutronReferenceNumber"   : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                     "neutronCustRefNumber"     : CommonUtils.shared().getValidatedString(string: self.customerID),
                                     "liabilityDetails"         : [["liabilityId"                   : CommonUtils.shared().getValidatedString(string: liabilityID),
                                                                    "liabilityType"                : ["code":selectedLOVDic["\(TAG_LIABILITY)"]?.code,"name":selectedLOVDic["\(TAG_LIABILITY)"]?.name],
                                                                    "externalProduct"              : ["code":selectedLOVDic["\(TAG_LOAN)"]?.code,"name":selectedLOVDic["\(TAG_LOAN)"]?.name],
                                                                    "institution"                  : ["code":selectedLOVDic["\(TAG_INSTITUTION)"]?.code,"name":selectedLOVDic["\(TAG_INSTITUTION)"]?.name],
                                                                    "frequencyForLiability"        : ["code":selectedLOVDic["\(TAG_LIABILITY_FREQUENCY)"]?.code,"name":selectedLOVDic["\(TAG_LIABILITY_FREQUENCY)"]?.name],
                                                                    "installmentAmount"            : installmentAmountView.getFieldValue(),
                                                                    "closedDate"                   : CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: closedDateView.getFieldValue(), outputFormat: Constants.DATE_FORMAT_SERVICE),
                                                                    "otherLiabilityDescription"    : "",
                                                                    "sanctionedAmount"             : sanctionAmountView.getFieldValue(),
                                                                    "loanTenure"                   : "",
                                                                    "balance"                      : principleOutstandingView.getFieldValue(),
                                                                    "emiStartDate"                 : CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: emiStartDateView.getFieldValue(), outputFormat: Constants.DATE_FORMAT_SERVICE)]]]
        
        Webservices.shared().POST(urlString: ServiceUrl.SAVE_LIABILITY_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                if let obj = AppDelegate.instance.getSpecificVC(targetClass: LiabilityListVC.self) as? LiabilityListVC {
                    obj.fetchList()
                }
                self.navigationController?.popViewController(animated: true)
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
