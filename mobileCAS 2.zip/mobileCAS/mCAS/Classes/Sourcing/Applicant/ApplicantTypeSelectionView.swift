//
//  ApplicantTypeSelectionView.swift
//  mCAS
//
//  Created by Ashutosh Mishra on 06/03/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol ApplicantTypeDelegate {
    func getSelectedOption(customerType: ApplicantType)
}

class ApplicantTypeSelectionView: UIView {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var indView: SDOptionView!
    @IBOutlet weak var corpView: SDOptionView!
    
    @IBOutlet weak var popupView: UIView!
    private var delegate: ApplicantTypeDelegate?
    
    private let indVTag = 1000
    private let corpTag = 1001
    
    func setProperties(width: CGFloat, height: CGFloat, delegate: ApplicantTypeDelegate) {
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        
        // Do any additional setup after loading the view.
        self.delegate = delegate
        
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        
        closeButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(25)
        popupView.layer.cornerRadius = 8
        
        indView.setProperties(title: "Individual", image: "tab_icon_reports", delegate: self, tag: indVTag, removeBottomMargin: true)
        
        corpView.setProperties(title: "Corporate", image: "tab_icon_reports", delegate: self, tag: corpTag, removeBottomMargin: true)
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        self.alpha = 0
    }
}

extension ApplicantTypeSelectionView: SDOptionViewDelegate {
    
    func buttonAction(tag: Int) {
        
        switch tag
        {
        case indVTag:
            delegate?.getSelectedOption(customerType: .Individual)
        case corpTag:
            delegate?.getSelectedOption(customerType: .Corporate)
        default:
            break
        }
    }
}

