//
//  SourcingSearchResultCell.swift
//  mCAS
//
//  Created by iMac on 02/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class SourcingSearchResultCell: UITableViewCell {
    
    @IBOutlet weak var userImage: UIButton!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
    @IBOutlet weak var copyButton: UIButton!
    @IBOutlet weak var bgView: UIView!
    
    func setProperties(dataObj: SearchResultModel) {
        
        nameLabel.font = CustomFont.shared().GETFONT_MEDIUM(17)
        detailLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        
        copyButton.setButtonProperties()
        
        userImage.layer.borderWidth = 1
        userImage.layer.cornerRadius = 23
        userImage.layer.borderColor = Color.LIGHTER_GRAY.cgColor
        
        bgView.setShadow()
        bgView.setCornerRadius()
        nameLabel.text = dataObj.name
        detailLabel.text = dataObj.role + dataObj.AppId
    }
    
    @IBAction func copyButtonAction(_ sender: Any) {
    }
}
