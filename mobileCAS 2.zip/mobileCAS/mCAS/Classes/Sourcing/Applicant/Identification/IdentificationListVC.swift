//
//  IdentificationListVC.swift
//  mCAS
//
//  Created by iMac on 23/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class IdentificationListVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var headerTitleView: SourcingTitleView!
    
    private enum DetailOptions: String {
        case edit = "Edit"
        case delete = "Delete"
    }
    
    private var identityModelArray = [SourcingModelClasses.IdentificationModel]()
    private var cellOptionArray: [DetailOptions] = [.edit, .delete]
    private var customerType: ApplicantType!
    private var applicationID: String!
    private var customerID: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
        fetchList()
    }
    
    func setupView() {
        
        headerTitleView.setProperties(title: "Identification")
        
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties()
        
        tableView.register(UINib(nibName: "SourcingCommonListCell", bundle: nil), forCellReuseIdentifier: "SourcingCommonListCell")
        tableView.tableFooterView = UIView()
        
    }
    
    private func setListData() {
        tableView.isHidden = self.identityModelArray.isEmpty
        noDataCapturedView.isHidden = !tableView.isHidden
        self.tableView.reloadData()
        buttonView.setProperties(showBack: true, nextBtnTitle: self.identityModelArray.isEmpty ? "Skip" : "Continue", delegate: self)
    }
    
    func setData(type: ApplicantType, applicationID: String, customerID: String) {
        self.customerType = type
        self.applicationID = applicationID
        self.customerID = customerID
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader(isHide: false, title: "Add Applicant")
        }
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        moveToDetailPage()
    }
    
    func fetchList() {
        
        let param = ["neutronCustRefNumber" : customerID]
        
        identityModelArray.removeAll()
        Webservices.shared().POST(urlString: ServiceUrl.GET_ALL_IDENTIFICATION_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [[String: Any]]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: [SourcingModelClasses.IdentificationModel].self) { list in
                    self.identityModelArray.append(contentsOf: list)
                }
            }
            self.setListData()
            
        }, failure: { (error) in
            
            self.setListData()
            
        }, noNetwork: { (error) in
            self.setListData()
        })
    }
    
    private func moveToDetailPage(index: Int? = nil) {
        var data: SourcingModelClasses.IdentificationModel?
        
        if let index = index {
            data = identityModelArray[index]
        }
        
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "AddIdentificationVC") as? AddIdentificationVC {
            vc.setData(type: customerType, applicationID: applicationID, customerID: customerID, dataObj: data)
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
    
    private func deleteDataRow(index: Int) {
        
        let param = ["neutronReferenceNumber"   : applicationID,
                     "neutronCustRefNumber"     : customerID,
                     "neutronIdentificationId"  : identityModelArray[index].neutronIdentificationId]
        
        Webservices.shared().POST(urlString: ServiceUrl.DELETE_IDENTIFICATION_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                self.identityModelArray.remove(at: index)
                self.setListData()
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
}

extension IdentificationListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return identityModelArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SourcingCommonListCell", for: indexPath) as! SourcingCommonListCell
        
        cell.setProperties(optionArray: cellOptionArray.map({ $0.rawValue }), cellIndex: indexPath.row, delegate: self)
        cell.label1.text = CommonUtils.shared().getValidatedString(string: identityModelArray[indexPath.row].identificationType?.name)
        cell.label2.text = CommonUtils.shared().getValidatedString(string: identityModelArray[indexPath.row].identificationValue)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        moveToDetailPage(index: indexPath.row)
    }
    
}

extension IdentificationListVC : NextBackButtonDelegate {
    func nextButtonAction() {
        if customerType == .Corporate {
            let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "SourcingAddressListVC") as? SourcingAddressListVC {
                vc.setData(type: customerType, applicationID: applicationID, customerID: customerID)
                AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
            }
        }
        else {
            let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "EmploymentListVC") as? EmploymentListVC {
                vc.setData(type: customerType, applicationID: applicationID, customerID: customerID)
                AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
            }
        }
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension IdentificationListVC : CommonListCellDelegate {
    
    func selectedIndex(index: Int, cellIndex: Int, cellSection: Int) {
        let item = self.cellOptionArray[index]
        if item == .edit {
            moveToDetailPage(index: cellIndex)
        }
        else if item == .delete {
            CommonAlert.shared().showAlert(message: "Are you sure you want to delete identification details?", cancelTitle: "Cancel" , okAction: { _ in
                self.deleteDataRow(index: cellIndex)
            })
        }
    }
}
