//
//  AddIdentificationVC.swift
//  mCAS
//
//  Created by iMac on 23/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddIdentificationVC: UIViewController {
    
    @IBOutlet weak var identificationTypeLOV: LOVFieldView!
    @IBOutlet weak var identificationNumberView: CustomTextFieldView!
    @IBOutlet weak var issueDateView: CustomTextFieldView!
    @IBOutlet weak var expiryDateView: CustomTextFieldView!
    @IBOutlet weak var issuingCountryLOV: LOVFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private let TAG_IDENTIFICATION = 1000
    private let TAG_COUNTRY = 1001
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var dropDownList = [DropDown]()
    private var customerType: ApplicantType!
    private var applicationID: String!
    private var customerID: String!
    private var dataObj: SourcingModelClasses.IdentificationModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    private func setupView() {
        var parentKey = Constants.ID_TYPE_INDV
        
        if self.customerType == .Corporate {
            parentKey = Constants.ID_TYPE_CORP
        }
        
        identificationTypeLOV.setLOVProperties(masterName: Entity.ID_TYPE, title: "Identification Type", tag: TAG_IDENTIFICATION, delegate: self, parentKey: parentKey)
        issuingCountryLOV.setLOVProperties(masterName: Entity.COUNTRY, title: "Issuing Country", tag: TAG_COUNTRY, delegate: self)
        
        identificationNumberView.setProperties(placeHolder: "Identification No.", delegate: self)
        
        let stDate = Date().addingTimeInterval(-1*24*60*60)
        issueDateView.setProperties(placeHolder: "Issue Date", type: .DATE, delegate: self, maximumDate: stDate)
        
        let endDate = Date().addingTimeInterval(1*24*60*60)
        expiryDateView.setProperties(placeHolder: "Expiry Date", type: .DATE, delegate: self, minimumDate: endDate, maximumDate: nil)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        fillDataInEditMode(dataObj: dataObj)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Identification")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader()
        }
    }
    
    func setData(type: ApplicantType, applicationID: String, customerID: String, dataObj: SourcingModelClasses.IdentificationModel? = nil) {
        self.customerType = type
        self.applicationID = applicationID
        self.customerID = customerID
        self.dataObj = dataObj
    }
    
    private func refreshFieldData() {
        identificationNumberView.setFieldValue()
        issueDateView.setFieldValue()
        expiryDateView.setFieldValue()
    }
    
    private func fillDataInEditMode(dataObj: SourcingModelClasses.IdentificationModel?) {
        
        if let data = dataObj
        {
            identificationTypeLOV.autoFillLOVBy(key: data.identificationType?.code)
            
            issuingCountryLOV.autoFillLOVBy(key: data.issuingCountry?.code)
            
            identificationNumberView.setFieldValue(text: data.identificationValue)
            issueDateView.setFieldValue(text: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: dataObj?.issueDate))
            expiryDateView.setFieldValue(text: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: data.expiryDate))
            
            buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Update", delegate: self)
        }
        validateFields()
    }
    
}


extension AddIdentificationVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = !(selectedLOVDic["\(TAG_IDENTIFICATION)"] == nil || selectedLOVDic["\(TAG_COUNTRY)"] == nil || identificationNumberView.getFieldValue().isEmpty)
        
        if isEnabled, let selectedObj = selectedLOVDic["\(TAG_IDENTIFICATION)"]
        {
            if selectedObj.code.lowercased() == ConstantCodes.ID_TYPE_DL.lowercased() {
                isEnabled = (isEnabled && !(issueDateView.getFieldValue().isEmpty || expiryDateView.getFieldValue().isEmpty))
            }
            else if selectedObj.code.lowercased() == ConstantCodes.ID_TYPE_PASSPORT.lowercased() {
                isEnabled = (isEnabled && !expiryDateView.getFieldValue().isEmpty)
            }
            else if selectedObj.code.lowercased() == ConstantCodes.ID_TYPE_PAN.lowercased() {
                isEnabled = (isEnabled && identificationNumberView.getFieldValue().validatePAN)
            }
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        if let selectedObj = selectedLOVDic["\(TAG_IDENTIFICATION)"]
        {
            if selectedObj.code.lowercased() == ConstantCodes.ID_TYPE_AADHAR.lowercased() {
                return text.isNumeric && text.count <= Constants.AADHAR_LENGTH
            }
            else if selectedObj.code.lowercased() == ConstantCodes.ID_TYPE_PAN.lowercased() {
                return text.isAlphanumeric && text.count <= Constants.PAN_LENGTH
            }
            else {
                return text.isAlphanumeric && text.count <= Constants.TEXTFIELD_ID_LENGTH
            }
        }
        
        return text.isAlphanumeric
    }
}

extension AddIdentificationVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_IDENTIFICATION
        {
            if selectedObj.code.lowercased() == ConstantCodes.ID_TYPE_DL.lowercased() {
                setFields(issueDateOptional: false, expiryDateOptional: false)
            }
            else if selectedObj.code.lowercased() == ConstantCodes.ID_TYPE_PASSPORT.lowercased() {
                setFields(expiryDateOptional: false)
            }
            else {
                setFields()
            }
        }
        validateFields()
    }
    
    private func setFields(issueDateOptional: Bool = true, expiryDateOptional: Bool = true) {
        
        refreshFieldData()
        
        if issueDateOptional {
            issueDateView.setFieldPlaceHolder(placeHolder: "Issue Date (Optional)")
        }
        else {
            issueDateView.setFieldPlaceHolder(placeHolder: "Issue Date")
        }
        
        if expiryDateOptional {
            expiryDateView.setFieldPlaceHolder(placeHolder: "Expiry Date (Optional)")
        }
        else {
            expiryDateView.setFieldPlaceHolder(placeHolder: "Expiry Date")
        }
    }
}

extension AddIdentificationVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        if let fromDate = CustomDateFormatter.shared().getRespectiveDateFromString(inputString: issueDateView.getFieldValue()),
            let toDate = CustomDateFormatter.shared().getRespectiveDateFromString(inputString: expiryDateView.getFieldValue())
        {
            if fromDate.timeDifferenceInSeconds(toDate: toDate) < 0 {
                CommonAlert.shared().showAlert(message: "expiry date must be greater than issue date")
                return
            }
        }
        
        var identificationID = ""
        
        if let dataObj = dataObj {
            identificationID = dataObj.neutronIdentificationId!
        }
        else {
            identificationID = "\(CommonUtils.shared().getValidatedString(string: self.customerID))_\(CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_IDENTIFICATION)"]?.code))"
        }
        
        let param: [String : Any] = ["neutronReferenceNumber"   : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                     "neutronCustRefNumber"     : CommonUtils.shared().getValidatedString(string: self.customerID),
                                     "identificationDetails"    : [["neutronIdentificationId"   : CommonUtils.shared().getValidatedString(string: identificationID),
                                                                    "identificationValue"       : identificationNumberView.getFieldValue(),
                                                                    "issueDate"                 : CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: issueDateView.getFieldValue(), outputFormat: Constants.DATE_FORMAT_SERVICE),
                                                                    "expiryDate"                : CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: expiryDateView.getFieldValue(), outputFormat: Constants.DATE_FORMAT_SERVICE),
                                                                    "issuingCountry"            : ["code":selectedLOVDic["\(TAG_COUNTRY)"]?.code,"name":selectedLOVDic["\(TAG_COUNTRY)"]?.name],
                                                                    "identificationType"        : ["code":selectedLOVDic["\(TAG_IDENTIFICATION)"]?.code,"name":selectedLOVDic["\(TAG_IDENTIFICATION)"]?.name],
                                                                    "validatePan"               : false]]]
        
        
        Webservices.shared().POST(urlString: ServiceUrl.SAVE_IDENTIFICATION_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                if let obj = AppDelegate.instance.getSpecificVC(targetClass: IdentificationListVC.self) as? IdentificationListVC {
                    obj.fetchList()
                }
                
                self.navigationController?.popViewController(animated: true)
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
