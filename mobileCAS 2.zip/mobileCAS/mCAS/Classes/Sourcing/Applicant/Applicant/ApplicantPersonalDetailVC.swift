//
//  ApplicantPersonalDetailVC.swift
//  mCAS
//
//  Created by iMac on 21/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class ApplicantPersonalDetailVC: UIViewController {
    
    //Individual
    @IBOutlet weak var headerTitleView: SourcingTitleView!
    @IBOutlet weak var salutationLOV: LOVFieldView!
    @IBOutlet weak var salutationLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var firstNameView: CustomTextFieldView!
    @IBOutlet weak var firstNameViewHeight: NSLayoutConstraint!
    @IBOutlet weak var middleNameView: CustomTextFieldView!
    @IBOutlet weak var middleNameViewHeight: NSLayoutConstraint!
    @IBOutlet weak var lastNameView: CustomTextFieldView!
    @IBOutlet weak var lastNameViewHeight: NSLayoutConstraint!
    @IBOutlet weak var genderLOV: LOVFieldView!
    @IBOutlet weak var genderLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var dateOfBirthView: CustomTextFieldView!
    @IBOutlet weak var dateOfBirthViewHeight: NSLayoutConstraint!
    @IBOutlet weak var fathersNameView: CustomTextFieldView!
    @IBOutlet weak var fathersNameViewHeight: NSLayoutConstraint!
    @IBOutlet weak var mothersMaidenNameView: CustomTextFieldView!
    @IBOutlet weak var mothersMaidenNameViewHeight: NSLayoutConstraint!
    @IBOutlet weak var maritalStatusLOV: LOVFieldView!
    @IBOutlet weak var maritalStatusLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var houseHoldTypeLOV: LOVFieldView!
    @IBOutlet weak var houseHoldTypeLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var noOfDependantView: CustomStepperView!
    @IBOutlet weak var noOfDependantViewHeight: NSLayoutConstraint!
    @IBOutlet weak var noOfChildDependants: CustomStepperView!
    @IBOutlet weak var noOfChildDependantsHeight: NSLayoutConstraint!
    @IBOutlet weak var categoryLOV: LOVFieldView!
    @IBOutlet weak var categoryLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var citizenshipLOV: LOVFieldView!
    @IBOutlet weak var citizenshipLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var residentialStatusLOV: LOVFieldView!
    @IBOutlet weak var residentialStatusLOVHeight: NSLayoutConstraint!
    
    
    //Corporate
    @IBOutlet weak var applicantTypeLOV: LOVFieldView!
    @IBOutlet weak var applicantTypeLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var institutionNameView: CustomTextFieldView!
    @IBOutlet weak var institutionNameViewHeight: NSLayoutConstraint!
    @IBOutlet weak var incorporationDateView: CustomTextFieldView!
    @IBOutlet weak var incorporationDateViewHeight: NSLayoutConstraint!
    @IBOutlet weak var natureOfBusinessLOV: LOVFieldView!
    @IBOutlet weak var natureOfBusinessLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var industryClassificationLOV: LOVFieldView!
    @IBOutlet weak var industryClassificationLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var industryLOV: LOVFieldView!
    @IBOutlet weak var industryLOVHeight: NSLayoutConstraint!
    
    //Common
    @IBOutlet weak var emailView: CustomTextFieldView!
    @IBOutlet weak var mobileNoView: CustomMobileNumberView!
    @IBOutlet weak var constitutionLOV: LOVFieldView!
    @IBOutlet weak var phoneNoView: CustomPhoneNumberView!
    @IBOutlet weak var languageLOV: LOVFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var relationShipLOV: LOVFieldView!
    @IBOutlet weak var relationShipLOVHeight: NSLayoutConstraint!
    
    private let TAG_SALUTATION          = 1000
    private let TAG_GENDER              = 1001
    private let TAG_MARITAL             = 1002
    private let TAG_CATEGORY            = 1003
    private let TAG_CITIZENSHIP         = 1004
    private let TAG_RESIDENTIAL_STATUS  = 1005
    private let TAG_LANGUAGE            = 1006
    private let TAG_COUNTRY_CODE_PHONE  = 1007
    private let TAG_COUNTRY_CODE_MOBILE = 1008
    private let TAG_APPLICANT_TYPE      = 1009
    private let TAG_NATURE_OF_BUSINESS  = 1010
    private let TAG_CONSTITUTION        = 1011
    private let TAG_INDUSTRY_CLASS      = 1012
    private let TAG_INDUSTRY            = 1013
    private let TAG_HOUSE_HOLD          = 1014
    private let TAG_RELEATIONSHIP       = 1015
    
    
    private let TAG_NAME                = 10000
    private let TAG_INSTITUTION_NAME    = 10001
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var customerType: ApplicantType!
    
    private var applicationID: String!
    private var customerID: String!
    private var applicationType: DropDown!
    private var productCategory: LoanType!
    private var dataObj: SourcingModelClasses.ApplicantModel!
    private var applicantRoleCode: String!
    private var primaryApplicantType: String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        if customerType == .Corporate {
            headerTitleView.setProperties(title: "Corporate")
            salutationLOVHeight.constant = 0
            firstNameViewHeight.constant = 0
            middleNameViewHeight.constant = 0
            lastNameViewHeight.constant = 0
            genderLOVHeight.constant = 0
            dateOfBirthViewHeight.constant = 0
            fathersNameViewHeight.constant = 0
            mothersMaidenNameViewHeight.constant = 0
            maritalStatusLOVHeight.constant = 0
            houseHoldTypeLOVHeight.constant = 0
            noOfDependantViewHeight.constant = 0
            noOfChildDependantsHeight.constant = 0
            categoryLOVHeight.constant = 0
            citizenshipLOVHeight.constant = 0
            residentialStatusLOVHeight.constant = 0
            
            applicantTypeLOVHeight.constant = 65
            institutionNameViewHeight.constant = 65
            incorporationDateViewHeight.constant = 65
            natureOfBusinessLOVHeight.constant = 65
            industryClassificationLOVHeight.constant = 65
            industryLOVHeight.constant = 65
            
            applicantTypeLOV.setLOVProperties(masterName: Entity.APPLTYPE, title: "Applicant Type", tag: TAG_APPLICANT_TYPE, delegate: self, enable: false)
            applicantTypeLOV.autoFillLOVBy(key: applicantRoleCode)
            
            natureOfBusinessLOV.setLOVProperties(masterName: Entity.BUSINESS_NATURE, title: "Nature Of Business", tag: TAG_NATURE_OF_BUSINESS, delegate: self)
            industryClassificationLOV.setLOVProperties(masterName: Entity.INDUSTRY_CLAS, title: "Industry Classification", tag: TAG_INDUSTRY_CLASS, delegate: self)
            industryLOV.setLOVProperties(masterName: Entity.INDUSTRY, title: "Industry", tag: TAG_INDUSTRY, delegate: self)
            languageLOV.setLOVProperties(masterName: Entity.PREFERRED_LANGUAGE, title: "Preferred Language Of Communication", tag: TAG_LANGUAGE, delegate: self)
            
            institutionNameView.setProperties(placeHolder: "Institution Name", delegate: self, tag: TAG_INSTITUTION_NAME)
            incorporationDateView.setProperties(placeHolder: "Incorporation Date", type: .DATE, delegate: self)
            phoneNoView.setProperties(tag: TAG_COUNTRY_CODE_PHONE, delegate: self, phoneViewdelegate: self)
            emailView.setProperties(placeHolder: "Email Id", type: .Email, delegate: self)
        }
        else {
            headerTitleView.setProperties(title: "Personal")
            
            firstNameView.setProperties(placeHolder: "First Name", delegate: self, tag: TAG_NAME)
            
            middleNameView.setProperties(placeHolder: "Middle Name", delegate: self, tag: TAG_NAME)
            
            lastNameView.setProperties(placeHolder: "Last Name", delegate: self, tag: TAG_NAME)
            
            dateOfBirthView.setProperties(placeHolder: "Date Of Birth", type: .DOB, delegate: self)
            
            fathersNameView.setProperties(placeHolder: "Father's Full Name (Optional)", delegate: self, tag: TAG_NAME)
            
            mothersMaidenNameView.setProperties(placeHolder: "Mother's Maiden Name", delegate: self, tag: TAG_NAME)
            
            salutationLOV.setLOVProperties(masterName: Entity.SALUTATION, title: "Salutation", tag: TAG_SALUTATION, delegate: self)
            genderLOV.setLOVProperties(masterName: Entity.GENDER, title: "Gender", tag: TAG_GENDER, delegate: self)
            maritalStatusLOV.setLOVProperties(masterName: Entity.MARITAL, title: "Marital Status", tag: TAG_MARITAL, delegate: self)
            
            houseHoldTypeLOV.setLOVProperties(masterName: Entity.HOUSEHOLD_TYPE_ENTITY, title: "House Hold Type", tag: TAG_HOUSE_HOLD, delegate: self)
            
            categoryLOV.setLOVProperties(masterName: Entity.CUSTOMER_CATEGORY, title: "Category", tag: TAG_CATEGORY, delegate: self)
            citizenshipLOV.setLOVProperties(masterName: Entity.CITIZEN, title: "Citizenship", tag: TAG_CITIZENSHIP, delegate: self)
            residentialStatusLOV.setLOVProperties(masterName: Entity.RESIDENT_TYPE, title: "Residential Status", tag: TAG_RESIDENTIAL_STATUS, delegate: self)
            languageLOV.setLOVProperties(masterName: Entity.PREFERRED_LANGUAGE, title: "Preferred Language Of Communication", tag: TAG_LANGUAGE, delegate: self)
            
            noOfDependantView.setProperties(title: "No. of Adult Dependants")
            noOfChildDependants.setProperties(title: "No. of Child Dependants")
            phoneNoView.setProperties(tag: TAG_COUNTRY_CODE_PHONE, delegate: self, phoneViewdelegate: self, isFieldOptional: true)
            emailView.setProperties(placeHolder: "Email Id (Optional)", type: .Email, delegate: self)
        }
        
        constitutionLOV.setLOVProperties(masterName: Entity.CONSTITUTION, title: "Constitution", tag: TAG_CONSTITUTION, delegate: self)
    
        mobileNoView.setProperties(tag: TAG_COUNTRY_CODE_MOBILE, lovDelegate: self, tfDelegate: self)
        buttonView.setProperties(nextBtnTitle: "Continue", delegate: self)
        
        //SK Change 
        if self.applicantRoleCode != Constants.APPLICANT_ROLE_CODE_PRIMARY {
            var parentKey = ""

            if let primaryAppType = primaryApplicantType {
                parentKey = "\(primaryAppType)\(self.customerType == .Corporate ? "N" : "I")"
            }
            
            relationShipLOVHeight.constant = 65
            relationShipLOV.setLOVProperties(masterName: Entity.RELATION, title: "Relationship", tag: TAG_RELEATIONSHIP, delegate: self, parentKey: parentKey)
        }
        
        fillDataInEditMode(dataObj: dataObj)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            headerView.showHideStepHeader(isHide: false, title: "Add Applicant", landingPage: AppDelegate.instance.getSpecificVC(targetClass: ApplicantListVC.self))
            bottomView.isHidden = true
        }
    }
    
    func setData(type: ApplicantType, productCategory: LoanType, applicationType: DropDown, applicationID: String, dataObj: SourcingModelClasses.ApplicantModel? = nil, applicantRoleCode: String, primaryApplicantType: String? = nil) {
        self.customerType = type
        self.productCategory = productCategory
        self.applicationType = applicationType
        self.applicationID = applicationID
        self.dataObj = dataObj
        self.applicantRoleCode = applicantRoleCode
        self.primaryApplicantType = primaryApplicantType
        
        if let dataObj = dataObj {
            //Edit Mode
            self.customerID = dataObj.neutronCustRefNumber
        }
        else {
            //Add New
            self.customerID = SourcingCommonUtil.shared().generateCustomerID(tempAppID: self.applicationID, isPrimary: (applicantRoleCode == Constants.APPLICANT_ROLE_CODE_PRIMARY))
        }
    }
    
    private func fillDataInEditMode(dataObj: SourcingModelClasses.ApplicantModel?) {
        if let data = dataObj {
            
            if customerType == .Corporate {
                applicantTypeLOV.autoFillLOVBy(key: data.applicantRole?.code)
                
                natureOfBusinessLOV.autoFillLOVBy(key: data.natureOfBusiness?.code)
                
                industryClassificationLOV.autoFillLOVBy(key: data.industryClassification?.code)
                
                industryLOV.autoFillLOVBy(key: data.industry?.code)
                
                institutionNameView.setFieldValue(text: data.institutionName)
                incorporationDateView.setFieldValue(text: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: data.incorporationDate))
            }
            else {
                salutationLOV.autoFillLOVBy(key: data.salutation?.code)
                
                genderLOV.autoFillLOVBy(key: data.gender?.code)
                
                maritalStatusLOV.autoFillLOVBy(key: data.maritalStatus?.code)
                
                houseHoldTypeLOV.autoFillLOVBy(key: data.householdType?.code)
                
                categoryLOV.autoFillLOVBy(key: data.customerCategory?.code)
                
                citizenshipLOV.autoFillLOVBy(key: data.nationality?.code)
                
                residentialStatusLOV.autoFillLOVBy(key: data.residentialStatus?.code)
                
                firstNameView.setFieldValue(text: data.firstName)
                middleNameView.setFieldValue(text: data.middleName)
                lastNameView.setFieldValue(text: data.lastName)
                dateOfBirthView.setFieldValue(text: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: data.dateOfBirth))
                fathersNameView.setFieldValue(text: data.fatherName)
                mothersMaidenNameView.setFieldValue(text: data.motherMaidenName)
                noOfDependantView.textFieldView.setFieldValue(text: "\(data.numOfDependents ?? 0)")
                noOfChildDependants.textFieldView.setFieldValue(text: "\(data.numOfChildDependents ?? 0)")
            }
            
            if self.applicantRoleCode != Constants.APPLICANT_ROLE_CODE_PRIMARY {
                relationShipLOV.autoFillLOVBy(key: data.partyRelationship?.code)
            }
            
            constitutionLOV.autoFillLOVBy(key: data.constitution?.code)
            
            languageLOV.autoFillLOVBy(key: data.preferredLanguage?.code)
            
            mobileNoView.setAutoFillMobileNumber(countryKey: data.isdCode?.code, mobileNumber: data.mobileNumber ?? "")
            
            phoneNoView.setAutoFillPhoneNumber(countryKey: data.isdCodePhoneNo?.code, std: data.stdCode ?? "", phoneNumber: data.phoneNumber ?? "")
            
            emailView.setFieldValue(text: data.emailAddress)
        }
        validateFields()
    }
}

extension ApplicantPersonalDetailVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        if customerType == .Corporate {
            isEnabled = !(selectedLOVDic["\(TAG_APPLICANT_TYPE)"] == nil || institutionNameView.getFieldValue().isEmpty || incorporationDateView.getFieldValue().isEmpty  || selectedLOVDic["\(TAG_NATURE_OF_BUSINESS)"] == nil || selectedLOVDic["\(TAG_CONSTITUTION)"] == nil || selectedLOVDic["\(TAG_INDUSTRY_CLASS)"] == nil || selectedLOVDic["\(TAG_INDUSTRY)"] == nil || !emailView.getFieldValue().isValidEmail || selectedLOVDic["\(TAG_COUNTRY_CODE_MOBILE)"] == nil || !mobileNoView.mobileNoTFView.getFieldValue().isValidPhone || selectedLOVDic["\(TAG_COUNTRY_CODE_PHONE)"] == nil || phoneNoView.stdCodeView.getFieldValue().isEmpty || phoneNoView.phoneNumberTFView.getFieldValue().isEmpty || selectedLOVDic["\(TAG_LANGUAGE)"] == nil)
        }
        else {
            isEnabled = !(selectedLOVDic["\(TAG_SALUTATION)"] == nil || firstNameView.getFieldValue().isEmpty || lastNameView.getFieldValue().isEmpty  || selectedLOVDic["\(TAG_GENDER)"] == nil || dateOfBirthView.getFieldValue().isEmpty || mothersMaidenNameView.getFieldValue().isEmpty || selectedLOVDic["\(TAG_MARITAL)"] == nil || selectedLOVDic["\(TAG_HOUSE_HOLD)"] == nil || selectedLOVDic["\(TAG_CONSTITUTION)"] == nil ||  noOfDependantView.getFieldValue().isEmpty || noOfChildDependants.getFieldValue().isEmpty || selectedLOVDic["\(TAG_CATEGORY)"] == nil || selectedLOVDic["\(TAG_CITIZENSHIP)"] == nil || selectedLOVDic["\(TAG_RESIDENTIAL_STATUS)"] == nil || selectedLOVDic["\(TAG_COUNTRY_CODE_MOBILE)"] == nil || !mobileNoView.mobileNoTFView.getFieldValue().isValidPhone || selectedLOVDic["\(TAG_LANGUAGE)"] == nil)
        }
        
        if self.applicantRoleCode != Constants.APPLICANT_ROLE_CODE_PRIMARY {
            isEnabled = isEnabled && !(selectedLOVDic["\(TAG_RELEATIONSHIP)"] == nil)
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_NAME, TAG_INSTITUTION_NAME:
            return text.validateName
            
        default:
            return true
        }
    }
}


extension ApplicantPersonalDetailVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        if customerType == .Individual, !emailView.getFieldValue().isEmpty, !emailView.getFieldValue().isValidEmail {
            CommonAlert.shared().showAlert(message: "Please enter valid email Id")
            return
        }
	
        var paramApplicant: [String : Any] = [:]
        
        paramApplicant["neutronCustRefNumber"]  = CommonUtils.shared().getValidatedString(string: self.customerID)
        paramApplicant["mobileNumber"]          = mobileNoView.mobileNoTFView.getFieldValue()
        paramApplicant["stdCode"]               = phoneNoView.stdCodeView.getFieldValue()
        paramApplicant["phoneNumber"]           = phoneNoView.phoneNumberTFView.getFieldValue()
        paramApplicant["isBasicDetails"]        = true
        paramApplicant["emailAddress"]          = emailView.getFieldValue()
        paramApplicant["preferredLanguage"]     = ["code":selectedLOVDic["\(TAG_LANGUAGE)"]?.code, "name":selectedLOVDic["\(TAG_LANGUAGE)"]?.name]
        paramApplicant["isdCodePhoneNo"]        = ["code":selectedLOVDic["\(TAG_COUNTRY_CODE_PHONE)"]?.code, "name":selectedLOVDic["\(TAG_COUNTRY_CODE_PHONE)"]?.name]
        paramApplicant["isdCode"]               = ["code":selectedLOVDic["\(TAG_COUNTRY_CODE_MOBILE)"]?.code, "name":selectedLOVDic["\(TAG_COUNTRY_CODE_MOBILE)"]?.name]
        paramApplicant["constitution"]          = ["code":selectedLOVDic["\(TAG_CONSTITUTION)"]?.code, "name":selectedLOVDic["\(TAG_CONSTITUTION)"]?.name]
        paramApplicant["applicantRole"]         = ["code":self.applicantRoleCode]
        
        if self.applicantRoleCode != Constants.APPLICANT_ROLE_CODE_PRIMARY {
            paramApplicant["partyRelationship"]     = ["code":selectedLOVDic["\(TAG_RELEATIONSHIP)"]?.code, "name":selectedLOVDic["\(TAG_RELEATIONSHIP)"]?.name]
        }
        
        if (customerType == .Corporate) {
            paramApplicant["institutionName"]           = institutionNameView.getFieldValue()
            paramApplicant["incorporationDate"]         = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: incorporationDateView.getFieldValue(), outputFormat: Constants.DATE_FORMAT_SERVICE)
            paramApplicant["customerType"]              = ["code":Constants.CUSTOMER_TYPE_CORP]
            paramApplicant["industry"]                  = ["code":selectedLOVDic["\(TAG_INDUSTRY)"]?.code, "name":selectedLOVDic["\(TAG_INDUSTRY)"]?.name]
            paramApplicant["industryClassification"]    = ["code":selectedLOVDic["\(TAG_INDUSTRY_CLASS)"]?.code, "name":selectedLOVDic["\(TAG_INDUSTRY_CLASS)"]?.name]
            paramApplicant["natureOfBusiness"]          = ["code":selectedLOVDic["\(TAG_NATURE_OF_BUSINESS)"]?.code, "name":selectedLOVDic["\(TAG_NATURE_OF_BUSINESS)"]?.name]
        }
        else {
            paramApplicant["firstName"]                 = firstNameView.getFieldValue()
            paramApplicant["middleName"]                = middleNameView.getFieldValue()
            paramApplicant["lastName"]                  = lastNameView.getFieldValue()
            paramApplicant["dateOfBirth"]               = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: dateOfBirthView.getFieldValue(), outputFormat: Constants.DATE_FORMAT_SERVICE)
            paramApplicant["fatherName"]                = fathersNameView.getFieldValue()
            paramApplicant["motherMaidenName"]          = mothersMaidenNameView.getFieldValue()
            paramApplicant["numOfDependents"]           = noOfDependantView.getFieldValue()
            paramApplicant["numOfChildDependents"]      = noOfChildDependants.getFieldValue()
            paramApplicant["customerType"]              = ["code":Constants.CUSTOMER_TYPE_INDV]
            paramApplicant["gender"]                    = ["code":selectedLOVDic["\(TAG_GENDER)"]?.code, "name":selectedLOVDic["\(TAG_GENDER)"]?.name]
            paramApplicant["maritalStatus"]             = ["code":selectedLOVDic["\(TAG_MARITAL)"]?.code, "name":selectedLOVDic["\(TAG_MARITAL)"]?.name]
            paramApplicant["customerCategory"]          = ["code":selectedLOVDic["\(TAG_CATEGORY)"]?.code, "name":selectedLOVDic["\(TAG_CATEGORY)"]?.name]
            paramApplicant["nationality"]               = ["code":selectedLOVDic["\(TAG_CITIZENSHIP)"]?.code, "name":selectedLOVDic["\(TAG_CITIZENSHIP)"]?.name]
            paramApplicant["residentialStatus"]         = ["code":selectedLOVDic["\(TAG_RESIDENTIAL_STATUS)"]?.code, "name":selectedLOVDic["\(TAG_RESIDENTIAL_STATUS)"]?.name]
            paramApplicant["salutation"]                = ["code":selectedLOVDic["\(TAG_SALUTATION)"]?.code, "name":selectedLOVDic["\(TAG_SALUTATION)"]?.name]
            paramApplicant["householdType"]             = ["code":selectedLOVDic["\(TAG_HOUSE_HOLD)"]?.code, "name":selectedLOVDic["\(TAG_HOUSE_HOLD)"]?.name]
        }
        
        let param: [String : Any] = ["neutronReferenceNumber"   : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                     "neutronCustRefNumber"     : CommonUtils.shared().getValidatedString(string: self.customerID),
                                     "applicant"                : paramApplicant,
                                     "loanDetail"            	: ["productType"        : ["code": productCategory.code, "name": productCategory.name],
                                                                    "applicationType"   : ["code": applicationType.code, "name": applicationType.name]]]
        
        
        Webservices.shared().POST(urlString: ServiceUrl.SAVE_CUSTOMER_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                //SK Change - refresh applicant list - loader issue
                
                if let obj = AppDelegate.instance.getSpecificVC(targetClass: ApplicantListVC.self) as? ApplicantListVC {
                    obj.fetchList()
                }
                
                let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
                if let vc = storyboard.instantiateViewController(withIdentifier: "IdentificationListVC") as? IdentificationListVC {
                    vc.setData(type: self.customerType, applicationID: self.applicationID, customerID: self.customerID)
                    AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
                }
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
}

extension ApplicantPersonalDetailVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        validateFields()
    }
}

extension ApplicantPersonalDetailVC: CustomPhoneViewDelegate {
    
    func validatePhoneField() {
        validateFields()
    }
}
