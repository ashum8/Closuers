//
//  ApplicantListVC.swift
//  mCAS
//
//  Created by iMac on 21/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class ApplicantListVC: UIViewController {
    
    private enum DetailOptions: String {
        case edit = "Edit"
        case delete = "Delete"
        case verification = "Verification"
    }
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var addApplicantButton: UIButton!
    @IBOutlet weak var buttonViewHeight: NSLayoutConstraint!
    
    private var cellOptionArray: [DetailOptions] = [.edit, .delete, .verification]
    private var applicantListModelArray = [SourcingModelClasses.ApplicantModel]()
    
    private var applicationType: DropDown!
    private var productCategory: LoanType!
    private var applicationID: String!
    
    private var applicantRoleCode: String?
    private var applicantRoleView: ApplicantRoleSelectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties(title: "You have not added applicants yet!")
        addApplicantButton.setButtonProperties()
        
        tableView.register(UINib.init(nibName: "CasesCell", bundle: Bundle.main), forCellReuseIdentifier: "CasesCell")
        tableView.tableFooterView = UIView()
        
        buttonView.setProperties(nextBtnTitle: "Done", delegate: self)
        
        fetchList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.setTitleWith(line1: "Add Applicant", showBack: true)
        }        
    }
    
    func setData(productCategory: LoanType, applicationType: DropDown, applicationID: String? = nil) {
        self.productCategory = productCategory
        self.applicationType = applicationType
        self.applicationID = applicationID
    }
    
    private func setListData() {
        tableView.isHidden = applicantListModelArray.isEmpty
        addButton.isHidden = applicantListModelArray.isEmpty
        noDataCapturedView.isHidden = !tableView.isHidden
        addApplicantButton.isHidden = !tableView.isHidden
        buttonViewHeight.constant = tableView.isHidden ? 0 : 45
        self.tableView.reloadData()
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "AddApplicantModesVC") as? AddApplicantModesVC {
            vc.setData(productCategory: productCategory, applicationType: applicationType, applicationID: applicationID, applicantRoleCode: self.applicantRoleCode ?? Constants.APPLICANT_ROLE_CODE_PRIMARY, primaryApplicantType: getPrimaryApplicantType())
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    
    @IBAction func plusButtonAction(_ sender: Any) {
        if self.applicantRoleView == nil {
            self.applicantRoleView = .fromNib()
            self.applicantRoleView.setProperties(width: self.view.frame.size.width, height: self.view.frame.size.height, delegate: self)
            self.view.addSubview(self.applicantRoleView)
        }
        self.applicantRoleView.alpha = 1
    }
    
    private func getPrimaryApplicantType() -> String? {        
        let arr = self.applicantListModelArray.filter({ $0.applicantRole?.code?.lowercased() == Constants.APPLICANT_ROLE_CODE_PRIMARY.lowercased() })
        
        if !arr.isEmpty {
            return arr.first?.customerType.code?.lowercased() == Constants.CUSTOMER_TYPE_INDV.lowercased() ? "I" : "N"
        }
        
        return nil
    }
    
    func fetchList() {
        
        let param = ["neutronReferenceNumber" : applicationID]
        
        applicantListModelArray.removeAll()
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_ALL_CUSTOMERS_URL, paramaters: param, autoHandleLoader: true, allowOfflineAlert: false, success: { (header, responseObj) in
            
            if let response = responseObj as? [[String: Any]]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: [SourcingModelClasses.ApplicantModel].self) { list in
                    self.applicantListModelArray.append(contentsOf: list)
                }
            }
            self.setListData()
            
        }, failure: { (error) in
            
            self.setListData()
            
        }, noNetwork: { (error) in
            self.setListData()
        })
    }
    
    private func deleteDataRow(index: Int) {
        
        let param = ["neutronCustRefNumber" : applicantListModelArray[index].neutronCustRefNumber]
        
        Webservices.shared().POST(urlString: ServiceUrl.DELETE_CUSTOMER_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                self.applicantListModelArray.remove(at: index)
                self.setListData()
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
        }, noNetwork: { (error) in
        })
    }
}

extension ApplicantListVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return applicantListModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let optionArray = cellOptionArray.map({ $0.rawValue })
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CasesCell") as! CasesCell
        let model = applicantListModelArray[indexPath.row]
        cell.label1.text = model.getFullName()
        cell.label2.text = "\(model.applicantRole?.name ?? "") \(Constants.SEPERATOR) \(model.mobileNumber!)"
        
        if let firstNameChar = model.firstName?.first, let lastNameChar = model.lastName?.first, model.customerType.code?.lowercased() == Constants.CUSTOMER_TYPE_INDV.lowercased() {
            cell.textLogoLabel.text = "\(firstNameChar)\(lastNameChar)"
        }
        else if let firstNameChar = model.institutionName?.first, model.customerType.code?.lowercased() == Constants.CUSTOMER_TYPE_CORP.lowercased() {
            cell.textLogoLabel.text = "\(firstNameChar)"
        }
        
        cell.setProperties(cellIndex: indexPath.row, customerType: model.customerType.code,showOption: true, delegate: self, optionArray: optionArray, showTextLogo: true)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        moveToDetailPage(index: indexPath.row)
    }
    
    private func moveToDetailPage(index:Int) {
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "ApplicantPersonalDetailVC") as? ApplicantPersonalDetailVC {
            let model = applicantListModelArray[index]
            let customerType: ApplicantType = (model.customerType.code?.lowercased() == Constants.CUSTOMER_TYPE_INDV.lowercased()) ? .Individual : .Corporate
            
            vc.setData(type: customerType, productCategory: productCategory, applicationType: applicationType, applicationID: applicationID, dataObj: model, applicantRoleCode: model.applicantRole!.code!)
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
}

extension ApplicantListVC: NextBackButtonDelegate {
    func nextButtonAction() {
        self.navigationController?.popViewController(animated: true)
    } 
}

extension ApplicantListVC: CaseCellDelegate {
    
    func selectedIndex(index: Int, cellIndex: Int) {
        let item = self.cellOptionArray[index]
        if item == .edit {
            moveToDetailPage(index: cellIndex)
        }
        else if item == .delete {
            
            CommonAlert.shared().showAlert(message: "Are you sure you want to delete customer details?", cancelTitle: "Cancel" , okAction: { _ in
                self.deleteDataRow(index: cellIndex)
            })
        }
        else if item == .verification {
            
        }
    }
}

extension ApplicantListVC: ApplicantRoleDelegate {
    func setSelectedApplicant(role: String) {
        self.applicantRoleView.alpha = 0
        self.applicantRoleCode = role
        addApplicantButton.sendActions(for: .touchUpInside)
    }
}

