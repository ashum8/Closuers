//
//  AddEmploymentVC.swift
//  mCAS
//
//  Created by iMac on 24/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddEmploymentVC: UIViewController {
    
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var employmentTypeLOV: LOVFieldView!
    @IBOutlet weak var employerNameLOV: LOVFieldView!
    @IBOutlet weak var employerViewHeight: NSLayoutConstraint!
    @IBOutlet weak var employerNameView: CustomTextFieldView!
    @IBOutlet weak var employerNameViewHeight: NSLayoutConstraint!
    @IBOutlet weak var natureOfBusinessLOV: LOVFieldView!
    @IBOutlet weak var natureOfBViewHeight: NSLayoutConstraint!
    @IBOutlet weak var industryLOV: LOVFieldView!
    @IBOutlet weak var industryLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var employedFromView: CustomTextFieldView!
    @IBOutlet weak var employedFromViewHeight: NSLayoutConstraint!
    @IBOutlet weak var checkBoxButton: UIButton!
    @IBOutlet weak var organizationView: CustomTextFieldView!
    @IBOutlet weak var organizationViewHeight: NSLayoutConstraint!
    @IBOutlet weak var registrationNoView: CustomTextFieldView!
    @IBOutlet weak var registrationNoViewHeight: NSLayoutConstraint!
    
    private let TAG_EMP_TYPE = 1000
    private let TAG_EMPLOYER = 1001
    private let TAG_BUSINESS = 1002
    private let TAG_INDUSTRY = 1003
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var applicationID: String!
    private var customerID: String!
    private var dataObj: SourcingModelClasses.EmploymentModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        employmentTypeLOV.setLOVProperties(masterName: Entity.OCCUPATION_TYPE, title: "Employment Type", tag: TAG_EMP_TYPE, delegate: self)
        industryLOV.setLOVProperties(masterName: Entity.INDUSTRY, title: "Industry", tag: TAG_INDUSTRY, delegate: self)
        
        employedFromView.setProperties(placeHolder: "Employed From", type: .DATE, delegate: self)
        organizationView.setProperties(placeHolder: "Organization Name", type: .Text, delegate: self)
        registrationNoView.setProperties(placeHolder: "Registration Number", type: .Text, delegate: self)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        checkBoxButton.setCheckboxProperties(title: "Mark this as primary employment", isSelected: false)
        
        employerNameView.setProperties(placeHolder: "Other employer Name", type: .Text, delegate: self)
        
        fillDataInEditMode(dataObj: dataObj)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Employment")
        }
    }
    
    func setData(applicationID: String, customerID: String, dataObj: SourcingModelClasses.EmploymentModel? = nil) {
        self.applicationID = applicationID
        self.customerID = customerID
        self.dataObj = dataObj
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader()
        }
    }
    
    private func fillDataInEditMode(dataObj: SourcingModelClasses.EmploymentModel?) {
        if let data = dataObj {
            
            employmentTypeLOV.enableLOV(isEnable: false)
            employmentTypeLOV.autoFillLOVBy(key: data.occupationType?.code)
            
            employerNameLOV.autoFillLOVBy(key: data.employerName?.code)
            
            industryLOV.autoFillLOVBy(key: data.industry?.code)
            
            if data.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SEP.lowercased() {
                natureOfBusinessLOV.autoFillLOVBy(key: data.natureOfProfession?.code)
            }
            else if data.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_OTH.lowercased() {
                natureOfBusinessLOV.autoFillLOVBy(key: data.natureOfOccupation?.code)
            }
            else {
                natureOfBusinessLOV.autoFillLOVBy(key: data.natureOfBusiness?.code)
            }
            
            employedFromView.setFieldValue(text: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: data.employedFrom))
            organizationView.setFieldValue(text: data.organizationName)
            registrationNoView.setFieldValue(text: data.registrationNumber)
            
            if let name = data.otherEmployerName, !name.isEmpty {
                employerNameLOV.autoFillLOVBy(key: "Other")
                employerNameView.setFieldValue(text: data.otherEmployerName)
            }
            
            checkBoxButton.isSelected = data.majorOccupation ?? false
            buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Update", delegate: self)
        }
        validateFields()
    }
    
    @IBAction func checkBoxButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    private func refreshFieldData() {
        employedFromView.setFieldValue()
        natureOfBusinessLOV.resetLOVWithParentKey(key: "")
        industryLOV.resetLOVWithParentKey(key: "")
        employedFromView.setFieldValue()
        registrationNoView.setFieldValue()
        organizationView.setFieldValue()
        selectedLOVDic["\(TAG_BUSINESS)"] = nil
        selectedLOVDic["\(TAG_INDUSTRY)"] = nil
    }
    
    private func setFields(showEmployer: Bool = false, showNatureOfBusiness: Bool = false, showIndustry: Bool = false, showEmployedFrom: Bool = false, showRegistrationNo: Bool = false, showOrganization: Bool = false) {
        
        refreshFieldData()
        
        employerViewHeight.constant         = (showEmployer ? 65 : 0)
        natureOfBViewHeight.constant        = (showNatureOfBusiness ? 65 : 0)
        industryLOVHeight.constant          = (showIndustry ? 65 : 0)
        employedFromViewHeight.constant     = (showEmployedFrom ? 65 : 0)
        registrationNoViewHeight.constant   = (showRegistrationNo ? 65 : 0)
        organizationViewHeight.constant     = (showOrganization ? 65 : 0)
    }
}

extension AddEmploymentVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_EMP_TYPE {
            
            switch selectedObj.code {
                
            case ConstantCodes.EMP_TYPE_OTH:
                setFields(showNatureOfBusiness: true)
                natureOfBusinessLOV.setLOVProperties(masterName: Entity.NATURE_OF_OCCUPATION, title: "Nature of Occupation", tag: TAG_BUSINESS, delegate: self)
                employerNameLOV.setLOVProperties(masterName: Entity.EMPLOYER, title: "Employer Name", tag: TAG_EMPLOYER, delegate: self)
                
            case ConstantCodes.EMP_TYPE_SAL:
                setFields(showEmployer: true, showNatureOfBusiness: true, showIndustry: true, showEmployedFrom: true)
                
                natureOfBusinessLOV.setLOVProperties(masterName: Entity.BUSINESS_NATURE, title: "Nature of Business", tag: TAG_BUSINESS, delegate: self)
                
                var dropDownList = [DropDown]()
                CoreDataOperations.shared().fetchRecordsForMaster(masterName: Entity.EMPLOYER) { (records) in
                    
                    if let records = records {
                        dropDownList.append(contentsOf: records)
                    }
                }
                dropDownList.append(DropDown(code: "Other", name: "Other"))
                employerNameLOV.setLOVProperties(title: "Employer Name", tag: TAG_EMPLOYER, delegate: self, optionArray: dropDownList)
                
            case ConstantCodes.EMP_TYPE_SENP:
                setFields(showNatureOfBusiness: true, showOrganization: true)
                natureOfBusinessLOV.setLOVProperties(masterName: Entity.BUSINESS_NATURE, title: "Nature of Business", tag: TAG_BUSINESS, delegate: self)
                employerNameLOV.setLOVProperties(masterName: Entity.EMPLOYER, title: "Employer Name", tag: TAG_EMPLOYER, delegate: self)
                
            case ConstantCodes.EMP_TYPE_SEP:
                setFields(showNatureOfBusiness: true, showRegistrationNo: true, showOrganization: true)
                natureOfBusinessLOV.setLOVProperties(masterName: Entity.NATURE_OF_PROF, title: "Nature of Profession", tag: TAG_BUSINESS, delegate: self)
                employerNameLOV.setLOVProperties(masterName: Entity.EMPLOYER, title: "Employer Name", tag: TAG_EMPLOYER, delegate: self)
                
            default:
                setFields()
                employerNameLOV.setLOVProperties(masterName: Entity.EMPLOYER, title: "Employer Name", tag: TAG_EMPLOYER, delegate: self)
                natureOfBusinessLOV.setLOVProperties(masterName: Entity.BUSINESS_NATURE, title: "Nature of Business", tag: TAG_BUSINESS, delegate: self)
            }
        }
        else if btntag == TAG_EMPLOYER {
            if selectedObj.code.lowercased() == "other" {
                employerNameViewHeight.constant = 65
            }
            else {
                employerNameViewHeight.constant = 0
            }
        }
        validateFields()
    }
}

extension AddEmploymentVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = !(selectedLOVDic["\(TAG_EMP_TYPE)"] == nil)
        
        if isEnabled, let selectedObj = selectedLOVDic["\(TAG_EMP_TYPE)"]
        {
            if selectedObj.code.lowercased() == ConstantCodes.EMP_TYPE_SAL.lowercased() {
                isEnabled = !(selectedLOVDic["\(TAG_EMPLOYER)"] == nil || selectedLOVDic["\(TAG_INDUSTRY)"] == nil || employedFromView.getFieldValue().isEmpty || selectedLOVDic["\(TAG_BUSINESS)"] == nil )
                
                if selectedLOVDic["\(TAG_EMPLOYER)"]?.code.lowercased() == "other" {
                    isEnabled = isEnabled && !employerNameView.getFieldValue().isEmpty
                }
            }
            else if selectedObj.code.lowercased() == ConstantCodes.EMP_TYPE_SENP.lowercased() {
                isEnabled = !(organizationView.getFieldValue().isEmpty || selectedLOVDic["\(TAG_BUSINESS)"] == nil)
            }
            else if selectedObj.code.lowercased() == ConstantCodes.EMP_TYPE_SEP.lowercased() {
                isEnabled = !(organizationView.getFieldValue().isEmpty || registrationNoView.getFieldValue().isEmpty || selectedLOVDic["\(TAG_BUSINESS)"] == nil)
            }
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        return text.isAlphanumericAndSpace && text.count < Constants.TEXTFIELD_ID_LENGTH
    }
}

extension AddEmploymentVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        var employmentID = ""
        if let dataObj = dataObj {
            employmentID = dataObj.employmentId!
        }
        else {
            employmentID = SourcingCommonUtil.shared().generateApplicationID()
        }
        
        var paramEmployment: [String : Any] = [:]
        paramEmployment["employmentId"] = employmentID
        paramEmployment["majorOccupation"] = checkBoxButton.isSelected
        paramEmployment["otherEmployerName"] = employerNameView.getFieldValue()
        
        paramEmployment["occupationType"] = ["code":selectedLOVDic["\(TAG_EMP_TYPE)"]?.code, "name":selectedLOVDic["\(TAG_EMP_TYPE)"]?.name]
        
        if selectedLOVDic["\(TAG_EMP_TYPE)"]?.code.lowercased() == ConstantCodes.EMP_TYPE_SAL.lowercased() {
            
            paramEmployment["employerName"] = ["code":selectedLOVDic["\(TAG_EMPLOYER)"]?.code, "name":selectedLOVDic["\(TAG_EMPLOYER)"]?.name]
            paramEmployment["industry"] = ["code":selectedLOVDic["\(TAG_INDUSTRY)"]?.code, "name":selectedLOVDic["\(TAG_INDUSTRY)"]?.name]
            paramEmployment["employedFrom"] = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: employedFromView.getFieldValue(), outputFormat: Constants.DATE_FORMAT_SERVICE)
            paramEmployment["natureOfBusiness"] = ["code":selectedLOVDic["\(TAG_BUSINESS)"]?.code, "name":selectedLOVDic["\(TAG_BUSINESS)"]?.name]
            
        }
        else if selectedLOVDic["\(TAG_EMP_TYPE)"]?.code.lowercased() == ConstantCodes.EMP_TYPE_SENP.lowercased() {
            paramEmployment["organizationName"] = organizationView.getFieldValue()
            paramEmployment["natureOfBusiness"] = ["code":selectedLOVDic["\(TAG_BUSINESS)"]?.code, "name":selectedLOVDic["\(TAG_BUSINESS)"]?.name]
        }
        else if selectedLOVDic["\(TAG_EMP_TYPE)"]?.code.lowercased() == ConstantCodes.EMP_TYPE_SEP.lowercased() {
            paramEmployment["organizationName"] = organizationView.getFieldValue()
            paramEmployment["registrationNumber"] = registrationNoView.getFieldValue()
            paramEmployment["natureOfProfession"] = ["code":selectedLOVDic["\(TAG_BUSINESS)"]?.code, "name":selectedLOVDic["\(TAG_BUSINESS)"]?.name]
        }
        else if selectedLOVDic["\(TAG_EMP_TYPE)"]?.code.lowercased() == ConstantCodes.EMP_TYPE_OTH.lowercased() {
            paramEmployment["natureOfOccupation"] = ["code":selectedLOVDic["\(TAG_BUSINESS)"]?.code, "name":selectedLOVDic["\(TAG_BUSINESS)"]?.name]
        }
        
        
        let param: [String : Any] = ["neutronReferenceNumber"   : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                     "neutronCustRefNumber"     : CommonUtils.shared().getValidatedString(string: self.customerID),
                                     "employmentDetails"        : [paramEmployment]]
        
        
        Webservices.shared().POST(urlString: ServiceUrl.SAVE_EMPLOYMENT_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                if let obj = AppDelegate.instance.getSpecificVC(targetClass: EmploymentListVC.self) as? EmploymentListVC {
                    obj.fetchList()
                }
                self.navigationController?.popViewController(animated: true)
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
        
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
