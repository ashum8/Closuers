//
//  EmploymentListVC.swift
//  mCAS
//
//  Created by iMac on 23/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class EmploymentListVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var headerTitleView: SourcingTitleView!
    
    private enum DetailOptions: String {
        case edit = "Edit"
        case delete = "Delete"
    }
    
    private var applicationID: String!
    private var customerID: String!
    private var customerType: ApplicantType!

    private var employmentModelArray = [SourcingModelClasses.EmploymentModel]()
    private var cellOptionArray: [DetailOptions] = [.edit, .delete]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
        fetchList()
    }
    
    private func setupView() {
        
        headerTitleView.setProperties(title: "Employment")
        
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties()
        
        tableView.register(UINib(nibName: "SourcingCommonListCell", bundle: nil), forCellReuseIdentifier: "SourcingCommonListCell")
        tableView.tableFooterView = UIView()
        
    }
    
    private func setListData() {
        tableView.isHidden = employmentModelArray.isEmpty
        noDataCapturedView.isHidden = !tableView.isHidden
        self.tableView.reloadData()
        buttonView.setProperties(showBack: true, nextBtnTitle: self.employmentModelArray.isEmpty ? "Skip" : "Continue", delegate: self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader(isHide: false, title: "Add Applicant")
        }
    }
    
    func setData(type: ApplicantType, applicationID: String, customerID: String) {
        self.customerType = type
        self.applicationID = applicationID
        self.customerID = customerID
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        moveToDetailPage()
    }
    
    func fetchList() {
        
        let param = ["neutronCustRefNumber" : customerID]
        
        employmentModelArray.removeAll()
        Webservices.shared().POST(urlString: ServiceUrl.GET_ALL_EMPLOYMENT_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [[String: Any]]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: [SourcingModelClasses.EmploymentModel].self) { list in
                    self.employmentModelArray.append(contentsOf: list)
                    self.employmentModelArray = SourcingCommonUtil.shared().sortEmploymentBasedOnOccupationType(list: self.employmentModelArray)
                }
            }
            self.setListData()
            
        }, failure: { (error) in
            
            self.setListData()
            
        }, noNetwork: { (error) in
            self.setListData()
        })
    }
    
    private func moveToDetailPage(index: Int? = nil) {
        var data: SourcingModelClasses.EmploymentModel?
        
        if let index = index {
            data = employmentModelArray[index]
        }
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "AddEmploymentVC") as? AddEmploymentVC {
            vc.setData(applicationID: applicationID, customerID: customerID, dataObj: data)
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
    
    private func deleteDataRow(index: Int) {
        
        let param: [String : Any] = ["neutronReferenceNumber"   : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                     "neutronCustRefNumber"     : CommonUtils.shared().getValidatedString(string: self.customerID),
                                     "employmentDetails"        : [["employmentId":employmentModelArray[index].employmentId]]]
        
        Webservices.shared().POST(urlString: ServiceUrl.DELETE_EMPLOYMENT_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                self.employmentModelArray.remove(at: index)
                self.setListData()
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
}

extension EmploymentListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return employmentModelArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let model = employmentModelArray[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SourcingCommonListCell", for: indexPath) as! SourcingCommonListCell
        cell.setProperties(optionArray: cellOptionArray.map({ $0.rawValue }), cellIndex: indexPath.row, delegate: self, showStatus: model.majorOccupation ?? false)
        
        if model.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SAL.lowercased() {
            if let name = model.otherEmployerName, !name.isEmpty {
                cell.label1.text = name
            }
            else {
                cell.label1.text = model.employerName?.name
            }
            
            cell.label2.text = "\(model.occupationType?.name ?? "") \(Constants.SEPERATOR) \(model.industry?.name ?? "") \(Constants.SEPERATOR) \(CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: model.employedFrom))"
        }
        else if model.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_OTH.lowercased() {
            
            cell.label1.text = model.natureOfOccupation?.name
            cell.label2.text = model.occupationType?.name
        }
        else if model.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SENP.lowercased() {

            cell.label1.text = model.organizationName
            cell.label2.text = "\(model.occupationType?.name ?? "") \(Constants.SEPERATOR) \(model.natureOfBusiness?.name ?? "")"
        }
        else if model.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SEP.lowercased() {

            cell.label1.text = model.organizationName
            cell.label2.text = "\(model.occupationType?.name ?? "") \(Constants.SEPERATOR) \(model.natureOfProfession?.name ?? "") \(Constants.SEPERATOR) \(model.registrationNumber ?? "")"
        }
        else {
            cell.label1.text = model.employerName?.name
            cell.label2.text = model.occupationType?.name
        }
        
        cell.label3.text = model.majorOccupation ?? false ? "PRIMARY" : ""
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        moveToDetailPage(index: indexPath.row)
    }
}

extension EmploymentListVC : NextBackButtonDelegate {
    func nextButtonAction() {
        
        if !employmentModelArray.isEmpty {
            let filterArray = employmentModelArray.filter({$0.majorOccupation == true})
            if filterArray.isEmpty {
                CommonAlert.shared().showAlert(message: "Please mark one as primary employment.")
                return
            }
        }
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "SourcingAddressListVC") as? SourcingAddressListVC {
            vc.setData(type: self.customerType, applicationID: applicationID, customerID: customerID)
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension EmploymentListVC : CommonListCellDelegate {
    
    func selectedIndex(index: Int, cellIndex: Int, cellSection: Int) {
        let item = self.cellOptionArray[index]
        if item == .edit {
            moveToDetailPage(index: cellIndex)
        }
        else if item == .delete {
            CommonAlert.shared().showAlert(message: "Are you sure you want to delete employment details?", cancelTitle: "Cancel" , okAction: { _ in
                self.deleteDataRow(index: cellIndex)
                
            })
        }
    }
}
