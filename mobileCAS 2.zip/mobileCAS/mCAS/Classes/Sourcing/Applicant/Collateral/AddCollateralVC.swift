//
//  AddCollateralVC.swift
//  mCAS
//
//  Created by iMac on 31/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddCollateralVC: UIViewController {
    
    @IBOutlet weak var collateralSubType: LOVFieldView!
    @IBOutlet weak var collateralSubTypeHeight: NSLayoutConstraint!
    @IBOutlet weak var fundingForLOV: LOVFieldView!
    @IBOutlet weak var fundingForLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var assetTypeLOV: LOVFieldView!
    @IBOutlet weak var assetTypeLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var assetCategoryLOV: LOVFieldView!
    @IBOutlet weak var assetCategoryLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var assetMakeLOV: LOVFieldView!
    @IBOutlet weak var assetMakeLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var assetModelLOV: LOVFieldView!
    @IBOutlet weak var assetModelLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var assetVariantLOV: LOVFieldView!
    @IBOutlet weak var assetVariantLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var assetCostView: CustomTextFieldView!
    @IBOutlet weak var assetCostViewHeight: NSLayoutConstraint!
    @IBOutlet weak var quantityView: CustomTextFieldView!
    @IBOutlet weak var quantityViewHeight: NSLayoutConstraint!
    @IBOutlet weak var effectiveAssetCostView: CustomTextFieldView!
    @IBOutlet weak var effectiveAssetCostViewHeight: NSLayoutConstraint!
    @IBOutlet weak var dealerLOV: LOVFieldView!
    @IBOutlet weak var dealerLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var bodyTypeLOV: LOVFieldView!
    @IBOutlet weak var bodyTypeLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var bodyManufacturerLOV: LOVFieldView!
    @IBOutlet weak var bodyManufacturerLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var bodyCostView: CustomTextFieldView!
    @IBOutlet weak var bodyCostViewHeight: NSLayoutConstraint!
    @IBOutlet weak var bodyCostAsPerGridView: CustomTextFieldView!
    @IBOutlet weak var bodyCostAsPerGridViewHeight: NSLayoutConstraint!
    @IBOutlet weak var bodyCostProposedView: CustomTextFieldView!
    @IBOutlet weak var bodyCostProposedViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var engineNumberView: CustomTextFieldView!
    @IBOutlet weak var engineNumberViewHeight: NSLayoutConstraint!
    @IBOutlet weak var chassisNumberView: CustomTextFieldView!
    @IBOutlet weak var chassisNumberViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var registrationNumberView: CustomTextFieldView!
    @IBOutlet weak var registrationNumberViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var propertyTypeLOV: LOVFieldView!
    @IBOutlet weak var propertyTypeLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var natureOfPropertyLOV: LOVFieldView!
    @IBOutlet weak var natureOfPropertyLOVHeight: NSLayoutConstraint!
    
    //LAP related fields
    @IBOutlet weak var propertyIdentifiedButton: UIButton!
    @IBOutlet weak var propertyIdentifiedButtonHeight: NSLayoutConstraint!
    @IBOutlet weak var expectedPriceView: CustomTextFieldView!
    @IBOutlet weak var expectedPriceViewHeight: NSLayoutConstraint!
    @IBOutlet weak var assetAddressLabel: EdgeInsetLabel!
    @IBOutlet weak var assetAddressLabelHeight: NSLayoutConstraint!
    @IBOutlet weak var addressLine1View: CustomTextFieldView!
    @IBOutlet weak var addressLine1ViewHeight: NSLayoutConstraint!
    @IBOutlet weak var addressLine2View: CustomTextFieldView!
    @IBOutlet weak var addressLine2ViewHeight: NSLayoutConstraint!
    @IBOutlet weak var addressLine3View: CustomTextFieldView!
    @IBOutlet weak var addressLine3ViewHeight: NSLayoutConstraint!
    @IBOutlet weak var landmarkView: CustomTextFieldView!
    @IBOutlet weak var landmarkViewHeight: NSLayoutConstraint!
    @IBOutlet weak var searchByPincodeView: CustomSearchByPincodeView!
    @IBOutlet weak var searchByPincodeViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private let TAG_ASSET_CATEGORY      = 1000
    private let TAG_ASSET_MAKE          = 1001
    private let TAG_ASSET_MODEL         = 1002
    private let TAG_ASSET_VARIANT       = 1003
    private let TAG_DEALER              = 1004
    private let TAG_COLLATERAL_SUB_TYPE = 1005
    private let TAG_ASSET_TYPE          = 1006
    private let TAG_FUNDING_FOR         = 1007
    private let TAG_BODY_TYPE           = 1008
    private let TAG_BODY_MANU_NAME      = 1009
    private let TAG_PROPERTY_TYPE       = 1010
    private let TAG_NATURE_OF_PROPERTY  = 1011
    private let TAG_AMOUNT              = 10000
    private let TAG_QUANTITY            = 10001
    private let TAG_USED_ASSET          = 10002
    private let TAG_ADDRESS             = 10003
    
    private let FUNDING_FOR             = "Both"
    private let ASSET_TYPE_USED         = "used asset"
    
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var applicationType: DropDown!
    private var productCategory: LoanType!
    private var applicationID: String!
    private var branchCode: String!
    private var productCode: String!

    private var dataObj: SourcingModelClasses.CollateralModel.CollateralDetail!
    private var seachByPincodeView: SearchByPinCodeView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getAllDealers()
        setupView()
    }
    
    private func setupView() {
        
        collateralSubType.setLOVProperties(masterName: Entity.COLL_SUB_TYPE, title: "Collateral Sub Type", tag: TAG_COLLATERAL_SUB_TYPE, delegate: self, parentKey: productCode)
        fundingForLOV.setLOVProperties(masterName: Entity.FUNDED_FOR, title: "Funding For", tag: TAG_FUNDING_FOR, delegate: self)
        assetTypeLOV.setLOVProperties(masterName: Entity.ASSET_TYPE, title: "Asset Type", tag: TAG_ASSET_TYPE, delegate: self)
        
        //SK Change - CL/CD - dropdown parent issue
        assetCategoryLOV.setLOVProperties(masterName: Entity.ASSET, title: "Asset Category", tag: TAG_ASSET_CATEGORY, delegate: self)
        assetMakeLOV.setLOVProperties(masterName: Entity.ASSET_MAKE, title: "Asset Make", tag: TAG_ASSET_MAKE, delegate: self)
        assetModelLOV.setLOVProperties(masterName: Entity.ASSET_MODEL, title: "Asset Model", tag: TAG_ASSET_MODEL, delegate: self)
        assetVariantLOV.setLOVProperties(masterName: Entity.ASSET_VARIANT, title: "Asset Variant (Optional)", tag: TAG_ASSET_VARIANT, delegate: self)
        dealerLOV.setLOVProperties(title: "Dealer", tag: TAG_DEALER, delegate: self)
        bodyTypeLOV.setLOVProperties(masterName: Entity.BODY_TYPE, title: "Body Type", tag: TAG_BODY_TYPE, delegate: self)
        bodyManufacturerLOV.setLOVProperties(masterName: Entity.BODY_MAN_NAME, title: "Body Manufacturer Name", tag: TAG_BODY_MANU_NAME, delegate: self)
        
        propertyTypeLOV.setLOVProperties(masterName: Entity.PROP_TYPE, title: "Property Type", tag: TAG_PROPERTY_TYPE, delegate: self)
        natureOfPropertyLOV.setLOVProperties(masterName: Entity.NATURE_OF_PROP, title: "Nature of Property", tag: TAG_NATURE_OF_PROPERTY, delegate: self)
        
        searchByPincodeView.setProperties(delegate: self)
        
        assetCostView.setProperties(placeHolder: "Asset Cost", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        quantityView.setProperties(placeHolder: "Quantity", type: .Number, delegate: self, tag: TAG_QUANTITY)
        effectiveAssetCostView.setProperties(placeHolder: "Effective Asset Cost", type: .Amount, delegate: self, enabled: false)
        expectedPriceView.setProperties(placeHolder: "Expected Price", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        
        bodyCostView.setProperties(placeHolder: "Body Cost", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        bodyCostAsPerGridView.setProperties(placeHolder: "Body Cost as per Grid", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        bodyCostProposedView.setProperties(placeHolder: "Body Cost Proposed", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        
        engineNumberView.setProperties(placeHolder: "Engine Number", type: .Text, delegate: self, tag: TAG_USED_ASSET)
        chassisNumberView.setProperties(placeHolder: "Chassis Number", type: .Text, delegate: self, tag: TAG_USED_ASSET)
        registrationNumberView.setProperties(placeHolder: "Registration Number", type: .Text, delegate: self, tag: TAG_USED_ASSET)
        
        addressLine1View.setProperties(placeHolder: "Address Line 1", type: .Text, delegate: self, tag: TAG_ADDRESS)
        addressLine2View.setProperties(placeHolder: "Address Line 2 (Optional)", type: .Text, delegate: self, tag: TAG_ADDRESS)
        addressLine3View.setProperties(placeHolder: "Address Line 3 (Optional)", type: .Text, delegate: self, tag: TAG_ADDRESS)
        landmarkView.setProperties(placeHolder: "Landmark", type: .Text, delegate: self, tag: TAG_ADDRESS)
        
        assetAddressLabel.font = CustomFont.shared().GETFONT_MEDIUM(19)
        assetAddressLabel.text = "Asset Address"
        assetAddressLabel.layer.masksToBounds = true
        
        propertyIdentifiedButton.layer.masksToBounds = true
        propertyIdentifiedButton.setCheckboxProperties(title: "is Property Identified", isSelected: false)
                
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        setupLayout()
        fillDataInEditMode(dataObj: dataObj)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Collateral")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader()
        }
    }
    
    func setData(productCategory: LoanType, applicationType: DropDown, applicationID: String, branchCode: String, productCode: String, dataObj: SourcingModelClasses.CollateralModel.CollateralDetail? = nil) {
        self.productCategory = productCategory
        self.applicationType = applicationType
        self.applicationID = applicationID
        self.branchCode = branchCode
        self.productCode = productCode
        self.dataObj = dataObj
    }
    
    private func fillDataInEditMode(dataObj: SourcingModelClasses.CollateralModel.CollateralDetail?) {
        
        if let data = dataObj {
            collateralSubType.autoFillLOVBy(key: data.collateralSubType?.code)
            fundingForLOV.autoFillLOVBy(key: data.fundedFor?.code)
            assetTypeLOV.autoFillLOVBy(key: data.assetType?.code)
            assetCategoryLOV.autoFillLOVBy(key: data.assetModelCategory?.code)
            assetMakeLOV.autoFillLOVBy(key: data.assetMake?.code)
            assetModelLOV.autoFillLOVBy(key: data.assetModel?.code)
            assetVariantLOV.autoFillLOVBy(key: data.assetVariant?.code)
            
            if let amount = data.assetCost {
                assetCostView.setFieldValue(text: "\(amount)")
            }
            
            bodyTypeLOV.autoFillLOVBy(key: data.bodyType?.code)
            bodyManufacturerLOV.autoFillLOVBy(key: data.bodyManuName?.code)
            
            if let amount = data.bodyCost {
                bodyCostView.setFieldValue(text: "\(amount)")
            }
            if let amount = data.bodyCostAsPerGrid {
                bodyCostAsPerGridView.setFieldValue(text: "\(amount)")
            }
            if let amount = data.bodyCostProposed {
                bodyCostProposedView.setFieldValue(text: "\(amount)")
            }
            
            engineNumberView.setFieldValue(text: data.engineNumber)
            chassisNumberView.setFieldValue(text: data.chassisNumber)
            registrationNumberView.setFieldValue(text: data.registrationNumber)
            
            if let qua = data.quantity {
                quantityView.setFieldValue(text: "\(qua)")
            }
            if let amount = data.assetCost {
                assetCostView.setFieldValue(text: "\(amount)")
            }
            
            if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_LAP.lowercased() || self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_HL.lowercased() {
                propertyTypeLOV.autoFillLOVBy(key: data.propertyType?.code)
                natureOfPropertyLOV.autoFillLOVBy(key: data.natureOfProperty?.code)
                
                if let amount = data.propertyPurchasePrice {
                    expectedPriceView.setFieldValue(text: "\(amount)")
                }
                
                if data.isPropertyIdentified ?? false {
                    propertyIdentifiedButton.sendActions(for: .touchUpInside)
                }
                
                addressLine1View.setFieldValue(text: data.addressVO?.unit)
                addressLine2View.setFieldValue(text: data.addressVO?.streetNo)
                addressLine3View.setFieldValue(text: data.addressVO?.streetName)
                landmarkView.setFieldValue(text: data.addressVO?.landmark)
                
                searchByPincodeView.setAutoFillValues(countryKey: data.addressVO?.country?.code, stateKey: data.addressVO?.state?.code, cityKey: data.addressVO?.city?.code, pincode: CommonUtils.shared().getValidatedString(string: data.addressVO?.postalCode?.code))
            }
            
            buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Update", delegate: self)
        }
        
        validateFields()
    }
    
    
    private func setupLayout() {
        
        if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CV.lowercased() {
            collateralSubTypeHeight.constant = 65
            fundingForLOVHeight.constant = 65
            assetTypeLOVHeight.constant = 65
            assetCategoryLOVHeight.constant = 65
            assetMakeLOVHeight.constant = 65
            assetModelLOVHeight.constant = 65
            assetVariantLOVHeight.constant = 65
            assetCostViewHeight.constant = 65
            dealerLOVHeight.constant = 65
            
            effectiveAssetCostViewHeight.constant = 0
            quantityViewHeight.constant = 0
            propertyTypeLOVHeight.constant = 0
        }
        else if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CON_VEH.lowercased() {
            collateralSubTypeHeight.constant = 65
            assetTypeLOVHeight.constant = 65
            assetCategoryLOVHeight.constant = 65
            assetMakeLOVHeight.constant = 65
            assetModelLOVHeight.constant = 65
            assetVariantLOVHeight.constant = 65
            assetCostViewHeight.constant = 65
            dealerLOVHeight.constant = 65
            
            fundingForLOVHeight.constant = 0
            effectiveAssetCostViewHeight.constant = 0
            quantityViewHeight.constant = 0
            propertyTypeLOVHeight.constant = 0
        }
        else if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_LAP.lowercased() || self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_HL.lowercased() {
            collateralSubTypeHeight.constant = 65
            propertyTypeLOVHeight.constant = 65
            propertyIdentifiedButtonHeight.constant = 50
            natureOfPropertyLOVHeight.constant = 65
            expectedPriceViewHeight.constant = 65
            
            fundingForLOVHeight.constant = 0
            assetTypeLOVHeight.constant = 0
            assetCategoryLOVHeight.constant = 0
            assetMakeLOVHeight.constant = 0
            assetModelLOVHeight.constant = 0
            assetVariantLOVHeight.constant = 0
            assetCostViewHeight.constant = 0
            dealerLOVHeight.constant = 0
            effectiveAssetCostViewHeight.constant = 0
            quantityViewHeight.constant = 0
        }
        else if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CL.lowercased() {
            assetCategoryLOVHeight.constant = 65
            assetMakeLOVHeight.constant = 65
            assetModelLOVHeight.constant = 65
            assetVariantLOVHeight.constant = 65
            assetCostViewHeight.constant = 65
            dealerLOVHeight.constant = 65
            quantityViewHeight.constant = 65
            effectiveAssetCostViewHeight.constant = 65
            
            collateralSubTypeHeight.constant = 0
            fundingForLOVHeight.constant = 0
            assetTypeLOVHeight.constant = 0
            propertyTypeLOVHeight.constant = 0
            propertyIdentifiedButtonHeight.constant = 0
            natureOfPropertyLOVHeight.constant = 0
            expectedPriceViewHeight.constant = 0
        }
        else {
            collateralSubTypeHeight.constant = 65
            assetTypeLOVHeight.constant = 65
            assetCategoryLOVHeight.constant = 65
            assetMakeLOVHeight.constant = 65
            assetModelLOVHeight.constant = 65
            assetVariantLOVHeight.constant = 65
            assetCostViewHeight.constant = 65
            dealerLOVHeight.constant = 65
            
            fundingForLOVHeight.constant = 0
            propertyTypeLOVHeight.constant = 0
            propertyIdentifiedButtonHeight.constant = 0
            natureOfPropertyLOVHeight.constant = 0
            expectedPriceViewHeight.constant = 0
            quantityViewHeight.constant = 0
            effectiveAssetCostViewHeight.constant = 0
        }
    }
    
    @IBAction func propertyIdentifiedButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        
        addressLine1View.setFieldValue()
        addressLine2View.setFieldValue()
        addressLine3View.setFieldValue()
        landmarkView.setFieldValue()
        
        assetAddressLabelHeight.constant = sender.isSelected ? 40 : 0
        assetAddressLabel.topTextInset = sender.isSelected ? 10 : 0
        addressLine1ViewHeight.constant = sender.isSelected ? 65 : 0
        addressLine2ViewHeight.constant = sender.isSelected ? 65 : 0
        addressLine3ViewHeight.constant = sender.isSelected ? 65 : 0
        landmarkViewHeight.constant = sender.isSelected ? 65 : 0
        
        searchByPincodeViewHeight.constant = sender.isSelected ? 300 : 0
        searchByPincodeView.hideAllFields(isHide: !sender.isSelected)
        
        validateFields()
    }
    
    private func getAllDealers() {
        
        let param: [String: Any] = ["branch"    : ["code" : branchCode],
                                    "product"   : ["code" : productCode]]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_ALL_DEALER_MASTER_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [[String: Any]]
            {
                let dealerDropDown = response.map({ DropDown(code: $0["code"] as? String ?? "", name: $0["name"] as? String ?? "")})
                self.dealerLOV.resetLOVWithMaster(list: dealerDropDown)
                
                if let data = self.dataObj {
                    self.dealerLOV.autoFillLOVBy(key: data.dealer?.code)
                }
            }
            
        }, failure: { (error) in
        }, noNetwork: { (error) in
        })
    }
}

extension AddCollateralVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        switch btntag {
        case TAG_ASSET_CATEGORY:
            if let dd = selectedLOVDic["\(TAG_ASSET_CATEGORY)"] {
                assetMakeLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_ASSET_MAKE)"] = nil
                
                assetModelLOV.resetLOVWithParentKey()
                selectedLOVDic["\(TAG_ASSET_MODEL)"] = nil
                
                assetVariantLOV.resetLOVWithParentKey()
                selectedLOVDic["\(TAG_ASSET_VARIANT)"] = nil
                
                self.assetCostView.setFieldValue()
            }
            
        case TAG_ASSET_MAKE:
            if let dd = selectedLOVDic["\(TAG_ASSET_MAKE)"] {
                assetModelLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_ASSET_MODEL)"] = nil
                
                assetVariantLOV.resetLOVWithParentKey()
                selectedLOVDic["\(TAG_ASSET_VARIANT)"] = nil
                
                self.assetCostView.setFieldValue()
            }
            
        case TAG_ASSET_MODEL:
            if let dd = selectedLOVDic["\(TAG_ASSET_MODEL)"] {
                assetVariantLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_ASSET_VARIANT)"] = nil
                
                CoreDataOperations.shared().fetchRecordsForMaster(masterName: Entity.ASSET_MODEL_PRICE, parentKey: dd.code) { (records) in
                    if let records = records, !records.isEmpty {
                        self.assetCostView.setFieldValue(text: records.first?.code)
                    }
                    else {
                        self.assetCostView.setFieldValue()                      
                    }
                }
            }
            
        case TAG_ASSET_VARIANT:
            if let dd = selectedLOVDic["\(TAG_ASSET_VARIANT)"] {
                
                CoreDataOperations.shared().fetchRecordsForMaster(masterName: Entity.ASSET_VARIANT_PRICE, parentKey: dd.code) { (records) in
                    if let records = records, !records.isEmpty {
                        self.assetCostView.setFieldValue(text: records.first?.code)
                    }
                    else {
                        self.assetCostView.setFieldValue()
                    }
                }
            }
            
        case TAG_FUNDING_FOR:
            if selectedLOVDic["\(TAG_FUNDING_FOR)"]?.code.lowercased() == FUNDING_FOR.lowercased() {
                bodyTypeLOVHeight.constant = 65
                bodyManufacturerLOVHeight.constant = 65
                bodyCostViewHeight.constant = 65
                bodyCostAsPerGridViewHeight.constant = 65
                bodyCostProposedViewHeight.constant = 65
            }
            else {
                bodyTypeLOVHeight.constant = 0
                bodyManufacturerLOVHeight.constant = 0
                bodyCostViewHeight.constant = 0
                bodyCostAsPerGridViewHeight.constant = 0
                bodyCostProposedViewHeight.constant = 0
            }
            
            bodyTypeLOV.resetLOVWithParentKey()
            bodyManufacturerLOV.resetLOVWithParentKey()
            bodyCostView.setFieldValue()
            bodyCostAsPerGridView.setFieldValue()
            bodyCostProposedView.setFieldValue()
            
        case TAG_ASSET_TYPE:
            if selectedLOVDic["\(TAG_ASSET_TYPE)"]?.code.lowercased() == ASSET_TYPE_USED.lowercased() {
                engineNumberViewHeight.constant = 65
                chassisNumberViewHeight.constant = 65
                registrationNumberViewHeight.constant = 65
            }
            else {
                engineNumberViewHeight.constant = 0
                chassisNumberViewHeight.constant = 0
                registrationNumberViewHeight.constant = 0
            }
            
            engineNumberView.setFieldValue()
            chassisNumberView.setFieldValue()
            registrationNumberView.setFieldValue()
            
        case TAG_COLLATERAL_SUB_TYPE:
            if let dd = selectedLOVDic["\(TAG_COLLATERAL_SUB_TYPE)"] {
                assetCategoryLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_ASSET_CATEGORY)"] = nil
                
                propertyTypeLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_PROPERTY_TYPE)"] = nil
                
                natureOfPropertyLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_NATURE_OF_PROPERTY)"] = nil
            }
            
        case TAG_PROPERTY_TYPE:
            if let dd = selectedLOVDic["\(TAG_PROPERTY_TYPE)"] {
                natureOfPropertyLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_NATURE_OF_PROPERTY)"] = nil
            }
            
        default:
            debugPrint("case not matched")
        }
        
        validateFields()
    }
}

extension AddCollateralVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        
        if let cost = Double(assetCostView.getFieldValue()), let quantity = Double(quantityView.getFieldValue()) {
            effectiveAssetCostView.setFieldValue(text: "\(cost*quantity)".formatCurrency)
        }
        else {
            effectiveAssetCostView.setFieldValue()
        }
        
        if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_LAP.lowercased() || self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_HL.lowercased() {
            
            isEnabled = !(selectedLOVDic["\(TAG_COLLATERAL_SUB_TYPE)"] == nil || selectedLOVDic["\(TAG_PROPERTY_TYPE)"] == nil || selectedLOVDic["\(TAG_NATURE_OF_PROPERTY)"] == nil || expectedPriceView.getFieldValue().isEmpty)
            
            if propertyIdentifiedButton.isSelected {
                isEnabled = isEnabled && !(addressLine1View.getFieldValue().isEmpty || landmarkView.getFieldValue().isEmpty) && searchByPincodeView.validateCSBPFields()
            }
        }
        else if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CV.lowercased() || self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CON_VEH.lowercased() || self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CL.lowercased() || self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_FE.lowercased() {
            
            if (selectedLOVDic["\(TAG_ASSET_CATEGORY)"] == nil || selectedLOVDic["\(TAG_ASSET_MAKE)"] == nil || selectedLOVDic["\(TAG_ASSET_MODEL)"] == nil || assetCostView.getFieldValue().isEmpty || (self.productCategory.code != ConstantCodes.PRODUCT_TYPE_CL && selectedLOVDic["\(TAG_COLLATERAL_SUB_TYPE)"] == nil))
            {
                isEnabled = false
            }
            
            if selectedLOVDic["\(TAG_FUNDING_FOR)"]?.code.lowercased() == FUNDING_FOR.lowercased() {
                isEnabled = isEnabled && !(selectedLOVDic["\(TAG_BODY_TYPE)"] == nil || selectedLOVDic["\(TAG_BODY_MANU_NAME)"] == nil || bodyCostView.getFieldValue().isEmpty || bodyCostAsPerGridView.getFieldValue().isEmpty || bodyCostProposedView.getFieldValue().isEmpty)
            }
            
            if selectedLOVDic["\(TAG_ASSET_TYPE)"]?.code.lowercased() == ASSET_TYPE_USED.lowercased() {
                isEnabled = isEnabled && !(engineNumberView.getFieldValue().isEmpty || chassisNumberView.getFieldValue().isEmpty || registrationNumberView.getFieldValue().isEmpty)
            }
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            let cost = Double(text) ?? 0.0
            return cost < SourcingCommonUtil.shared().maxAmount && cost > 0
            
        case TAG_QUANTITY:
            let quantity = Int(text) ?? 0
            return quantity < SourcingCommonUtil.shared().maxQuantity && quantity > 0
            
        case TAG_USED_ASSET:
            return text.isAlphanumeric && text.count <= 30
            
        default:
            return true
        }
    }
}

extension AddCollateralVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        var collateralID = ""
        if let dataObj = dataObj {
            collateralID = dataObj.neutronCollateralId!
        }
        else {
            collateralID = SourcingCommonUtil.shared().generateApplicationID()
        }
        
        var paramCollateral: [String : Any] = [:]
        
        paramCollateral["neutronCollateralId"]       = collateralID
        
        if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_LAP.lowercased() || self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_HL.lowercased() {
            paramCollateral["collateralSubType"]       = ["code"    : selectedLOVDic["\(TAG_COLLATERAL_SUB_TYPE)"]?.code,
                                                          "name"    : selectedLOVDic["\(TAG_COLLATERAL_SUB_TYPE)"]?.name]
            paramCollateral["isPropertyIdentified"]    = propertyIdentifiedButton.isSelected
            paramCollateral["propertyType"]            = ["code"    : selectedLOVDic["\(TAG_PROPERTY_TYPE)"]?.code,
                                                          "name"    : selectedLOVDic["\(TAG_PROPERTY_TYPE)"]?.name]
            paramCollateral["natureOfProperty"]        = ["code"    : selectedLOVDic["\(TAG_NATURE_OF_PROPERTY)"]?.code,
                                                          "name"    : selectedLOVDic["\(TAG_NATURE_OF_PROPERTY)"]?.name]
            paramCollateral["propertyPurchasePrice"]   = expectedPriceView.getFieldValue()
            
            if propertyIdentifiedButton.isSelected {
                var paramAddress: [String : Any] = [:]
                paramAddress["unit"]        = addressLine1View.getFieldValue()
                paramAddress["streetNo"]    = addressLine2View.getFieldValue()
                paramAddress["streetName"]  = addressLine3View.getFieldValue()
                paramAddress["landmark"]    = landmarkView.getFieldValue()
                
                paramAddress["country"]     = ["code"   :   searchByPincodeView.getSelectedCountry().0,
                                               "name"   :   searchByPincodeView.getSelectedCountry().1]
                paramAddress["state"]       = ["code"   :   searchByPincodeView.getSelectedState().0,
                                               "name"   :   searchByPincodeView.getSelectedState().1]
                paramAddress["city"]        = ["code"   :   searchByPincodeView.getSelectedCity().0,
                                               "name"   :   searchByPincodeView.getSelectedCity().1]
                paramAddress["postalCode"]  = ["code"   :   searchByPincodeView.getSelectedPincode().0,
                                               "name"   :   searchByPincodeView.getSelectedPincode().1]
                
                paramCollateral["addressVO"]   = paramAddress
            }
        }
        else {
            if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CV.lowercased()  ||  self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CON_VEH.lowercased() || self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_FE.lowercased() {
                
                paramCollateral["collateralSubType"]    = ["code"   : selectedLOVDic["\(TAG_COLLATERAL_SUB_TYPE)"]?.code,
                                                           "name"   : selectedLOVDic["\(TAG_COLLATERAL_SUB_TYPE)"]?.name]
                paramCollateral["assetType"]            = ["code"   : selectedLOVDic["\(TAG_ASSET_TYPE)"]?.code,
                                                           "name"   : selectedLOVDic["\(TAG_ASSET_TYPE)"]?.name]
                
                if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CV.lowercased() {
                    paramCollateral["fundedFor"]                = ["code"   : selectedLOVDic["\(TAG_FUNDING_FOR)"]?.code,
                                                                   "name"   : selectedLOVDic["\(TAG_FUNDING_FOR)"]?.name]
                    
                    if selectedLOVDic["\(TAG_FUNDING_FOR)"]?.code.lowercased() == FUNDING_FOR.lowercased() {
                        paramCollateral["bodyType"]             = ["code"   : selectedLOVDic["\(TAG_BODY_TYPE)"]?.code,
                                                                   "name"   : selectedLOVDic["\(TAG_BODY_TYPE)"]?.name]
                        paramCollateral["bodyManuName"]         = ["code"   : selectedLOVDic["\(TAG_BODY_MANU_NAME)"]?.code,
                                                                   "name"   : selectedLOVDic["\(TAG_BODY_MANU_NAME)"]?.name]
                        paramCollateral["bodyCost"]             = bodyCostView.getFieldValue()
                        paramCollateral["bodyCostAsPerGrid"]    = bodyCostAsPerGridView.getFieldValue()
                        paramCollateral["bodyCostProposed"]     = bodyCostProposedView.getFieldValue()
                    }
                }
                
                if selectedLOVDic["\(TAG_ASSET_TYPE)"]?.code.lowercased() == ASSET_TYPE_USED.lowercased() {
                    paramCollateral["engineNumber"]         = engineNumberView.getFieldValue()
                    paramCollateral["chassisNumber"]        = chassisNumberView.getFieldValue()
                    paramCollateral["registrationNumber"]   = registrationNumberView.getFieldValue()
                }
            }
            
            if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CL.lowercased() {
                paramCollateral["effectiveAssetCost"]   = effectiveAssetCostView.getFieldValue()
                paramCollateral["quantity"]             = quantityView.getFieldValue()
            }
            
            paramCollateral["dealer"]               = ["code"   : CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_DEALER)"]?.code),
                                                       "name"   : CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_DEALER)"]?.name)]
            
            paramCollateral["assetModelCategory"]   = ["code"   : CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_ASSET_CATEGORY)"]?.code),
                                                       "name"   : CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_ASSET_CATEGORY)"]?.name)]
            
            paramCollateral["assetMake"]            = ["code"   : CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_ASSET_MAKE)"]?.code),
                                                       "name"   : CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_ASSET_MAKE)"]?.name)]
            
            paramCollateral["assetModel"]           = ["code"   : CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_ASSET_MODEL)"]?.code),
                                                       "name"   : CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_ASSET_MODEL)"]?.name)]
            
            paramCollateral["assetVariant"]         = ["code"   : CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_ASSET_VARIANT)"]?.code),
                                                       "name"   : CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_ASSET_VARIANT)"]?.name)]
            
            paramCollateral["assetCost"]            = assetCostView.getFieldValue()
        }
        
        let param: [String : Any] = ["neutronReferenceNumber"   : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                     "collateralDetails"        : paramCollateral]
        
        
        Webservices.shared().POST(urlString: ServiceUrl.SAVE_COLLATERAL_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                if let obj = AppDelegate.instance.getSpecificVC(targetClass: CollateralListVC.self) as? CollateralListVC {
                    obj.fetchList()
                }
                self.navigationController?.popViewController(animated: true)
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension AddCollateralVC: CustomPincodeDelegate {
    func validatePincode() {
        self.validateFields()
    }
}

extension AddCollateralVC: CSByPincodeDelegate {
    func CSBPValidation() {
        validateFields()
    }
}



