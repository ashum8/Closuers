//
//  CollateralListVC.swift
//  mCAS
//
//  Created by iMac on 31/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class CollateralListVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var addCollateralButton: UIButton!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var buttonViewHeight: NSLayoutConstraint!
    private var modelData: SourcingModelClasses.SourcingModel?
    
    private enum DetailOptions: String {
        case edit = "Edit"
        case delete = "Delete"
    }
    
    private var dataModelArray = [SourcingModelClasses.CollateralModel.CollateralDetail]()
    
    private var cellOptionArray: [DetailOptions] = [.edit, .delete]
    private var applicationType: DropDown!
    private var productCategory: LoanType!
    private var applicationID: String!
    private var branchCode: String!
    private var productCode: String!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        fetchList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            let navArray = AppDelegate.instance.applicationNavController.viewControllers
            let lastVC = navArray[navArray.count-2]
            headerView.showHideStepHeader(isHide: false, title: "Collateral", landingPage: lastVC)
        }
    }
    
    private func setupView() {
        
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties(title: "Do you have any collateral to add?")
        
        tableView.register(UINib(nibName: "SourcingCommonListCell", bundle: nil), forCellReuseIdentifier: "SourcingCommonListCell")
        tableView.tableFooterView = UIView()
        
        addCollateralButton.setButtonProperties()
        buttonView.setProperties(nextBtnTitle: "Done", delegate: self)
    }
    
    func setData(productCategory: LoanType, applicationType: DropDown, applicationID: String, branchCode: String, productCode: String) {
        self.productCategory = productCategory
        self.applicationType = applicationType
        self.applicationID = applicationID
        self.branchCode = branchCode
        self.productCode = productCode
    }
    
    private func setListData() {
        tableView.isHidden = dataModelArray.isEmpty
        self.addButton.isHidden = dataModelArray.isEmpty
        noDataCapturedView.isHidden = !tableView.isHidden
        addCollateralButton.isHidden = !tableView.isHidden
        buttonViewHeight.constant = tableView.isHidden ? 0 : 45
        self.tableView.reloadData()
        
        if dataModelArray.count == 1 && (self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_HL.lowercased() || self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_LAP.lowercased() || self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CV.lowercased()) {
            
            self.addButton.isHidden = true
        }
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = st.instantiateViewController(withIdentifier: "AddCollateralVC") as? AddCollateralVC  {
            vc.setData(productCategory: self.productCategory, applicationType: self.applicationType, applicationID: self.applicationID, branchCode: self.branchCode, productCode: self.productCode)
            AppDelegate.instance.applicationNavController.pushViewController(vc, animated: true)
        }
    }
    
    func fetchList() {
        
        let param: [String: Any] = ["neutronReferenceNumber"   : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                    "product"                  : ["code" : productCategory.code]]
        
        dataModelArray.removeAll()
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_ALL_COLLATERAL_URL, paramaters: param, autoHandleLoader: true, allowOfflineAlert: false, success: { (header, responseObj) in
            
            if let response = responseObj as? [String: Any]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: SourcingModelClasses.CollateralModel.self) { list in
                    if let records = list.collateralDetails {
                        self.dataModelArray.append(contentsOf: records)
                    }
                }
            }
            self.setListData()
            
        }, failure: { (error) in
            
            self.setListData()
            
        }, noNetwork: { (error) in
            self.setListData()
        })
    }
    
    private func deleteDataRow(index: Int) {
        
        let param = ["neutronReferenceNumber" : CommonUtils.shared().getValidatedString(string: self.applicationID),
                     "neutronCollateralId"    : dataModelArray[index].neutronCollateralId ]
        
        Webservices.shared().POST(urlString: ServiceUrl.DELETE_COLLATERAL_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                self.dataModelArray.remove(at: index)
                self.setListData()
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
        }, noNetwork: { (error) in
        })
    }
    
}

extension CollateralListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataModelArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SourcingCommonListCell", for: indexPath) as! SourcingCommonListCell
        cell.setProperties(optionArray: cellOptionArray.map({ $0.rawValue }), cellIndex: indexPath.row, delegate: self)
        
        let model = dataModelArray[indexPath.row]
        
        if let assetMake = model.assetMake?.name {
            cell.label1.text = assetMake
            
            if let cost = model.assetCost {
                cell.label2.text = "\(CommonUtils.shared().getValidatedString(string: model.assetModel?.name)) \(Constants.SEPERATOR) \(String(cost).formatCurrency)"
            }
            else {
                cell.label2.text = CommonUtils.shared().getValidatedString(string: model.assetModel?.name)
            }
            
            cell.label3.text = model.dealer?.name
        }
        else if let propertyType = model.propertyType?.name {
            cell.label1.text = propertyType
            
            if let cost = model.propertyPurchasePrice {
                cell.label2.text = "\(CommonUtils.shared().getValidatedString(string: model.natureOfProperty?.name)) \(Constants.SEPERATOR) \(String(cost).formatCurrency)"
            }
            else {
                cell.label2.text = CommonUtils.shared().getValidatedString(string: model.natureOfProperty?.name)
            }
            
            if let obj = model.addressVO {
                cell.label3.text = obj.getFullAddress()
            }
            else {
                cell.label3.text = model.engineNumber
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.moveToDetailScreen(cellIndex: indexPath.row, cellSection: indexPath.section)
    }
    
    private func moveToDetailScreen(cellIndex: Int, cellSection: Int) {
        let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = st.instantiateViewController(withIdentifier: "AddCollateralVC") as? AddCollateralVC  {
            vc.setData(productCategory: self.productCategory, applicationType: self.applicationType, applicationID: self.applicationID, branchCode: self.branchCode, productCode: self.productCode, dataObj: dataModelArray[cellIndex])
            AppDelegate.instance.applicationNavController.pushViewController(vc, animated: true)
        }
    }
}

extension CollateralListVC : NextBackButtonDelegate {
    func nextButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension CollateralListVC : CommonListCellDelegate {
    
    func selectedIndex(index: Int, cellIndex: Int, cellSection: Int) {
        let item = self.cellOptionArray[index]
        if item == .edit {
            self.moveToDetailScreen(cellIndex: cellIndex, cellSection: cellSection)
        }
        else if item == .delete {
            CommonAlert.shared().showAlert(message: "Are you sure you want to delete collateral details?", cancelTitle: "Cancel" , okAction: { _ in
                self.deleteDataRow(index: cellIndex)
            })
            
        }
    }
}
