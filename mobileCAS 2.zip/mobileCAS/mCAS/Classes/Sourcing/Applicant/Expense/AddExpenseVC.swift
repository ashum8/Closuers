//
//  AddExpenseVC.swift
//  mCAS
//
//  Created by iMac on 28/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddExpenseVC: UIViewController {
    
    @IBOutlet weak var expenseHeadLOV: LOVFieldView!
    @IBOutlet weak var frequencyLOV: LOVFieldView!
    @IBOutlet weak var amountView: CustomTextFieldView!
    @IBOutlet weak var percentageView: CustomTextFieldView!
    @IBOutlet weak var netAmountView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var applicationID: String!
    private var customerID: String!
    private var dataObj: SourcingModelClasses.ExpenseModel!
    
    private let TAG_EXPENSE = 1000
    private let TAG_FREQUENCY = 1001
    private let TAG_AMOUNT = 10000
    private let TAG_PERCENTAGE = 10001
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        expenseHeadLOV.setLOVProperties(masterName: Entity.INCOME_EXPENSE_HEAD, title: "Expense Head", tag: TAG_EXPENSE, delegate: self, parentKey: "expense")
        frequencyLOV.setLOVProperties(masterName: Entity.FREQUENCY, title: "Frequency", tag: TAG_FREQUENCY, delegate: self)
        
        amountView.setProperties(placeHolder: "Amount", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        percentageView.setProperties(placeHolder: "Percentage(%)", type: .Decimal, delegate: self, tag: TAG_PERCENTAGE, enabled: false)
        netAmountView.setProperties(placeHolder: "Net Amount", type: .Text, delegate: self, enabled: false)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        percentageView.setFieldValue(text: "100.00")
        fillDataInEditMode(dataObj: dataObj)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Expense")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader()
        }
    }
    
    func setData(applicationID: String, customerID: String, dataObj: SourcingModelClasses.ExpenseModel? = nil) {
        self.applicationID = applicationID
        self.customerID = customerID
        self.dataObj = dataObj
    }
    
    @IBAction func checkBoxButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    private func fillDataInEditMode(dataObj: SourcingModelClasses.ExpenseModel?) {
        if let data = dataObj {
            
            if let dataCode = data.expenseType?.code, !dataCode.isEmpty {
                expenseHeadLOV.enableLOV(isEnable: false)
                expenseHeadLOV.autoFillLOVBy(key: dataCode)
            }
            
            frequencyLOV.autoFillLOVBy(key: data.expenseFrequency?.code)
            
            if let amount = data.grossAmount {
                amountView.setFieldValue(text: "\(amount)")
                netAmountView.setFieldValue(text: "\(amount)".formatCurrency)
            }
            
            buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Update", delegate: self)
        }
        validateFields()
    }
    
}

extension AddExpenseVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        validateFields()
    }
}

extension AddExpenseVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true

        if let cost = Double(amountView.getFieldValue()) {
            netAmountView.setFieldValue(text: "\(cost)".formatCurrency)
        }
        
        if (selectedLOVDic["\(TAG_EXPENSE)"] == nil || selectedLOVDic["\(TAG_FREQUENCY)"] == nil || amountView.getFieldValue().isEmpty || netAmountView.getFieldValue().isEmpty ) {
            
            isEnabled = false
        }
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            let amount = Double(text) ?? 0.0
            return amount <= SourcingCommonUtil.shared().maxAmount && amount > 0

        case TAG_PERCENTAGE:
            return Double(text) ?? 0 <= SourcingCommonUtil.shared().maxPercentage && Double(text) ?? 0 > 0

        default:
            return true
        }
    }
}

extension AddExpenseVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        var expenseID = ""
        if let dataObj = dataObj {
            expenseID = dataObj.expenseId!
        }
        else {
            expenseID =  "\(CommonUtils.shared().getValidatedString(string: self.customerID))_\(CommonUtils.shared().getValidatedString(string: selectedLOVDic["\(TAG_EXPENSE)"]?.code))" 
        }
        
        let param: [String : Any] = ["neutronReferenceNumber"   : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                     "neutronCustRefNumber"     : CommonUtils.shared().getValidatedString(string: self.customerID),
                                     "expenseDetails"           :[["expenseId" : CommonUtils.shared().getValidatedString(string: expenseID),
                                                                   "expenseType"             : ["code":selectedLOVDic["\(TAG_EXPENSE)"]?.code,"name":selectedLOVDic["\(TAG_EXPENSE)"]?.name],
                                                                   "expenseFrequency"        : ["code":selectedLOVDic["\(TAG_FREQUENCY)"]?.code,"name":selectedLOVDic["\(TAG_FREQUENCY)"]?.name],
                                                                   "grossAmount"             : amountView.getFieldValue(),
                                                                   "percentage"              : percentageView.getFieldValue(),
                                                                   "netAmount"               : netAmountView.getFieldValue() ]]]
        
        Webservices.shared().POST(urlString: ServiceUrl.SAVE_EXPENSE_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                if let obj = AppDelegate.instance.getSpecificVC(targetClass: ExpenseListVC.self) as? ExpenseListVC {
                    obj.fetchList()
                }
                self.navigationController?.popViewController(animated: true)
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
