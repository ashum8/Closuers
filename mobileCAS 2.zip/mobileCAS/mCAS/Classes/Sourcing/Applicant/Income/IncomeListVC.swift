//
//  IncomeListVC.swift
//  mCAS
//
//  Created by iMac on 28/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class IncomeListVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var headerTitleView: SourcingTitleView!
    
    private enum DetailOptions: String {
        case edit = "Edit"
        case delete = "Delete"
    }
    
    private var dataModelArray = [SourcingModelClasses.EmploymentModel]()
    private var filteredModelArray = [SourcingModelClasses.EmploymentModel]()
    
    private var cellOptionArray: [DetailOptions] = [.edit, .delete]
    private var applicationID: String!
    private var customerID: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
        fetchList()
    }
    
    private func setupView() {
        
        tableView.register(UINib(nibName: "SourcingCommonListCell", bundle: nil), forCellReuseIdentifier: "SourcingCommonListCell")
        tableView.register(UINib(nibName: "IncomeDeductionHeaderTVCell", bundle: nil), forCellReuseIdentifier: "IncomeDeductionHeaderTVCell")
        tableView.tableFooterView = UIView()
        
        headerTitleView.setProperties(title: "Income")
        
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties(title: "Add Income details here.")
        
        setListData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader(isHide: false, title: "Add Applicant")
        }
    }
    
    private func setListData() {
        self.filteredModelArray = self.filteredModelArray.filter({ !($0.incomeDetails?.isEmpty ?? true)})
        tableView.isHidden = self.filteredModelArray.isEmpty
        noDataCapturedView.isHidden = !tableView.isHidden
        self.tableView.reloadData()
        buttonView.setProperties(showBack: true, nextBtnTitle: self.filteredModelArray.isEmpty ? "Skip" : "Continue", delegate: self)
    }
    
    func setData(applicationID: String, customerID: String) {
        self.applicationID = applicationID
        self.customerID = customerID
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        
        let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = st.instantiateViewController(withIdentifier: "AddIncomeVC") as? AddIncomeVC  {
            vc.setData(applicationID: applicationID, customerID: customerID, employmentModelArray: dataModelArray)
            AppDelegate.instance.applicationNavController.pushViewController(vc, animated: true)
        }
    }
    
    func fetchList() {
        
        let param = ["neutronCustRefNumber" : customerID]
        
        dataModelArray.removeAll()
        filteredModelArray.removeAll()
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_ALL_INCOME_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [[String: Any]]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: [SourcingModelClasses.EmploymentModel].self) { list in
                    self.dataModelArray.append(contentsOf: list)
                    self.filteredModelArray = SourcingCommonUtil.shared().sortEmploymentBasedOnOccupationType(list: self.dataModelArray)
                }
            }
            self.setListData()
            
        }, failure: { (error) in
            
            self.setListData()
            
        }, noNetwork: { (error) in
            self.setListData()
        })
    }
    
    private func moveToDetailPage(index: Int, section: Int) {
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "AddIncomeVC") as? AddIncomeVC {
            if let incomeDetails = filteredModelArray[section].incomeDetails, !incomeDetails.isEmpty {
                let incomeID = incomeDetails[index].incomeId
                
                vc.setData(applicationID: applicationID, customerID: customerID, dataObj: filteredModelArray[section], employmentModelArray: dataModelArray, incomeID: incomeID)
                AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
            }
        }
    }
    
    private func deleteDataRow(index: Int, sectionIndex: Int) {
        
        if let incomeDetails = filteredModelArray[sectionIndex].incomeDetails, !incomeDetails.isEmpty {
            let incomeID = incomeDetails[index].incomeId
            let param = ["neutronReferenceNumber"   : applicationID,
                         "neutronCustRefNumber"     : customerID,
                         "incomeID"                 : incomeID]
            
            Webservices.shared().POST(urlString: ServiceUrl.DELETE_INCOME_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
                
                if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                    
                    self.filteredModelArray = self.filteredModelArray.map({
                        var obj = $0
                        if var incomeArr = $0.incomeDetails, !incomeArr.isEmpty {
                            for (index, item) in incomeArr.enumerated() {
                                if item.incomeId == incomeID {
                                    incomeArr.remove(at: index)
                                }
                            }
                            obj.incomeDetails = incomeArr
                            
                            return obj
                        }
                        return obj
                    })
                    self.setListData()
                }
                
                
            }, failure: { (error) in
                
                self.setListData()
                
            }, noNetwork: { (error) in
                self.setListData()
            })
        }
        
    }
}

extension IncomeListVC : UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return filteredModelArray.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let arr = filteredModelArray[section].incomeDetails
        return arr?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SourcingCommonListCell", for: indexPath) as! SourcingCommonListCell
        
        cell.setProperties(optionArray: cellOptionArray.map({ $0.rawValue }), cellIndex: indexPath.row, cellSection: indexPath.section, delegate: self)
        let model = filteredModelArray[indexPath.section].incomeDetails?[indexPath.row]
        cell.label1.text = model?.incomeExpense?.name
	
        if let amount = model?.grossAmount, let percentage = model?.percentage, let per = Double(percentage) {
            let amt = Double(amount)
            let netAmt = "\((amt * per) / 100)".formatCurrency
            cell.label2.text = "\(model?.incomeFrequency?.name ?? "") \(Constants.SEPERATOR) " + "\(netAmt)"
        }
        else {
            if let year1 = model?.year1Income, let year2 = model?.year2Income, let year3 = model?.year3Income {
                cell.label2.text = "\(String(year1).formatCurrency) \(Constants.SEPERATOR) \(String(year2).formatCurrency) \(Constants.SEPERATOR) \(String(year3).formatCurrency)"
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let  headerCell = tableView.dequeueReusableCell(withIdentifier: "IncomeDeductionHeaderTVCell") as! IncomeDeductionHeaderTVCell
        let model = filteredModelArray[section]
        
        if model.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SAL.lowercased() {
            if let employer = model.employerName?.name {
                headerCell.setProperties(heading: "\(employer) (\(model.industry?.name ?? ""))", statusText: model.occupationType?.name ?? "")
            }
            else {
                headerCell.setProperties(heading: "\(model.otherEmployerName ?? "") (\(model.industry?.name ?? ""))", statusText: model.occupationType?.name ?? "")
            }
        }
        else if model.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_OTH.lowercased() {
            headerCell.setProperties(heading: model.natureOfOccupation?.name ?? "", statusText: model.occupationType?.name ?? "")
        }
        else if model.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SENP.lowercased() {

            headerCell.setProperties(heading: "\(model.organizationName ?? "") (\(model.natureOfBusiness?.name ?? ""))", statusText: model.occupationType?.name ?? "")
        }
        else if model.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SEP.lowercased() {
        
            headerCell.setProperties(heading: "\(model.organizationName ?? "") (\(model.natureOfProfession?.name ?? ""))", statusText: model.occupationType?.name ?? "")
        }
        else {
            headerCell.setProperties(heading: "", statusText: model.occupationType?.name ?? "")
        }
        return headerCell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        moveToDetailPage(index: indexPath.row, section: indexPath.section)
    }
}

extension IncomeListVC : NextBackButtonDelegate {
    func nextButtonAction() {
        
        let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = st.instantiateViewController(withIdentifier: "DeductionListVC") as? DeductionListVC  {
            vc.setData(applicationID: applicationID, customerID: customerID)
            AppDelegate.instance.applicationNavController.pushViewController(vc, animated: true)
        }
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension IncomeListVC : CommonListCellDelegate {
    func selectedIndex(index: Int, cellIndex: Int, cellSection: Int) {
        let item = self.cellOptionArray[index]
        if item == .edit {
            moveToDetailPage(index: cellIndex, section: cellSection)
        }
        else if item == .delete {
            CommonAlert.shared().showAlert(message: "Are you sure you want to delete income details?", cancelTitle: "Cancel" , okAction: { _ in
                self.deleteDataRow(index: cellIndex, sectionIndex: cellSection)
                
            })
        }
    }
}
