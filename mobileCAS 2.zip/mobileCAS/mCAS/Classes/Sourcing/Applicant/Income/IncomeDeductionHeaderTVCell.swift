//
//  IncomeDeductionHeaderTVCell.swift
//  mCAS
//
//  Created by iMac on 06/03/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class IncomeDeductionHeaderTVCell: UITableViewCell {
    @IBOutlet weak var statusLabel: EdgeInsetLabel!
    @IBOutlet weak var headingLabel: UILabel!
    
    func setProperties(heading: String, statusText: String) {
        
        headingLabel.font = CustomFont.shared().GETFONT_MEDIUM(16)
        statusLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        statusLabel.setStatusLabelProperties(borderColor: Color.SKY_BLUE)
        statusLabel.text = statusText
        headingLabel.text = heading
    }
}
