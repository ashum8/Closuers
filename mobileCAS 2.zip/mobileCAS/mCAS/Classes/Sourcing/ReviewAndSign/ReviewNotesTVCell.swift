//
//  ReviewNotesTVCell.swift
//  mCAS
//
//  Created by iMac on 16/03/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class ReviewNotesTVCell: UITableViewCell {
    
    @IBOutlet weak var noteCodeLOV: LOVFieldView!
    @IBOutlet weak var remarksLabel: EdgeInsetLabel!
    @IBOutlet weak var remarksView: UIView!
    @IBOutlet weak var remarksPlaceHolderLabel: UILabel!
    @IBOutlet weak var remarksTextView: UITextView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private let TAG_NOTECODE = 1000
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var applicationID: String!
    private var successPopView: SuccessPopupView!
    
    func setProperties(applicationID: String) {
        
        remarksLabel.text = "REMARKS"
        remarksLabel.font = CustomFont.shared().GETFONT_MEDIUM(17)
        remarksView.setMainViewProperties()
        remarksPlaceHolderLabel.setRemarks(title: "Type here")
        remarksTextView.setRemarksTextView()
        
        self.applicationID = applicationID
        
        // AK Change - LOV
        noteCodeLOV.setLOVProperties(masterName: Entity.BODY_MAN_NAME, title: "Note Code", tag: TAG_NOTECODE, delegate: self)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Reject Application", nextBtnTitle: "Submit Application", delegate: self)
    }
    
    private func openPopUp(number: String) {
        self.successPopView = .fromNib()
        self.successPopView.setProperties(width: AppDelegate.instance.window!.frame.size.width, height: AppDelegate.instance.window!.frame.size.height, delegate: self, line1: "Application has been successfully generated. You can track Application by Application ID ", line2: number)
        AppDelegate.instance.window?.addSubview(self.successPopView)
    }
}

extension ReviewNotesTVCell: SelectedLOVDelegate {
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
    }
}

extension ReviewNotesTVCell: NextBackButtonDelegate {
    func nextButtonAction() {
        
        if remarksTextView.text.isEmpty {
            CommonAlert.shared().showAlert(message: "Remark is Mandatory.")
            return
        }
        
        let param = ["neutronReferenceNumber"   : self.applicationID,
                     "remarks"                  : CommonUtils.shared().getValidatedString(string: remarksTextView.text),
                     "noteCode"                 : "OK"]   // AK Change
        
        Webservices.shared().POST(urlString: ServiceUrl.SUBMIT_SOURCING_APPLICATION_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                self.openPopUp(number: "APPL000002851") // AK Change - application id
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
    
    func backButtonAction() {
        
        if remarksTextView.text.isEmpty {
            CommonAlert.shared().showAlert(message: "Remark is Mandatory.")
            return
        }
        
        let param = ["neutronReferenceNumber"   : self.applicationID,
                     "remarks"                  : CommonUtils.shared().getValidatedString(string: remarksTextView.text)]
        
        Webservices.shared().POST(urlString: ServiceUrl.REJECT_SOURCING_APPLICATION_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                self.goToHomeAction()
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
    
}

extension ReviewNotesTVCell: UITextViewDelegate {
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let stringValue = CommonUtils.shared().getValidatedString(string: textView.text) + text
        return stringValue.count < Constants.REMARKS_LENGTH && stringValue.isAlphanumericAndSpace
    }
}

extension ReviewNotesTVCell: SuccessPopupDelegate {
    func goToHomeAction() {
        if let obj = AppDelegate.instance.getSpecificVC(targetClass: SourcingListVC.self) as? SourcingListVC {
            obj.fetchCases()
            AppDelegate.instance.applicationNavController.popToViewController(obj, animated: true)
        }
    }
}
