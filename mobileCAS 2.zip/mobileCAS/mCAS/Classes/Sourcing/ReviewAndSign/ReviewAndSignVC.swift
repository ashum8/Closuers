//
//  ReviewAndSignVC.swift
//  mCAS
//
//  Created by iMac on 13/04/20.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class ReviewAndSignVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    private struct SectionValueModel {
        var title: String
        var dataList: [KeyValueModel]
    }
    
    private var dataModelArray: [KeyValueModel] = []
    private var sectionModelArray: [SectionValueModel] = []
    private var modelData: SourcingModelClasses.ApplicationDetails?
    private var applicationId: String!
    
    let SECTION_STATIC = "BUTTON"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        tableView.register(UINib(nibName: "ReviewNotesTVCell", bundle: nil), forCellReuseIdentifier: "ReviewNotesTVCell")
        
        fetchList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "Review and Sign", showBack: true)
        }
    }
    
    private func setMainData() {
        sectionModelArray.removeAll()
        
        if let data = self.modelData {
            
            var loanDetailArr: [KeyValueModel] = []
            var productTypeCode = ""
            
            if let loanDetail = data.loanDetail {
                productTypeCode = CommonUtils.shared().getValidatedString(string: loanDetail.productType?.code)
                
                loanDetailArr.append(KeyValueModel(fieldName: "Branch", fieldValue: CommonUtils.shared().getValidatedString(string: loanDetail.branch?.name)))
                loanDetailArr.append(KeyValueModel(fieldName: "Product Category", fieldValue: CommonUtils.shared().getValidatedString(string: loanDetail.productType?.name)))
                loanDetailArr.append(KeyValueModel(fieldName: "Product", fieldValue: CommonUtils.shared().getValidatedString(string: loanDetail.product?.name)))
                loanDetailArr.append(KeyValueModel(fieldName: "Scheme", fieldValue: CommonUtils.shared().getValidatedString(string: loanDetail.scheme?.name)))
                loanDetailArr.append(KeyValueModel(fieldName: "Application Type", fieldValue: CommonUtils.shared().getValidatedString(string: loanDetail.applicationType?.name)))
                loanDetailArr.append(KeyValueModel(fieldName: "Loan Purpose", fieldValue: CommonUtils.shared().getValidatedString(string: loanDetail.loanPurpose?.name)))
                
                loanDetailArr.append(KeyValueModel(fieldName: "Loan Amount Requested", fieldValue: getUnWrapString(textVal: loanDetail.loanAmount).formatCurrency))
                
                loanDetailArr.append(KeyValueModel(fieldName: "Rate of interest", fieldValue: "\(getUnWrapString(textVal: loanDetail.rateOfInterest))%"))
                
                loanDetailArr.append(KeyValueModel(fieldName: "Tenure (Months)", fieldValue: getUnWrapString(textVal: loanDetail.tenure)))
                
                loanDetailArr.append(KeyValueModel(fieldName: "Installment Due Day", fieldValue: SourcingCommonUtil.shared().getFormattedDay(day: getUnWrapString(textVal: loanDetail.dueDay))))
                
            }
            
            sectionModelArray.append(SectionValueModel(title: "Application", dataList: loanDetailArr))
            
            // collateral data
            
            if productTypeCode != ConstantCodes.PRODUCT_TYPE_PF && productTypeCode != ConstantCodes.PRODUCT_TYPE_CC {
                
                var collateralDetailArr: [KeyValueModel] = []
                
                if let collateralArray = data.collateralDetails {
                    
                    for (index, item) in collateralArray.enumerated() {
                        if productTypeCode.lowercased() == ConstantCodes.PRODUCT_TYPE_LAP.lowercased() || productTypeCode.lowercased() == ConstantCodes.PRODUCT_TYPE_HL.lowercased() {
                            collateralDetailArr.append(KeyValueModel(fieldName: "Product", fieldValue: CommonUtils.shared().getValidatedString(string: item.collateralSubType?.name)))
                            
                            collateralDetailArr.append(KeyValueModel(fieldName: "Cost of Property", fieldValue: getUnWrapString(textVal: item.propertyPurchasePrice)))
                            
                            collateralDetailArr.append(KeyValueModel(fieldName: "Nature of Property", fieldValue: CommonUtils.shared().getValidatedString(string: item.natureOfProperty?.name)))
                            
                            if let address = item.addressVO?.getFullAddress() {
                                collateralDetailArr.append(KeyValueModel(fieldName: "Address", fieldValue: address))
                            }
                        }
                        else {
                            if productTypeCode != ConstantCodes.PRODUCT_TYPE_CV {
                                collateralDetailArr.append(KeyValueModel(fieldName: "", fieldValue: "Collateral \(index + 1)", isHeading: true))
                            }
                            if let collSubType = item.collateralSubType?.name {
                                collateralDetailArr.append(KeyValueModel(fieldName: "Product", fieldValue: collSubType))
                            }
                            else {
                                collateralDetailArr.append(KeyValueModel(fieldName: "Product", fieldValue: "Consumer Loans"))  //SK Change - CL
                            }
                            
                            collateralDetailArr.append(KeyValueModel(fieldName: "Asset Make", fieldValue: CommonUtils.shared().getValidatedString(string: item.assetMake?.name)))
                            collateralDetailArr.append(KeyValueModel(fieldName: "Asset Model", fieldValue: CommonUtils.shared().getValidatedString(string: item.assetModel?.name)))
                            collateralDetailArr.append(KeyValueModel(fieldName: "Asset Cost", fieldValue: getUnWrapString(textVal: item.assetCost)))
                        }
                    }
                    
                    sectionModelArray.append(SectionValueModel(title: "Collateral", dataList: collateralDetailArr))
                }
            }
            
            // Applicant data
            if let applicantArray = data.applicants {
                
                for item in applicantArray {
                    var applicantDetailArr: [KeyValueModel] = []
                    
                    if item.customerType.code?.lowercased() == Constants.CUSTOMER_TYPE_CORP.lowercased() {
                        applicantDetailArr.append(KeyValueModel(fieldName: "Institution Name", fieldValue: item.getFullName()))
                        applicantDetailArr.append(KeyValueModel(fieldName: "Nature of Business", fieldValue: CommonUtils.shared().getValidatedString(string: item.natureOfBusiness?.name)))
                        applicantDetailArr.append(KeyValueModel(fieldName: "Industry", fieldValue: CommonUtils.shared().getValidatedString(string: item.industry?.name)))
                    }
                    else {
                        applicantDetailArr.append(KeyValueModel(fieldName: "Applicant Full Name", fieldValue: item.getFullName()))
                        applicantDetailArr.append(KeyValueModel(fieldName: "Gender", fieldValue: CommonUtils.shared().getValidatedString(string: item.gender?.name)))
                        applicantDetailArr.append(KeyValueModel(fieldName: "Date of Birth", fieldValue: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: item.dateOfBirth)))
                        applicantDetailArr.append(KeyValueModel(fieldName: "Father's Full Name", fieldValue: CommonUtils.shared().getValidatedString(string: item.fatherName)))
                        
                        applicantDetailArr.append(KeyValueModel(fieldName: "Mother's Maiden Name", fieldValue: CommonUtils.shared().getValidatedString(string: item.motherMaidenName)))
                        applicantDetailArr.append(KeyValueModel(fieldName: "Marital Status", fieldValue: CommonUtils.shared().getValidatedString(string: item.maritalStatus?.name)))
                        applicantDetailArr.append(KeyValueModel(fieldName: "House Hold Type", fieldValue: CommonUtils.shared().getValidatedString(string: item.householdType?.name)))
                        
                        applicantDetailArr.append(KeyValueModel(fieldName: "No. of Adult Dependents", fieldValue: getUnWrapString(textVal: item.numOfDependents)))
                        applicantDetailArr.append(KeyValueModel(fieldName: "No. of Child Dependents", fieldValue: getUnWrapString(textVal: item.numOfChildDependents)))
                        
                        applicantDetailArr.append(KeyValueModel(fieldName: "Category", fieldValue: CommonUtils.shared().getValidatedString(string: item.customerCategory?.name)))
                        applicantDetailArr.append(KeyValueModel(fieldName: "Citizenship", fieldValue: CommonUtils.shared().getValidatedString(string: item.nationality?.name)))
                        applicantDetailArr.append(KeyValueModel(fieldName: "Residential Status", fieldValue: CommonUtils.shared().getValidatedString(string: item.residentialStatus?.name)))
                    }
                    
                    applicantDetailArr.append(KeyValueModel(fieldName: "Constitution", fieldValue: CommonUtils.shared().getValidatedString(string: item.constitution?.name)))
                    applicantDetailArr.append(KeyValueModel(fieldName: "Email ID", fieldValue: CommonUtils.shared().getValidatedString(string: item.emailAddress)))
                    
                    if let mobileNo = item.mobileNumber, let isdCode = item.isdCode?.name {
                        applicantDetailArr.append(KeyValueModel(fieldName: "Mobile Number", fieldValue: "\(isdCode)~\(mobileNo)"))
                    }
                    else {
                        applicantDetailArr.append(KeyValueModel(fieldName: "Mobile Number", fieldValue: ""))
                    }
                    
                    if let phoneNo = item.phoneNumber, let isdCode = item.isdCodePhoneNo?.name, let stdCode = item.stdCode {
                        applicantDetailArr.append(KeyValueModel(fieldName: "Phone Number", fieldValue: "\(isdCode)~\(stdCode)~\(phoneNo)"))
                    }
                    else {
                        applicantDetailArr.append(KeyValueModel(fieldName: "Phone Number", fieldValue: ""))
                    }
                    
                    applicantDetailArr.append(KeyValueModel(fieldName: "Preferred language", fieldValue: CommonUtils.shared().getValidatedString(string: item.preferredLanguage?.name)))
                    
                    if let identificationArray = item.identificationDetails {
                        
                        applicantDetailArr.append(KeyValueModel(fieldName: "", fieldValue: "IDs", isHeading: true))
                        
                        var addedIds = ""
                        var identificationArr: [KeyValueModel] = []
                        
                        for identityItem in identificationArray {
                            if let idType = identityItem.identificationType?.name, !idType.isEmpty {
                                addedIds = addedIds.isEmpty ? (CommonUtils.shared().getValidatedString(string: identityItem.identificationType?.name)) : (addedIds + ", " + (CommonUtils.shared().getValidatedString(string: identityItem.identificationType?.name)))
                            }
                            identificationArr.append(KeyValueModel(fieldName: CommonUtils.shared().getValidatedString(string: identityItem.identificationType?.name), fieldValue: CommonUtils.shared().getValidatedString(string: identityItem.identificationValue)))
                        }
                        
                        applicantDetailArr.append(KeyValueModel(fieldName: "IDs Added", fieldValue: addedIds))
                        applicantDetailArr.append(contentsOf: identificationArr)
                    }
                    
                    if let employmentArray = item.employmentDetails {
                        
                        for (index, item) in employmentArray.enumerated() {
                            
                            applicantDetailArr.append(KeyValueModel(fieldName: "", fieldValue: "EMPLOYEMENT \(index + 1)", isHeading: true))
                            
                            applicantDetailArr.append(KeyValueModel(fieldName: "Employment Type", fieldValue: CommonUtils.shared().getValidatedString(string: item.occupationType?.name)))
                            
                            if item.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SAL.lowercased()
                            {
                                if let name = item.otherEmployerName, !name.isEmpty {
                                    applicantDetailArr.append(KeyValueModel(fieldName: "Employer Name", fieldValue: name))
                                }
                                else {
                                    applicantDetailArr.append(KeyValueModel(fieldName: "Employer Name", fieldValue: CommonUtils.shared().getValidatedString(string: item.employerName?.name)))
                                }
                                
                                applicantDetailArr.append(KeyValueModel(fieldName: "Industry", fieldValue: CommonUtils.shared().getValidatedString(string: item.industry?.name)))
                                applicantDetailArr.append(KeyValueModel(fieldName: "Employed From", fieldValue: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: CommonUtils.shared().getValidatedString(string: item.employedFrom))))
                            }
                            else if item.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_OTH.lowercased() {
                                applicantDetailArr.append(KeyValueModel(fieldName: "Nature of Occupation", fieldValue: CommonUtils.shared().getValidatedString(string: item.natureOfOccupation?.name)))
                            }
                            else if item.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SENP.lowercased() {
                                
                                applicantDetailArr.append(KeyValueModel(fieldName: "Organization Name", fieldValue: CommonUtils.shared().getValidatedString(string: item.organizationName)))
                                applicantDetailArr.append(KeyValueModel(fieldName: "Nature of Business", fieldValue: CommonUtils.shared().getValidatedString(string: item.natureOfBusiness?.name)))
                            }
                            else if item.occupationType?.code?.lowercased() == ConstantCodes.EMP_TYPE_SEP.lowercased() {
                                
                                applicantDetailArr.append(KeyValueModel(fieldName: "Organization Name", fieldValue: CommonUtils.shared().getValidatedString(string: item.organizationName)))
                                applicantDetailArr.append(KeyValueModel(fieldName: "Nature of Profession", fieldValue: CommonUtils.shared().getValidatedString(string: item.natureOfProfession?.name)))
                            }
                            else {
                                applicantDetailArr.append(KeyValueModel(fieldName: "Nature of Occupation", fieldValue: CommonUtils.shared().getValidatedString(string: item.natureOfOccupation?.name)))
                            }
                        }
                    }
                    
                    if let addressArray = item.addressDetails {
                        applicantDetailArr.append(KeyValueModel(fieldName: "", fieldValue: "Address", isHeading: true))
                        
                        for addressItem in addressArray {
                            applicantDetailArr.append(KeyValueModel(fieldName: CommonUtils.shared().getValidatedString(string: addressItem.addressType?.name), fieldValue: addressItem.getFullAddress()))
                        }
                    }
                    
                    if let incomeArray = item.incomeAssetDetails {
                        applicantDetailArr.append(KeyValueModel(fieldName: "", fieldValue: "Net Asset", isHeading: true))
                        
                        var amount: Double = 0.0
                        for incomeItem in incomeArray {
                            amount += incomeItem.incomeAssetValue ?? 0.0
                        }
                        applicantDetailArr.append(KeyValueModel(fieldName: "Net Asset Amount", fieldValue: "\(amount)".formatCurrency))
                    }
                    
                    if let expenseArray = item.expenseDetails {
                        applicantDetailArr.append(KeyValueModel(fieldName: "", fieldValue: "Net Expense", isHeading: true))
                        
                        var amount: Double = 0.0
                        for expenseItem in expenseArray {
                            amount += expenseItem.grossAmount ?? 0.0
                        }
                        applicantDetailArr.append(KeyValueModel(fieldName: "Net Expense Amount", fieldValue: "\(amount)".formatCurrency))
                    }
                    
                    if let liabilityArray = item.liabilityDetails {
                        applicantDetailArr.append(KeyValueModel(fieldName: "", fieldValue: "Net Liability", isHeading: true))
                        
                        var amount: Double = 0.0
                        for liabilityItem in liabilityArray {
                            amount += liabilityItem.balance ?? 0.0
                        }
                        applicantDetailArr.append(KeyValueModel(fieldName: "Net Liability Amount", fieldValue: "\(amount)".formatCurrency))
                    }
                    
                    if let employmentArray = item.employmentDetails {
                        var income = 0.0
                        var deduction = 0.0
                        
                        for employmentItem in employmentArray {
                            if let incomeArr = employmentItem.incomeDetails {
                                for data in incomeArr {
                                    if let amount = data.grossAmount, let percentage = data.percentage, let per = Double(percentage) {
                                        let amt = Double(amount)
                                        income += (amt * per)/100
                                    }
                                    else {
                                        if let year3 = data.year3Income {
                                            income += year3
                                        }
                                    }
                                }
                            }
                            if let dedArr = employmentItem.deductionDetails {
                                for data in dedArr {
                                    if let amount = data.grossAmount, let percentage = data.percentage, let per = Double(percentage) {
                                        let amt = Double(amount)
                                        deduction += (amt * per)/100
                                    }
                                    else {
                                        if let year3 = data.year3Deduction {
                                            deduction += year3
                                        }
                                    }
                                }
                            }
                        }
                        if income > 0.0 {
                            applicantDetailArr.append(KeyValueModel(fieldName: "", fieldValue: "Net Income", isHeading: true))
                            applicantDetailArr.append(KeyValueModel(fieldName: "Net Income Amount", fieldValue: "\(income)".formatCurrency))
                        }
                        if deduction > 0.0 {
                            applicantDetailArr.append(KeyValueModel(fieldName: "", fieldValue: "Net Deduction", isHeading: true))
                            applicantDetailArr.append(KeyValueModel(fieldName: "Net Deduction Amount", fieldValue: "\(deduction)".formatCurrency))
                        }
                    }
                    if item.applicantRole?.code?.lowercased() == Constants.APPLICANT_ROLE_CODE_PRIMARY.lowercased()  {
                        sectionModelArray.append(SectionValueModel(title: Constants.APPLICANT_ROLE_NAME_PRIMARY, dataList: applicantDetailArr))
                    }
                    else if item.applicantRole?.code?.lowercased() == Constants.APPLICANT_ROLE_CODE_COAPPL.lowercased()  {
                        sectionModelArray.append(SectionValueModel(title: Constants.APPLICANT_ROLE_NAME_COAPPL, dataList: applicantDetailArr))
                    }
                    else if item.applicantRole?.code?.lowercased() == Constants.APPLICANT_ROLE_CODE_GUARANTOR.lowercased()  {
                        sectionModelArray.append(SectionValueModel(title: Constants.APPLICANT_ROLE_NAME_GUARANTOR, dataList: applicantDetailArr))
                    }
                }
            }
            else {
                sectionModelArray.append(SectionValueModel(title: Constants.APPLICANT_ROLE_NAME_PRIMARY, dataList: []))
            }
            
            // processing fee
            
            var feeDetailArr: [KeyValueModel] = []
            
            if let feeDetail = data.initialMoneyDeposits {
                
                for (index, item) in feeDetail.enumerated() {
                    
                    feeDetailArr.append(KeyValueModel(fieldName: "", fieldValue: "Processing Fees \(index + 1)", isHeading: true))
                    feeDetailArr.append(KeyValueModel(fieldName: "Payment Mode", fieldValue: CommonUtils.shared().getValidatedString(string: item.paymentModeType?.name)))
                    
                    if item.paymentModeType?.code?.lowercased() == ConstantCodes.PAYMENT_MODE_CASH.lowercased() {
                        
                        feeDetailArr.append(KeyValueModel(fieldName: "Amount", fieldValue: getUnWrapString(textVal: item.amount).formatCurrency))
                    }
                    else if item.paymentModeType?.code?.lowercased() == ConstantCodes.PAYMENT_MODE_EFT.lowercased() {
                        feeDetailArr.append(KeyValueModel(fieldName: "Sub Payment Mode", fieldValue: CommonUtils.shared().getValidatedString(string: item.subPaymentModeType?.name)))
                    }
                    else {
                        feeDetailArr.append(KeyValueModel(fieldName: "Instrument Date", fieldValue: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: item.instrumentDate)))
                        feeDetailArr.append(KeyValueModel(fieldName: "Instrument Number", fieldValue: CommonUtils.shared().getValidatedString(string: item.instrumentNumber)))
                        feeDetailArr.append(KeyValueModel(fieldName: "MICR Code", fieldValue: CommonUtils.shared().getValidatedString(string: item.micrCode)))
                    }
                    
                    feeDetailArr.append(KeyValueModel(fieldName: "Remark", fieldValue: CommonUtils.shared().getValidatedString(string: item.remarks)))
                    feeDetailArr.append(KeyValueModel(fieldName: "Receipt Number", fieldValue: CommonUtils.shared().getValidatedString(string: item.receiptNumber)))
                }
                
                sectionModelArray.append(SectionValueModel(title: "Processing Fees", dataList: feeDetailArr))
            }
        }
        
        sectionModelArray.append(SectionValueModel(title: SECTION_STATIC, dataList: []))
        reloadTable()
    }
    
    private func getUnWrapString(textVal: Any?) -> String
    {
        if let str = textVal as? String {
            return str
        }
        else if let str = textVal as? Double {
            return "\(str)"
        }
        else if let str = textVal as? Int {
            return "\(str)"
        }
        
        return ""
    }
    
    func setData(applicationId: String) {
        self.applicationId = applicationId
    }
    
    private func reloadTable() {
        tableView.reloadData()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02, execute: {
            self.tableView.reloadData()
        })
    }
    
    func fetchList() {
        
        let param = ["neutronReferenceNumber" : applicationId]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_ALL_APPLICATION_DETAIL_URL, paramaters: param, autoHandleLoader: true, allowOfflineAlert: false, success: { (header, responseObj) in
            
            if let response = responseObj as? [String: Any]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: SourcingModelClasses.ApplicationDetails.self) { record in
                    self.modelData = record
                    self.setMainData()
                }
            }
            
        }, failure: { (error) in
            self.setMainData()
        }, noNetwork: { (error) in
            self.setMainData()
        })
    }
}

extension ReviewAndSignVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sectionModelArray.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if sectionModelArray[indexPath.section].title == SECTION_STATIC {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ReviewNotesTVCell") as! ReviewNotesTVCell
            cell.setProperties(applicationID: self.applicationId)
            return cell
        }
        else {
            let identifier = "LoanDetailTVCell_\(sectionModelArray[indexPath.section].title)"
            var cell = tableView.dequeueReusableCell(withIdentifier: identifier) as? LoanDetailTableViewCell
            
            if cell == nil {
                tableView.register(UINib(nibName: "LoanDetailTableViewCell", bundle: nil), forCellReuseIdentifier: identifier)
                cell = tableView.dequeueReusableCell(withIdentifier: identifier) as? LoanDetailTableViewCell
            }
            //SK Change - data mess format corrupt
            cell!.setProperties(title: sectionModelArray[indexPath.section].title, arrList: sectionModelArray[indexPath.section].dataList, delegate: self, isCollapsable: true)
            return cell!
        }
    }
}

extension ReviewAndSignVC: ButtonTVCDelegate {
    
    func buttonAction() {
        
    }
}

extension ReviewAndSignVC: LDTableViewDelegate {
    func reloadCell() {
        reloadTable()
    }
}

