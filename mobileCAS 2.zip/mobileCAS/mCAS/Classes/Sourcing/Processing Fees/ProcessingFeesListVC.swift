//
//  ProcessingFeesListVC.swift
//  mCAS
//
//  Created by iMac on 17/03/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class ProcessingFeesListVC: UIViewController {
    
    private enum DetailOptions: String {
        case edit = "Edit"
        case delete = "Delete"
    }
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var addNewButton: UIButton!
    @IBOutlet weak var buttonViewHeight: NSLayoutConstraint!
    
    private var cellOptionArray: [DetailOptions] = [.edit, .delete]
    private var listModelArray = [SourcingModelClasses.ProcessingDetails.InitialMoneyDeposits]()
    private var applicationID: String!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties(title: "You have not added processing fee yet!")
        addNewButton.setButtonProperties()
        
        tableView.register(UINib.init(nibName: "SourcingCommonListCell", bundle: Bundle.main), forCellReuseIdentifier: "SourcingCommonListCell")
        tableView.tableFooterView = UIView()
        
        buttonView.setProperties(nextBtnTitle: "Done", delegate: self)
        
        fetchList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            headerView.showHideStepHeader(isHide: false, title: "Processing Fee", landingPage: AppDelegate.instance.getSpecificVC(targetClass: SourcingDashboardVC.self))
            bottomView.isHidden = true
        }
    }
    
    private func setListData() {
        tableView.isHidden = listModelArray.isEmpty
        addButton.isHidden = listModelArray.isEmpty
        noDataCapturedView.isHidden = !tableView.isHidden
        addNewButton.isHidden = !tableView.isHidden
        buttonViewHeight.constant = tableView.isHidden ? 0 : 45
        self.tableView.reloadData()
    }
    
    func setData(applicationID: String) {
        self.applicationID = applicationID
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        addButton.sendActions(for: .touchUpInside)
    }
    
    @IBAction func plusButtonAction(_ sender: Any) {
        
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "AddProcessingFeesVC") as? AddProcessingFeesVC {
            vc.setData(applicationID: applicationID)
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    
    private func moveToDetailPage(index:Int) {
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "AddProcessingFeesVC") as? AddProcessingFeesVC {
            vc.setData(applicationID: applicationID, dataObj: listModelArray[index])
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    
    func fetchList() {

        let param = ["neutronReferenceNumber" : applicationID]
        listModelArray.removeAll()
        Webservices.shared().POST(urlString: ServiceUrl.GET_ALL_PROCESSING_FEE_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String: Any]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: SourcingModelClasses.ProcessingDetails.self) { record in
                    if let list = record.initialMoneyDeposits {
                        self.listModelArray.append(contentsOf: list)
                    }
                }
            }
            self.setListData()
            
        }, failure: { (error) in
            
            self.setListData()
            
        }, noNetwork: { (error) in
            self.setListData()
        })
    }
    
    private func deleteDataRow(index: Int) {
        
        let param = ["imdId"   : listModelArray[index].imdId]
        
        Webservices.shared().POST(urlString: ServiceUrl.DELETE_PROCESSING_FEE_URL, paramaters: param, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                self.listModelArray.remove(at: index)
                self.setListData()
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
    
}

extension ProcessingFeesListVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModelArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let optionArray = cellOptionArray.map({ $0.rawValue })
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SourcingCommonListCell") as! SourcingCommonListCell
        let model = listModelArray[indexPath.row]
        cell.label1.text = model.paymentModeType?.name
        if model.paymentModeType?.code?.lowercased() == ConstantCodes.PAYMENT_MODE_CHEQUE.lowercased() || model.paymentModeType?.code?.lowercased() == ConstantCodes.PAYMENT_MODE_DEMAND_DRAFT.lowercased() {
            cell.label2.text = "\(CommonUtils.shared().getValidatedString(string: model.amount).formatCurrency) \(Constants.SEPERATOR) \(CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: CommonUtils.shared().getValidatedString(string: model.instrumentDate))) \(Constants.SEPERATOR) \(CommonUtils.shared().getValidatedString(string: model.instrumentNumber))"
        }
        else if model.paymentModeType?.code?.lowercased() == ConstantCodes.PAYMENT_MODE_EFT.lowercased() {
            cell.label2.text = CommonUtils.shared().getValidatedString(string: model.amount).formatCurrency
            cell.label3.text = model.subPaymentModeType?.name
        }
        else {
           cell.label2.text = CommonUtils.shared().getValidatedString(string: model.amount).formatCurrency
        }
        
        cell.setProperties(optionArray: optionArray, cellIndex: indexPath.row, delegate: self, showRemark: !(model.remarks?.isEmpty ?? true), popupMsg: CommonUtils.shared().getValidatedString(string: model.remarks))
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        moveToDetailPage(index:indexPath.row)
    }
    
}

extension ProcessingFeesListVC: NextBackButtonDelegate {
    func nextButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension ProcessingFeesListVC: CommonListCellDelegate {
    func selectedIndex(index: Int, cellIndex: Int, cellSection: Int) {
        let item = self.cellOptionArray[index]
        if item == .edit {
            moveToDetailPage(index:cellIndex)
        }
        else if item == .delete {
            deleteDataRow(index: cellIndex)
        }
    }
}



