//
//  AddProcessingFeesVC.swift
//  mCAS
//
//  Created by iMac on 17/03/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddProcessingFeesVC: UIViewController {
    
    @IBOutlet weak var paymentModeLOV: LOVFieldView!
    @IBOutlet weak var amountView: CustomTextFieldView!
    @IBOutlet weak var amountViewHeight: NSLayoutConstraint!
    @IBOutlet weak var instrumentDateView: CustomTextFieldView!
    @IBOutlet weak var instrumentDateViewHeight: NSLayoutConstraint!
    @IBOutlet weak var instrumentNumberView: CustomTextFieldView!
    @IBOutlet weak var instrumentNumberViewHeight: NSLayoutConstraint!
    @IBOutlet weak var micrCodeView: CustomTextFieldView!
    @IBOutlet weak var micrCodeViewHeight: NSLayoutConstraint!
    @IBOutlet weak var subPaymentModeLOV: LOVFieldView!
    @IBOutlet weak var subPaymentModeLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var receiptNumberView: CustomTextFieldView!
    @IBOutlet weak var receiptNumberViewHeight: NSLayoutConstraint!
    @IBOutlet weak var remarksView: UIView!
    @IBOutlet weak var remarksLabel: UILabel!
    @IBOutlet weak var remarksTextView: UITextView!
    
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private let TAG_PAYMENT_MODE        = 1000
    private let TAG_SUB_PAYMENT_MODE    = 1001
    
    private let TAG_AMOUNT              = 1002
    private let TAG_INS_NUMBER          = 1003
    private let TAG_MICR_CODE           = 1004
    private let TAG_REC_NUMBER          = 1005
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var applicationID: String!
    private var dataObj: SourcingModelClasses.ProcessingDetails.InitialMoneyDeposits?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    private func setupView() {
        
        paymentModeLOV.setLOVProperties(masterName: Entity.PAYMENT_MODES, title: "Payment Mode", tag: TAG_PAYMENT_MODE, delegate: self) // AK Change - Filter
        amountView.setProperties(placeHolder: "Amount",type: .Amount, delegate: self, tag: TAG_AMOUNT)
        instrumentDateView.setProperties(placeHolder: "Instrument Date", type: .DATE, delegate: self)
        instrumentNumberView.setProperties(placeHolder: "Instrument Number", type: .Number, delegate: self, tag: TAG_INS_NUMBER)
        micrCodeView.setProperties(placeHolder: "MICR Code", type: .Number, delegate: self, tag: TAG_MICR_CODE)
        subPaymentModeLOV.setLOVProperties(masterName: Entity.SUBPAYMENT_MODES, title: "Sub Payment Mode", tag: TAG_SUB_PAYMENT_MODE, delegate: self)
        receiptNumberView.setProperties(placeHolder: "Receipt Number", delegate: self, tag: TAG_REC_NUMBER)
        
        remarksView.setMainViewProperties()
        remarksLabel.setRemarks(title: "Remark (Optional)")
        remarksTextView.setRemarksTextView()
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        fillDataInEditMode(dataObj: dataObj)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Processing Fee")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader()
        }
    }
    
    func setData(applicationID: String, dataObj: SourcingModelClasses.ProcessingDetails.InitialMoneyDeposits? = nil) {
        self.applicationID = applicationID
        self.dataObj = dataObj
    }
    
    private func fillDataInEditMode(dataObj: SourcingModelClasses.ProcessingDetails.InitialMoneyDeposits?) {
        if let data = dataObj {
            paymentModeLOV.autoFillLOVBy(key: data.paymentModeType?.code)
            amountView.setFieldValue(text: CommonUtils.shared().getValidatedString(string: data.amount))
            remarksTextView.text = data.remarks
            receiptNumberView.setFieldValue(text: data.receiptNumber)
            
            instrumentNumberView.setFieldValue(text: data.instrumentNumber)
            instrumentDateView.setFieldValue(text: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: CommonUtils.shared().getValidatedString(string: data.instrumentDate)))
            micrCodeView.setFieldValue(text: data.micrCode)
            subPaymentModeLOV.autoFillLOVBy(key: data.subPaymentModeType?.code)
            buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Update", delegate: self)
        }
        validateFields()
    }
    
    private func refreshFieldData() {
        amountView.setFieldValue()
        receiptNumberView.setFieldValue()
        remarksTextView.text = ""
        instrumentDateView.setFieldValue()
        instrumentNumberView.setFieldValue()
        micrCodeView.setFieldValue()
        subPaymentModeLOV.resetLOVWithParentKey()
    }
    
}

extension AddProcessingFeesVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        if (selectedLOVDic["\(TAG_PAYMENT_MODE)"] == nil || amountView.getFieldValue().isEmpty || receiptNumberView.getFieldValue().isEmpty) {
            
            isEnabled = false
        }
        
        if selectedLOVDic["\(TAG_PAYMENT_MODE)"]?.code.lowercased() == ConstantCodes.PAYMENT_MODE_CHEQUE.lowercased() || selectedLOVDic["\(TAG_PAYMENT_MODE)"]?.code.lowercased() == ConstantCodes.PAYMENT_MODE_DEMAND_DRAFT.lowercased() {
            
            isEnabled = isEnabled && !(instrumentDateView.getFieldValue().isEmpty || instrumentNumberView.getFieldValue().isEmpty || micrCodeView.getFieldValue().isEmpty )
            
        }
        else if selectedLOVDic["\(TAG_PAYMENT_MODE)"]?.code.lowercased() == ConstantCodes.PAYMENT_MODE_EFT.lowercased() {
            isEnabled = isEnabled && !(selectedLOVDic["\(TAG_SUB_PAYMENT_MODE)"] == nil)
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            let amount = Double(text) ?? 0.0
            return amount <= SourcingCommonUtil.shared().maxAmount && amount > 0
            
        case TAG_REC_NUMBER:
            return text.isAlphanumeric && text.count < 30
            
        case TAG_INS_NUMBER:
            return text.count <= 6
            
        case TAG_MICR_CODE:
            return text.count <= 9
            
        default:
            return true
        }
    }
}

extension AddProcessingFeesVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_PAYMENT_MODE {
            refreshFieldData()
            remarksView.isHidden = false
            receiptNumberViewHeight.constant = 65
            amountViewHeight.constant = 65
            
            if selectedObj.code.lowercased() == ConstantCodes.PAYMENT_MODE_CASH.lowercased() {
                instrumentDateViewHeight.constant = 0
                instrumentNumberViewHeight.constant = 0
                micrCodeViewHeight.constant = 0
                subPaymentModeLOVHeight.constant = 0
                
            }
            else if selectedObj.code.lowercased() == ConstantCodes.PAYMENT_MODE_CHEQUE.lowercased() || selectedObj.code.lowercased() == ConstantCodes.PAYMENT_MODE_DEMAND_DRAFT.lowercased() {
                instrumentDateViewHeight.constant = 65
                instrumentNumberViewHeight.constant = 65
                micrCodeViewHeight.constant = 65
                subPaymentModeLOVHeight.constant = 0
                
            }
            else if selectedObj.code.lowercased() == ConstantCodes.PAYMENT_MODE_EFT.lowercased() {
                subPaymentModeLOVHeight.constant = 65
                
                instrumentDateViewHeight.constant = 0
                instrumentNumberViewHeight.constant = 0
                micrCodeViewHeight.constant = 0
                
            }
            
        }
        validateFields()
    }
}

extension AddProcessingFeesVC: UITextViewDelegate {
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let stringValue = (textView.text ?? "") + text
        return stringValue.count < Constants.REMARKS_LENGTH && stringValue.isAlphanumericAndSpace
    }
}

extension AddProcessingFeesVC: NextBackButtonDelegate {
    func nextButtonAction() {
        var imdID = ""
        if let dataObj = dataObj {
            imdID = dataObj.imdId!
        }
        else {
            imdID = SourcingCommonUtil.shared().generateApplicationID()
        }
        
        var imdParam: [String: Any] = [:]
        imdParam["imdId"]               = imdID
        imdParam["paymentModeType"]     = ["code"   :   selectedLOVDic["\(TAG_PAYMENT_MODE)"]?.code,
                                           "name"   :   selectedLOVDic["\(TAG_PAYMENT_MODE)"]?.name]
        imdParam["remarks"]             = remarksTextView.text
        imdParam["receiptNumber"]       = receiptNumberView.getFieldValue()
        imdParam["amount"]              = amountView.getFieldValue()
        
        if selectedLOVDic["\(TAG_PAYMENT_MODE)"]?.code.lowercased() == ConstantCodes.PAYMENT_MODE_CHEQUE.lowercased() || selectedLOVDic["\(TAG_PAYMENT_MODE)"]?.code.lowercased() == ConstantCodes.PAYMENT_MODE_DEMAND_DRAFT.lowercased() {
            
            imdParam["instrumentDate"]      = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: instrumentDateView.getFieldValue(), outputFormat: Constants.DATE_FORMAT_SERVICE)
            imdParam["instrumentNumber"]    = instrumentNumberView.getFieldValue()
            imdParam["micrCode"]            = micrCodeView.getFieldValue()
            
            
        }
        else if selectedLOVDic["\(TAG_PAYMENT_MODE)"]?.code.lowercased() == ConstantCodes.PAYMENT_MODE_EFT.lowercased() {
            imdParam["subPaymentModeType"]  = ["code"   :   selectedLOVDic["\(TAG_SUB_PAYMENT_MODE)"]?.code,
                                               "name"   :   selectedLOVDic["\(TAG_SUB_PAYMENT_MODE)"]?.name]
        }
        
        
        
        
        let param: [String : Any] = ["neutronReferenceNumber"       : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                     "initialMoneyDeposits"         : [imdParam]]
        
        Webservices.shared().POST(urlString: ServiceUrl.SAVE_PROCESSING_FEE_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                if let obj = AppDelegate.instance.getSpecificVC(targetClass: ProcessingFeesListVC.self) as? ProcessingFeesListVC {
                    obj.fetchList()
                }
                self.navigationController?.popViewController(animated: true)
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
        
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
