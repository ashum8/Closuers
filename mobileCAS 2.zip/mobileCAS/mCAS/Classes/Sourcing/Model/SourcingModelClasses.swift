//
//  SourcingModelClasses.swift
//  mCAS
//
//  Created by Mac on 31/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import Foundation

class SourcingModelClasses {
    struct SourcingList: Codable {
        let list: [SourcingModel]?
    }
    
    struct SourcingModel: Codable {
        
        let applicant: ApplicantModel?
        let loanDetail: LoanDetail?
        let neutronReferenceNumber: String
        let collateralPresent : Bool?
        
        struct LoanDetail: Codable {
            let rateOfInterest: Double?
            let loanAmount: Double?
            let noOfAdvanceEmi: Int?
            let tenure: Int?
            let dueDay: Int?
            let productType: ProductType?
            let product: Product?
            let scheme: Scheme?
            let loanPurpose: LoanPurpose?
            let rmOfficer: RmOfficer?
            let applicationType: ApplicationType?
            let branch: Branch?
            
            struct ProductType: Codable {
                let code: String?
                let name: String?
            }
            
            struct Product: Codable {
                let code: String?
                let name: String?
            }
            
            struct Scheme: Codable {
                let code: String?
                let name: String?
            }
            
            struct LoanPurpose: Codable {
                let code: String?
                let name: String?
            }
            
            struct Branch: Codable {
                let code: String?
                let name: String?
            }
            
            struct RmOfficer: Codable {
                let code: String?
                let name: String?
            }
            
            struct ApplicationType: Codable {
                let code: String?
                let name: String?
            }
        }
    }
    
    struct CustomerType: Codable {
        let code: String?
        let name: String?
    }
    
    struct NatureOfBusiness: Codable {
        let code : String?
        let name : String?
    }
    
    struct Industry: Codable {
        let code : String?
        let name : String?
    }
    
    struct PostalCode: Codable {
        let code : String?
        let name : String?
    }
    
    struct PaymentModeType : Codable {
        let code : String?
        let name : String?
    }
    
    struct SubPaymentModeType : Codable {
        let code : String?
        let name : String?
    }
    
    
    // Identification Model
    
    struct IdentificationModel: Codable {
        let identificationType : IdentificationType?
        let identificationValue : String?
        let issueDate : String?
        let expiryDate : String?
        let issuingCountry : IssuingCountry?
        let attemptsDone : Int?
        let neutronIdentificationId : String?
        
        struct IssuingCountry: Codable {
            let code : String?
            let name : String?
        }
        
        struct IdentificationType: Codable {
            let code : String?
            let name : String?
        }
    }
    
    // Employment Model and Income Model
    
    struct EmploymentModel: Codable {
        let id : Int?
        let industry : Industry?
        let occupationType : OccupationType?
        let employerName : EmployerName?
        let majorOccupation : Bool?
        let natureOfBusiness : NatureOfBusiness?
        let natureOfProfession : NatureOfProfession?
        let natureOfOccupation : NatureOfOccupation?
        let otherEmployerName : String?
        let organizationName : String?
        let registrationNumber : String?
        let employedFrom : String?
        let employmentId : String?
        var incomeDetails : [IncomeDetail]?
        var deductionDetails : [DeductionDetail]?
        
        struct NatureOfProfession: Codable {
            let code : String?
            let name : String?
        }
        
        struct NatureOfOccupation: Codable {
            let code : String?
            let name : String?
        }
        
        struct OccupationType: Codable {
            let code : String?
            let name : String?
        }
        
        struct EmployerName: Codable {
            let code : String?
            let name : String?
        }
        
        struct DeductionDetail: Codable {
            let deductionId : String?
            let deductionType : DeductionType?
            let deductionFrequency : DeductionFrequency?
            let grossAmount : Double?
            let percentage : String?
            let netAmount : String?
            let year1Deduction : Double?
            let year2Deduction : Double?
            let year3Deduction : Double?
            
            struct DeductionType: Codable {
                let code : String?
                let name : String?
            }
            
            struct DeductionFrequency: Codable {
                let code : String?
                let name : String?
            }  
        }
        
        struct IncomeDetail: Codable {
            let incomeId : String?
            let id : Int?
            let incomeExpense : IncomeExpense?
            let incomeFrequency : IncomeFrequency?
            let grossAmount : Double?
            let percentage : String?
            let netAmount : String?
            let year1Income : Double?
            let year2Income : Double?
            let year3Income : Double?
        }
        
        struct IncomeExpense: Codable {
            let code : String?
            let id : Int?
            let name : String?
        }
        
        struct IncomeFrequency: Codable {
            let code : String?
            let id : Int?
            let name : String?
        }
    }
    
    // Address Model
    
    struct AddressModel: Codable {
        let unit : String?
        let streetNo : String?
        let streetName : String?
        let landmark : String?
        let communicationAddress : Bool?
        let addressType : AddressType?
        let state : State?
        let city : City?
        let country : Country?
        let postalCode : PostalCode?
        let residenceType : ResidenceType?
        let residentialStatus : ResidentialStatus?
        let numberOfYearsAtAddress : Int?
        let numberOfMonthsAtAddress : Int?
        let numberOfYearsAtCity : Int?
        let numberOfMonthsAtCity : Int?
        let sameAsOfficeAddr : Bool?
        let sameAsPermanentAddr : Bool?
        let sameAsResidentialAddr : Bool?
        let neutronAddressId : String?
        
        struct AddressType: Codable {
            let code : String?
            let name : String?
        }
        
        struct ResidenceType: Codable {
            let code : String?
            let name : String?
        }
        
        struct ResidentialStatus: Codable {
            let code : String?
            let name : String?
        }
        
        struct State: Codable {
            let code : String?
            let name : String?
        }
        
        struct City: Codable {
            let code : String?
            let name : String?
        }
        
        struct Country: Codable {
            let code : String?
            let name : String?
        }
        
        func getFullAddress() -> String {
            var address = ""
            
            if let unit = self.unit, !unit.isEmpty {
                address = unit
            }
            if let streetNo = self.streetNo, !streetNo.isEmpty {
                address = "\(address), \(streetNo)"
            }
            if let streetName = self.streetName, !streetName.isEmpty {
                address = "\(address), \(streetName)"
            }
            if let landmark = self.landmark, !landmark.isEmpty {
                address = "\(address), \(landmark)"
            }
            if let city = self.city?.name, !city.isEmpty {
                address = "\(address), \(city)"
            }
            if let state = self.state?.name, !state.isEmpty {
                address = "\(address), \(state)"
            }
            if let country = self.country?.name, !country.isEmpty {
                address = "\(address), \(country)"
            }
            if let postalCode = self.postalCode?.name, !postalCode.isEmpty {
                address = "\(address), \(postalCode)"
            }
            
            return address
        }
    }
    
    
    // Applicant Model
    
    struct ApplicantModel: Codable {
        let applicantRole : ApplicantRole?
        let customerType : CustomerType
        let salutation : Salutation?
        let firstName : String?
        let middleName : String?
        let lastName : String?
        let institutionName: String?
        let emailAddress : String?
        let isdCode : IsdCode?
        let dateOfBirth : String?
        let gender : Gender?
        let maritalStatus : MaritalStatus?
        let constitution : Constitution?
        let mobileNumber : String?
        let fatherName : String?
        let natureOfBusiness : NatureOfBusiness?
        let industryClassification : IndustryClassification?
        let industry : Industry?
        let motherMaidenName : String?
        let customerCategory : CustomerCategory?
        let residentialStatus : ResidentialStatus?
        let preferredLanguage : PreferredLanguage?
        let partyRelationship : RelationShip?
        let phoneNumber : String?
        let neutronCustRefNumber : String
        let incorporationDate : String?
        let numOfDependents : Int?
        let numOfChildDependents : Int?
        let isdCodePhoneNo : IsdCodePhoneNo?
        let householdType : HouseholdType?
        let extn : String?
        let stdCode : String?
        let nationality : Nationality?
        let identificationDetails : [IdentificationModel]?
        let addressDetails : [AddressModel]?
        let employmentDetails : [EmploymentModel]?
        let incomeAssetDetails : [AssetModel]?
        let expenseDetails : [ExpenseModel]?
        let liabilityDetails : [LiabilityModel]?
        
        struct ApplicantRole: Codable {
            let code : String?
            let name : String?
        }
        
        struct RelationShip: Codable {
            let code : String?
            let name : String?
        }
        
        struct Constitution: Codable {
            let code : String?
            let name : String?
        }
        
        struct CustomerCategory: Codable {
            let code : String?
            let name : String?
        }
        
        struct IndustryClassification: Codable {
            let code : String?
            let name : String?
        }
        
        struct Salutation: Codable {
            let code : String?
            let name : String?
        }
        
        struct ResidentialStatus: Codable {
            let code : String?
            let name : String?
        }
        
        struct PreferredLanguage: Codable {
            let code : String?
            let name : String?
        }
        
        struct Nationality: Codable {
            let code : String?
            let name : String?
        }
        
        struct MaritalStatus: Codable {
            let code : String?
            let name : String?
        }
        
        struct IsdCodePhoneNo: Codable {
            let code : String?
            let name : String?
        }
        
        struct IsdCode: Codable {
            let code : String?
            let name : String?
        }
        
        struct HouseholdType: Codable {
            let code : String?
            let name : String?
        }
        
        struct Gender: Codable {
            let code : String?
            let name : String?
        }
        
        func getFullName() -> String {
            var name = ""
            
            if self.customerType.code == Constants.CUSTOMER_TYPE_CORP {
                if let instName = self.institutionName {
                    name = instName
                }
            }
            else {
                if let fName = self.firstName {
                    name = fName
                }
                if let mName = self.middleName {
                    name = "\(name) \(mName)"
                }
                if let lName = self.lastName {
                    name = "\(name) \(lName)"
                }
            }
            
            return name.capitalized
        }
    }
    
    
    // Expense Model
    
    struct ExpenseModel: Codable {
        let expenseType : ExpenseType?
        let grossAmount : Double?
        let expenseFrequency : ExpenseFrequency?
        let externalFlag : Bool?
        let percentage : String?
        let expenseId : String?
        
        struct ExpenseType: Codable {
            let code : String?
            let name : String?
        }
        
        struct ExpenseFrequency: Codable {
            let code : String?
            let name : String?
        }
    }
    
    // Asset Model
    
    struct AssetModel: Codable {
        let incomeAssetCategory : IncomeAssetCategory?
        let incomeAssetType : IncomeAssetType?
        let incomeAssetValue : Double?
        let incomeAssetDescription : String?
        let assetId : String?
        
        struct IncomeAssetType: Codable {
            let code : String?
            let name : String?
        }
        
        struct IncomeAssetCategory: Codable {
            let code : String?
            let name : String?
        }
    }
    
    // Liability Model
    
    struct LiabilityModel: Codable {
        let liabilityType : LiabilityType?
        let frequencyForLiability : FrequencyForLiability?
        let externalProduct : ExternalProduct?
        let institution : Institution?
        let installmentAmount : Double?
        let balance : Double?
        let sanctionedAmount : Double?
        let otherLiabilityDescription : String?
        let bureauFlag : Bool?
        let closedDate : String?
        let emiStartDate : String?
        let loanTenure : Int?
        let liabilityId : String?
        
        struct ExternalProduct: Codable {
            let code : String?
            let name : String?
        }
        
        struct FrequencyForLiability: Codable {
            let code : String?
            let name : String?
        }
        
        struct Institution: Codable {
            let code : String?
            let name : String?
        }
        
        struct LiabilityType: Codable {
            let code : String?
            let name : String?
        }
    }
    
    // Collateral model
    
    struct CollateralModel : Codable {
        let collateralDetails : [CollateralDetail]?
        let collateralPresent : Bool?
        
        struct CollateralDetail : Codable {
            let collateralSubType : CollateralSubType?
            let isPropertyIdentified : Bool?
            let propertyType : PropertyType?
            let natureOfProperty : NatureOfProperty?
            let fundedFor : FundedFor?
            let propertyPurchasePrice : Double?
            let bodyCost : Double?
            let bodyCostAsPerGrid : Double?
            let bodyCostProposed : Double?
            let addressVO : AddressModel?
            let neutronCollateralId : String?
            let assetModelCategory : AssetModelCategory?
            let assetMake : AssetMake?
            let assetModel : AssetModel?
            let bodyType : BodyType?
            let bodyManuName : BodyManuName?
            let assetCost : Double?
            let assetVariant : AssetVariant?
            let assetType : AssetType?
            let dealer : Dealer?
            let engineNumber : String?
            let chassisNumber : String?
            let quantity : Int?
            let registrationNumber : String?
        }
        
        struct BodyType : Codable {
            let code : String?
            let name : String?
        }
        
        struct BodyManuName : Codable {
            let code : String?
            let name : String?
        }
        
        struct AssetModelCategory : Codable {
            let code : String?
            let name : String?
        }
        
        struct FundedFor : Codable {
            let code : String?
            let name : String?
        }
        
        struct AssetType : Codable {
            let code : String?
            let name : String?
        }
        
        struct AssetVariant : Codable {
            let code : String?
            let name : String?
        }
        
        struct AssetModel : Codable {
            let code : String?
            let name : String?
        }
        
        struct Dealer : Codable {
            let code : String?
            let name : String?
        }
        
        struct AssetMake : Codable {
            let code : String?
            let name : String?
        }
        
        struct City : Codable {
            let code : String?
            let name : String?
        }
        
        struct CollateralSubType : Codable {
            let code : String?
            let name : String?
        }
        
        struct Country : Codable {
            let code : String?
            let name : String?
        }
        
        struct NatureOfProperty : Codable {
            let code : String?
            let name : String?
        }
        
        struct PostalCode : Codable {
            let code : String?
            let name : String?
        }
        
        struct PropertyType : Codable {
            let code : String?
            let name : String?
        }
        
        struct State : Codable {
            let code : String?
            let name : String?
        }
    }
    
    // All detail about application
    struct ApplicationDetails: Codable {
        let applicants : [ApplicantModel]?
        let loanDetail : SourcingModel.LoanDetail?
        let collateralDetails : [CollateralModel.CollateralDetail]?
        let collateralPresent : Bool?
        let initialMoneyDeposits : [ProcessingFees]?
        
        struct ProcessingFees: Codable {
            
            let paymentModeType : PaymentModeType?
            let subPaymentModeType : SubPaymentModeType?
            let amount : Double?
            let remarks : String?
            let imdId : String?
            let receiptNumber : String?
            let instrumentNumber : String?
            let micrCode : String?
            let instrumentDate : String?
        }
    }
    
    // Reference model
    
    struct ReferenceDetails: Codable {
        let neutronReferenceId : String?
        let addressDetails : AddressModel?
        let name : String?
        let emailAddress : String?
        let phoneNumber : String?
        let isdCode : IsdCodeRef?
        let referenceRelationshipType : ReferenceRelationshipType?
        
        struct ReferenceRelationshipType : Codable {
            let code : String?
            let name : String?
        }
        
        struct IsdCodeRef: Codable {
            let code : String?
            let name : String?
        }
    }
    
    // Processing model
    
    struct ProcessingDetails : Codable {
        let neutronReferenceNumber : String?
        let initialMoneyDeposits : [InitialMoneyDeposits]?
        
        struct InitialMoneyDeposits : Codable {
            let subPaymentModeType : SubPaymentModeType?
            let receiptNumber : String?
            let imdId : String?
            let paymentModeType : PaymentModeType?
            let amount : Double?
            let remarks : String?
            let instrumentNumber : String?
            let micrCode : String?
            let instrumentDate : String?
        }
    }
}
