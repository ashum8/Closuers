//
//  SourcingLoanDetailVC.swift
//  mCAS
//
//  Created by iMac on 20/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class SourcingLoanDetailVC: UIViewController {
    
    @IBOutlet weak var branchLOV: LOVFieldView!
    @IBOutlet weak var productLOV: LOVFieldView!
    @IBOutlet weak var schemeLOV: LOVFieldView!
    @IBOutlet weak var loanPurposeLOV: LOVFieldView!
    @IBOutlet weak var loanPurposeLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var agentLOV: LOVFieldView!
    @IBOutlet weak var loanAmountTFView: CustomTextFieldView!
    @IBOutlet weak var tenureTFView: CustomTextFieldView!
    @IBOutlet weak var rateTFView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var installmentTitleLabel: UILabel!
    @IBOutlet weak var firstRadioButton: RadioButtonView!
    @IBOutlet weak var secondRadioButton: RadioButtonView!
    @IBOutlet weak var thirdRadioButton: RadioButtonView!
    @IBOutlet weak var fourthRadioButton: RadioButtonView!
    @IBOutlet weak var dayOfMonthView: UIView!
    @IBOutlet weak var dueDateTitleLabel: UILabel!
    @IBOutlet weak var dayOfMonthViewHeight: NSLayoutConstraint!
    @IBOutlet weak var dayOfMonthButton: UIButton!
    @IBOutlet weak var noOfAdvanceEMIView: CustomTextFieldView!
    @IBOutlet weak var noOfAdvanceEmiViewHeight: NSLayoutConstraint!
    
    private let TAG_BRANCH          = 1000
    private let TAG_PRODUCT         = 1001
    private let TAG_SCHEME          = 1002
    private let TAG_LOAN_PURPOSE    = 1003
    private let TAG_SALES_AGENT     = 1004
    private let TAG_AMOUNT          = 10000
    private let TAG_TENURE          = 10001
    private let TAG_ROI             = 10002
    private let TAG_ADVANCE_EMI     = 10003
    
    
    private enum RadioBtnOption: String, CaseIterable {
        case First = "5"
        case Second = "10"
        case Third = "15"
        case Other = "Others"
    }
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var dueDatePopView: MonthView!
    private var selectedDueDay: String!
    
    private var isEditMode = true
    private var applicationType: DropDown!
    private var productCategory: LoanType!
    private var applicationID: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        branchLOV.setLOVProperties(masterName: Entity.BRANCH, title: "Branch", tag: TAG_BRANCH, delegate: self)
        productLOV.setLOVProperties(masterName: Entity.PRODUCT, title: "Product", tag: TAG_PRODUCT, delegate: self, parentKey: self.productCategory.code)
        schemeLOV.setLOVProperties(masterName: Entity.SCHEME, title: "Scheme", tag: TAG_SCHEME, delegate: self)
        loanPurposeLOV.setLOVProperties(masterName: Entity.LOAN_PURPOSE, title: "Loan Purpose", tag: TAG_LOAN_PURPOSE, delegate: self, parentKey: self.productCategory.code)
        agentLOV.setLOVProperties(masterName: Entity.SALES_AGENT, title: "Sales Agent", tag: TAG_SALES_AGENT, delegate: self)
        
        loanAmountTFView.setProperties(placeHolder: "Loan Amount Requested", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        tenureTFView.setProperties(placeHolder: "Tenure", type: .Number, delegate: self, unitText: "Month", tag: TAG_TENURE)
        rateTFView.setProperties(placeHolder: "Rate of interest", type: .Decimal, delegate: self, unitText: "%", tag: TAG_ROI)
        noOfAdvanceEMIView.setProperties(placeHolder: "No. of Advance EMI (Optional)", type: .Number, delegate: self, tag: TAG_ADVANCE_EMI)
        
        buttonView.setProperties(nextBtnTitle: "Save Details", delegate: self)
        dayOfMonthButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        installmentTitleLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        
        firstRadioButton.setProperties(title: SourcingCommonUtil.shared().getFormattedDay(day: RadioBtnOption.First.rawValue), delegate: self)
        secondRadioButton.setProperties(title: SourcingCommonUtil.shared().getFormattedDay(day: RadioBtnOption.Second.rawValue), delegate: self)
        thirdRadioButton.setProperties(title: SourcingCommonUtil.shared().getFormattedDay(day: RadioBtnOption.Third.rawValue), delegate: self)
        fourthRadioButton.setProperties(title: "\(RadioBtnOption.Other.rawValue)", delegate: self)
        
        selectedDueDay = ""
        dayOfMonthView.layer.masksToBounds = true
        dayOfMonthView.setMainViewProperties()
        
        if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CL.lowercased() {
            loanPurposeLOVHeight.constant = 0
            noOfAdvanceEmiViewHeight.constant = 65
        }
        
        validateFields()
        
        if self.isEditMode {
            getLoanDetail()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            let navArray = AppDelegate.instance.applicationNavController.viewControllers
            let lastVC = navArray[navArray.count-2]
            headerView.showHideStepHeader(isHide: false, title: "Loan Details", landingPage: lastVC)
            bottomView.isHidden = true
        }
    }
    
    func setData(productCategory: LoanType, applicationType: DropDown, applicationID: String, isEditMode: Bool) {
        self.isEditMode = isEditMode
        self.productCategory = productCategory
        self.applicationType = applicationType
        self.applicationID = applicationID
    }
    
    private func resetAllRadioButton() {
        firstRadioButton.setButtonState(isSelected: false)
        secondRadioButton.setButtonState(isSelected: false)
        thirdRadioButton.setButtonState(isSelected: false)
        fourthRadioButton.setButtonState(isSelected: false)
    }
    
    private func showHideDueDayButton(show: Bool) {
        if show, !selectedDueDay.isEmpty {
            dayOfMonthButton.setTitle(SourcingCommonUtil.shared().getFormattedDay(day: selectedDueDay), for: .normal)
            fourthRadioButton.radioButton.isSelected = true
            dayOfMonthViewHeight.constant = 50
        }
        else {
            dayOfMonthViewHeight.constant = 0
        }
        
        validateFields()
    }
    
    @IBAction func dueDatesButtonAction(_ sender: Any) {
        
        if self.dueDatePopView == nil {
            self.dueDatePopView = .fromNib()
            self.dueDatePopView.setProperties(width: self.view.frame.size.width, height: self.view.frame.size.height, delegate: self, removeOptionsArr: RadioBtnOption.allCases.map { $0.rawValue })
            self.view.addSubview(self.dueDatePopView)
        }
        
        self.dueDatePopView.selectedDay = selectedDueDay
        self.dueDatePopView.collectionView.reloadData()
        self.dueDatePopView.alpha = 1
    }
    
    private func getLoanDetail() {
        
        let param = ["neutronReferenceNumber": self.applicationID]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_LOAN_DETAIL_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let loanObj = response["loanDetail"] as? [String : Any] {
                
                CommonUtils.shared().JSONtoModel(jsonObject: loanObj, type: SourcingModelClasses.SourcingModel.LoanDetail.self) { data in
                    self.fillDataInEditMode(loanData: data)
                }
            }
            
        }, failure: { (error) in },
           noNetwork: { (error) in })
    }
    
    private func fillDataInEditMode(loanData: SourcingModelClasses.SourcingModel.LoanDetail?) {
        if let loanData = loanData {
            self.branchLOV.autoFillLOVBy(key: loanData.branch?.code)
            self.productLOV.autoFillLOVBy(key: loanData.product?.code)
            self.schemeLOV.autoFillLOVBy(key: loanData.scheme?.code)
            self.agentLOV.autoFillLOVBy(key: loanData.rmOfficer?.code)
            
            if let amount = loanData.loanAmount {
                self.loanAmountTFView.setFieldValue(text: "\(amount)")
            }
            if let tenure = loanData.tenure {
                self.tenureTFView.setFieldValue(text: "\(tenure)")
            }
            if let roi = loanData.rateOfInterest {
                self.rateTFView.setFieldValue(text: "\(roi)")
            }
            if let dueDay = loanData.dueDay {
                selectedDueDay = "\(dueDay)"
                
                if RadioBtnOption.First.rawValue == selectedDueDay {
                    self.selectedRadioButton(view: firstRadioButton)
                }
                else if RadioBtnOption.Second.rawValue == selectedDueDay {
                    self.selectedRadioButton(view: secondRadioButton)
                }
                else if RadioBtnOption.Third.rawValue == selectedDueDay {
                    self.selectedRadioButton(view: thirdRadioButton)
                }
                else {
                    self.showHideDueDayButton(show: true)
                }
            }
            if self.productCategory.code == ConstantCodes.PRODUCT_TYPE_CL {
                if let noOfEmi = loanData.noOfAdvanceEmi {
                    self.noOfAdvanceEMIView.setFieldValue(text: "\(noOfEmi)")
                }
            }
            else {
                self.loanPurposeLOV.autoFillLOVBy(key: loanData.loanPurpose?.code)
            }
            
            validateFields()
        }
    }
}

extension SourcingLoanDetailVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_PRODUCT {
            if let dd = selectedLOVDic["\(TAG_PRODUCT)"] {
                schemeLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_SCHEME)"] = nil
            }
        }
        
        validateFields()
    }
}

extension SourcingLoanDetailVC: CustomTFViewDelegate {
    func validateFields() {
        
        var isEnabled = true
        
        if (selectedLOVDic["\(TAG_BRANCH)"] == nil || selectedLOVDic["\(TAG_PRODUCT)"] == nil || selectedLOVDic["\(TAG_SCHEME)"] == nil || (self.productCategory.code != ConstantCodes.PRODUCT_TYPE_CL && selectedLOVDic["\(TAG_LOAN_PURPOSE)"] == nil) || selectedLOVDic["\(TAG_SALES_AGENT)"] == nil || loanAmountTFView.getFieldValue().isEmpty || tenureTFView.getFieldValue().isEmpty || rateTFView.getFieldValue().isEmpty || selectedDueDay.isEmpty)
        {
            isEnabled = false
        }
        else if let amount = Float(loanAmountTFView.getFieldValue()), let tenure = Float(tenureTFView.getFieldValue()), let rate = Float(rateTFView.getFieldValue()), (amount < 1.0 || tenure < 1.0 || rate < 1.0) {
            isEnabled = false
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            let amount = Double(text) ?? 0
            return amount <= SourcingCommonUtil.shared().maxAmount && amount > 0

        case TAG_ROI:
            let rate = Double(text) ?? 0
            return rate <= SourcingCommonUtil.shared().maxLimitRate && rate > 0

        case TAG_TENURE:
            let tenure = Int(text) ?? 0
            return tenure <= SourcingCommonUtil.shared().maxLimitTenure && tenure > 0

        case TAG_ADVANCE_EMI:
            return text.count <= 3

        default:
            return true
        }
    }
}

extension SourcingLoanDetailVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        
        var noOfEmi = ""
        if self.productCategory.code.lowercased() == ConstantCodes.PRODUCT_TYPE_CL.lowercased() {
            noOfEmi = noOfAdvanceEMIView.getFieldValue()
        }
        
        let param: [String : Any] = ["neutronReferenceNumber": self.applicationID ?? "",
                                     
                                     "loanDetail": ["tenure": tenureTFView.getFieldValue(),
                                                    
                                                    "dueDay": selectedDueDay ?? "",
                                                    
                                                    "rateOfInterest": rateTFView.getFieldValue(),
                                                    
                                                    "loanAmount": loanAmountTFView.getFieldValue(),
                                                    
                                                    "noOfAdvanceEmi": noOfEmi,
                                                    
                                                    "branch": ["code": selectedLOVDic["\(TAG_BRANCH)"]?.code,
                                                               "name": selectedLOVDic["\(TAG_BRANCH)"]?.name],
                                                    
                                                    "product": ["code": selectedLOVDic["\(TAG_PRODUCT)"]?.code,
                                                                "name": selectedLOVDic["\(TAG_PRODUCT)"]?.name],
                                                    
                                                    "applicationType": ["code": applicationType.code,
                                                                        "name": applicationType.name],
                                                    
                                                    "productType": ["code": productCategory.code,
                                                                    "name": productCategory.name],
                                                    
                                                    "scheme": ["code": selectedLOVDic["\(TAG_SCHEME)"]?.code,
                                                               "name": selectedLOVDic["\(TAG_SCHEME)"]?.name],
                                                    
                                                    "loanPurpose": ["code": selectedLOVDic["\(TAG_LOAN_PURPOSE)"]?.code,
                                                                    "name": selectedLOVDic["\(TAG_LOAN_PURPOSE)"]?.name],
                                                    
                                                    "rmOfficer": ["code": selectedLOVDic["\(TAG_SALES_AGENT)"]?.code,
                                                                  "name": selectedLOVDic["\(TAG_SALES_AGENT)"]?.name]]]
        
        
        Webservices.shared().POST(urlString: ServiceUrl.SAVE_LOAN_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                CommonAlert.shared().showAlert(message: "Loan detail saved successfully", okAction: { _ in
                    
                    let viewContrlls = AppDelegate.instance.applicationNavController.viewControllers.reversed()
                    
                    for vc in viewContrlls {
                        if vc.isKind(of: SourcingDashboardVC.self), let obj = vc as? SourcingDashboardVC
                        {
                            obj.updateEditMode(branchCode: self.selectedLOVDic["\(self.TAG_BRANCH)"]!.code, productCode: self.selectedLOVDic["\(self.TAG_PRODUCT)"]!.code)
                        }
                        else if vc.isKind(of: SourcingListVC.self), let obj = vc as? SourcingListVC {
                            obj.fetchCases(showLoader: false)
                            break
                        }
                    }
                    
                    self.navigationController?.popViewController(animated: true)
                })
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
}


extension SourcingLoanDetailVC: RadioButtonDelegate {
    
    func selectedRadioButton(view: RadioButtonView) {
        resetAllRadioButton()
        
        switch view {
            
        case firstRadioButton:
            firstRadioButton.radioButton.isSelected = true
            selectedDueDay = RadioBtnOption.First.rawValue
            showHideDueDayButton(show: false)
            
        case secondRadioButton:
            secondRadioButton.radioButton.isSelected = true
            selectedDueDay = RadioBtnOption.Second.rawValue
            showHideDueDayButton(show: false)
            
        case thirdRadioButton:
            thirdRadioButton.radioButton.isSelected = true
            selectedDueDay = RadioBtnOption.Third.rawValue
            showHideDueDayButton(show: false)
            
        case fourthRadioButton:
            dayOfMonthButton.sendActions(for: .touchUpInside)
            
        default:
            debugPrint("case not matched")
        }
    }
}

extension SourcingLoanDetailVC: MonthViewDelegate {
    func setSelectedDay(day: String) {
        selectedDueDay = day
        showHideDueDayButton(show: true)
    }
}
