//
//  AddReferenceDetailVC.swift
//  mCAS
//
//  Created by iMac on 17/03/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddReferenceDetailVC: UIViewController {
    
    @IBOutlet weak var nameTextView: CustomTextFieldView!
    @IBOutlet weak var relationShipLOV: LOVFieldView!
    @IBOutlet weak var mobileNumberView: CustomMobileNumberView!
    @IBOutlet weak var emailView: CustomTextFieldView!
    @IBOutlet weak var addressTypeLOV: LOVFieldView!
    @IBOutlet weak var residenceStatusLOV: LOVFieldView!
    @IBOutlet weak var residenceStatusLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var residenceTypeLOV: LOVFieldView!
    @IBOutlet weak var addressL1View: CustomTextFieldView!
    @IBOutlet weak var residenceTypeLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var addressL2View: CustomTextFieldView!
    @IBOutlet weak var addressL3View: CustomTextFieldView!
    @IBOutlet weak var landmarkView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var searchByPincodeView: CustomSearchByPincodeView!
    
    private let TAG_ADDRESS             = 1000
    private let TAG_RELATION            = 1001
    private let TAG_COUNTRY_CODE_MOBILE = 1002
    private let TAG_RESIDENCE           = 1003
    private let TAG_RESIDENCE_TYPE      = 1004
    
    private let TAG_ADDRESS_LANDMARK    = 1005
    private let TAG_NAME                = 1006
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var applicationID: String!
    private var dataObj: SourcingModelClasses.ReferenceDetails?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    private func setupView() {
        
        relationShipLOV.setLOVProperties(masterName: Entity.REF_RELATIONSHIP, title: "Relationship", tag: TAG_RELATION, delegate: self)
        addressTypeLOV.setLOVProperties(masterName: Entity.ADDTYPE, title: "Address Type", tag: TAG_ADDRESS, delegate: self)
        residenceStatusLOV.setLOVProperties(masterName: Entity.RESTYP, title: "Residence Status", tag: TAG_RESIDENCE, delegate: self)
        residenceTypeLOV.setLOVProperties(masterName: Entity.RESIDENCETYPE, title: "Residence Type", tag: TAG_RESIDENCE_TYPE, delegate: self)
        
        nameTextView.setProperties(placeHolder: "Name", delegate: self, tag: TAG_NAME)
        emailView.setProperties(placeHolder: "Email Id", type: .Email, delegate: self)
        mobileNumberView.setProperties(tag: TAG_COUNTRY_CODE_MOBILE, lovDelegate: self, tfDelegate: self)

        addressL1View.setProperties(placeHolder: "Address Line 1", delegate: self, tag: TAG_ADDRESS_LANDMARK)
        addressL2View.setProperties(placeHolder: "Address Line 2", delegate: self, tag: TAG_ADDRESS_LANDMARK)
        addressL3View.setProperties(placeHolder: "Address Line 3", delegate: self, tag: TAG_ADDRESS_LANDMARK)
        landmarkView.setProperties(placeHolder: "Landmark", delegate: self, tag: TAG_ADDRESS_LANDMARK)
        searchByPincodeView.setProperties(delegate: self)
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        fillDataInEditMode(dataObj: dataObj)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Reference")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader()
        }
    }
    
    func setData(applicationID: String, dataObj: SourcingModelClasses.ReferenceDetails? = nil) {
        self.applicationID = applicationID
        self.dataObj = dataObj
    }
    
    private func fillDataInEditMode(dataObj: SourcingModelClasses.ReferenceDetails?) {
        if let data = dataObj {
            
            nameTextView.setFieldValue(text: data.name)
            relationShipLOV.autoFillLOVBy(key: data.referenceRelationshipType?.code)
            mobileNumberView.setAutoFillMobileNumber(countryKey: data.isdCode?.code, mobileNumber: CommonUtils.shared().getValidatedString(string: data.phoneNumber))
            emailView.setFieldValue(text: data.emailAddress)
            addressTypeLOV.autoFillLOVBy(key: data.addressDetails?.addressType?.code)
            addressL1View.setFieldValue(text: data.addressDetails?.unit)
            addressL2View.setFieldValue(text: data.addressDetails?.streetNo)
            addressL3View.setFieldValue(text: data.addressDetails?.streetName)
            landmarkView.setFieldValue(text: data.addressDetails?.landmark)
            searchByPincodeView.setAutoFillValues(countryKey: data.addressDetails?.country?.code, stateKey: data.addressDetails?.state?.code, cityKey: data.addressDetails?.city?.code, pincode: CommonUtils.shared().getValidatedString(string:data.addressDetails?.postalCode?.code))
            
            buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Update", delegate: self)
        }
	
        validateFields()
    }
    
    private func refreshFieldData() {
        residenceTypeLOV.resetLOVWithParentKey()
        residenceStatusLOV.resetLOVWithParentKey()
        addressL1View.setFieldValue()
        addressL2View.setFieldValue()
        addressL3View.setFieldValue()
        landmarkView.setFieldValue()
    }
    
}

extension AddReferenceDetailVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        if (selectedLOVDic["\(TAG_ADDRESS)"] == nil || selectedLOVDic["\(TAG_COUNTRY_CODE_MOBILE)"] == nil || !mobileNumberView.mobileNoTFView.getFieldValue().isValidPhone || !emailView.getFieldValue().isValidEmail || addressL1View.getFieldValue().isEmpty || addressL2View.getFieldValue().isEmpty || addressL3View.getFieldValue().isEmpty || landmarkView.getFieldValue().isEmpty) {
            
            isEnabled = false
        }
        
        if selectedLOVDic["\(TAG_ADDRESS)"]?.code.lowercased() == ConstantCodes.ADDRESS_TYPE_PERM.lowercased() || selectedLOVDic["\(TAG_ADDRESS)"]?.code.lowercased() == ConstantCodes.ADDRESS_TYPE_RES.lowercased() {
           
            isEnabled = isEnabled && !(selectedLOVDic["\(TAG_RESIDENCE)"] == nil || selectedLOVDic["\(TAG_RESIDENCE_TYPE)"] == nil)
        }
        
        isEnabled = isEnabled && searchByPincodeView.validateCSBPFields()
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_ADDRESS_LANDMARK:
            return text.validateStringWithRegex(regx: "^[A-Z-a-z0-9,.() #@$*%-_\\/:?]{1,40}$")
        
        case TAG_NAME:
            return text.isAlphabeticAndSpace && text.count < 30
        default:
            return true
        }
    }
}

extension AddReferenceDetailVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_ADDRESS {
            refreshFieldData()
            if selectedObj.code.lowercased() == ConstantCodes.ADDRESS_TYPE_PERM.lowercased() || selectedObj.code.lowercased() == ConstantCodes.ADDRESS_TYPE_RES.lowercased() {
                residenceTypeLOVHeight.constant = 65
                residenceStatusLOVHeight.constant = 65
            }
            else {
                residenceTypeLOVHeight.constant = 0
                residenceStatusLOVHeight.constant = 0
            }
        }
        validateFields()
    }
}

extension AddReferenceDetailVC: NextBackButtonDelegate {
    func nextButtonAction() {

        var referenceID = ""
        if let dataObj = dataObj {
            referenceID = dataObj.neutronReferenceId!
        }
        else {
            referenceID = SourcingCommonUtil.shared().generateApplicationID()
        }
        
        var addressParam: [String: Any] = [:]
        addressParam["unit"]        = addressL1View.getFieldValue()
        addressParam["streetNo"]    = addressL2View.getFieldValue()
        addressParam["streetName"]  = addressL3View.getFieldValue()
        addressParam["landmark"]    = landmarkView.getFieldValue()
        addressParam["country"]     = ["code"   :   searchByPincodeView.getSelectedCountry().0,
                                       "name"   :   searchByPincodeView.getSelectedCountry().1]
        addressParam["state"]       = ["code"   :   searchByPincodeView.getSelectedState().0,
                                       "name"   :   searchByPincodeView.getSelectedState().1]
        addressParam["city"]        = ["code"   :   searchByPincodeView.getSelectedCity().0,
                                       "name"   :   searchByPincodeView.getSelectedCity().1]
        addressParam["postalCode"]  = ["code"   :   searchByPincodeView.getSelectedPincode().0,
                                       "name"   :   searchByPincodeView.getSelectedPincode().1]
        addressParam["addressType"] = ["code"   :   selectedLOVDic["\(TAG_ADDRESS)"]?.code,
                                       "name"   :   selectedLOVDic["\(TAG_ADDRESS)"]?.name]
        
        if selectedLOVDic["\(TAG_ADDRESS)"]?.code.lowercased() == ConstantCodes.ADDRESS_TYPE_PERM.lowercased() || selectedLOVDic["\(TAG_ADDRESS)"]?.code.lowercased() == ConstantCodes.ADDRESS_TYPE_RES.lowercased() {
            
            addressParam["residenceType"]       = ["code"   :   selectedLOVDic["\(TAG_RESIDENCE_TYPE)"]?.code,
                                                   "name"   :   selectedLOVDic["\(TAG_RESIDENCE_TYPE)"]?.name]
            addressParam["residentialStatus"]   = ["code"   :   selectedLOVDic["\(TAG_RESIDENCE)"]?.code,
                                                   "name"   :   selectedLOVDic["\(TAG_RESIDENCE)"]?.name]
            
        }
        
        
        let param: [String : Any] = ["neutronReferenceNumber"       : CommonUtils.shared().getValidatedString(string: self.applicationID),
                                     "neutronReferenceId"           : referenceID,
                                     "addressDetails"               : addressParam,
                                     "emailAddress"                 : emailView.getFieldValue(),
                                     "name"                         : nameTextView.getFieldValue(),
                                     "phoneNumber"                  : mobileNumberView.mobileNoTFView.getFieldValue(),
                                     "isdCode"                      : ["code"   :   selectedLOVDic["\(TAG_COUNTRY_CODE_MOBILE)"]?.code,
                                                                       "name"   :   selectedLOVDic["\(TAG_COUNTRY_CODE_MOBILE)"]?.name],
                                     "referenceRelationshipType"    : ["code"   :   selectedLOVDic["\(TAG_RELATION)"]?.code,
                                                                       "name"   :   selectedLOVDic["\(TAG_RELATION)"]?.name]]

        Webservices.shared().POST(urlString: ServiceUrl.SUBMIT_REFERENCE_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true {
                
                if let obj = AppDelegate.instance.getSpecificVC(targetClass: ReferenceDetailListVC.self) as? ReferenceDetailListVC {
                    obj.fetchList()
                }
                self.navigationController?.popViewController(animated: true)
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
        
        
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension AddReferenceDetailVC: CSByPincodeDelegate {
    func CSBPValidation() {
        validateFields()
    }
}
