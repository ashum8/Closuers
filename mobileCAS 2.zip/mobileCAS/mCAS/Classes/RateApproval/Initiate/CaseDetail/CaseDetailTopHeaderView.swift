//
//  CaseDetailTopHeaderView.swift
//  mCAS
//
//  Created by Mac on 08/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation


class CaseDetailTopHeaderView: UIView {
    @IBOutlet weak var headerLabel: UILabel!
    @IBOutlet weak var wirrLabel: UILabel!
    @IBOutlet weak var wirrPercentLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var applicableLabel: UILabel!
    @IBOutlet weak var requestedLabel: UILabel!
    @IBOutlet weak var wirrTF: UITextField!
    @IBOutlet weak var crossSellLabel: UILabel!
    
    func setProperties() {
        wirrTF.delegate = self
        
        headerLabel.font = CustomFont.shared().GETFONT_MEDIUM(14)
        wirrLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        wirrPercentLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        typeLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        applicableLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        requestedLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        wirrTF.font = CustomFont.shared().GETFONT_REGULAR(14)
        crossSellLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        
        typeLabel.textColor = .gray
        applicableLabel.textColor = .gray
        requestedLabel.textColor = .gray
        crossSellLabel.textColor = .gray
    }
}

extension CaseDetailTopHeaderView: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField.disableDoubleSpacePeriodIssue(shouldChangeCharactersRange: range, replacementString: string) == false {
            return false
        }
        
        if let text = textField.text, let textRange = Range(range, in: text), !string.isEmpty {
            let updatedText = text.replacingCharacters(in: textRange, with: string)
            
            let split = updatedText.components(separatedBy: ".")
            let first = split[0]
            
            if first.count > 3 {
                return false
            }
            
            if let value = Float(updatedText) {
                return updatedText.validateAmountString &&  (value.isLessThanOrEqualTo(100.0))
            }
        }
        
        return true
    }
}
