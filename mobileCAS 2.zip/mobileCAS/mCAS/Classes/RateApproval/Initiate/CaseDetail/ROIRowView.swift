//
//  ROIRowView.swift
//  mCAS
//
//  Created by Mac on 08/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

class ROIRowView: UIView {
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var applicableLabel: UILabel!
    @IBOutlet weak var requestedTF: UITextField!
    @IBOutlet weak var percentLabel: UILabel!
    @IBOutlet weak var waiveLabel: UILabel!
    @IBOutlet weak var checkButton: UIButton!
    
    var unit = ""
    var waiverValue: Double = 0.0
    var initialValue: Double = 0.0
    
    func setProperties() {
        requestedTF.delegate = self
        typeLabel.font = CustomFont.shared().GETFONT_MEDIUM(14)
        applicableLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        requestedTF.font = CustomFont.shared().GETFONT_REGULAR(14)
        percentLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        waiveLabel.font = CustomFont.shared().GETFONT_REGULAR(13)
    }
    
    func setRateData(item: RAModelClasses.Rate) -> CGFloat {
        typeLabel.text = item.type?.code
        updateRowHeight(row: self, label: typeLabel)
        
        unit = "%"
        
        if let initial = item.initialRate, let proposed = item.proposedRate {
            
            initialValue = initial
            
            applicableLabel.text = String(format: "%.2f", initialValue) + unit
            requestedTF.text = String(format: "%.2f", proposed)
            percentLabel.text = unit
            
            setWaiverLabel(proposed: proposed)
        }
        
        checkButton.isHidden = true
        
        return frame.size.height
    }
    
    func setChargeData(item: RAModelClasses.Charge, crossSellFlags: String) -> CGFloat {
        if let name = item.chargeDetails?.name, let id = item.chargeDetails?.id {
            typeLabel.text = name
            self.updateRowHeight(row: self, label: typeLabel)
            
            if crossSellFlags.contains("\(id)") {
                checkButton.isSelected = true
            }
        }
        
        var proposed = 0.0
        
        if let initial = item.initialValue {
            initialValue = initial
        }
        
        if let proposedValue = item.proposedValue {
            proposed = proposedValue
        }
        else {
            if let waiver = item.waiverValue {
                proposed = initialValue - waiver
            }
            else {
                proposed = initialValue
            }
        }
        
        if let code = item.unitType?.code, code.uppercased() == "RATE" {
            unit = "%"
            
            applicableLabel.text = String(format: "%.2f", initialValue) + unit
        }
        else {
            unit = Constants.CURRENCY_SYMBOL
            
            applicableLabel.text = unit + String(format: "%.2f", initialValue)
        }
        
        setWaiverLabel(proposed: proposed)
        
        percentLabel.text = unit
        requestedTF.text = String(format: "%.2f", proposed)
        
        return frame.size.height
    }
    
    private func updateRowHeight(row: ROIRowView, label: UILabel) {
        var frame = self.frame
        
        let height = NSString(string: label.text!).boundingRect(
            with: CGSize(width: label.frame.size.width, height: .greatestFiniteMagnitude),
            options: .usesLineFragmentOrigin,
            attributes: [.font: label.font as Any],
            context: nil).size.height
        
        frame.size.height = max(40, height + 10)
        
        self.frame = frame
        label.center = center
    }
    
    private func setWaiverLabel(proposed: Double) {
        
        waiverValue = initialValue - proposed
        
        if unit == Constants.CURRENCY_SYMBOL {
            waiveLabel.text = unit + String(format: "%.2f", waiverValue)
        }
        else {
            waiveLabel.text = String(format: "%.2f", waiverValue) + unit
        }
        
        if waiverValue < 0  { waiveLabel.textColor = Color.GREEN }
        else                { waiveLabel.textColor = Color.RED }
    }
    
    @IBAction func checkButtonAction(_ sender: Any) {
        checkButton.isSelected = !checkButton.isSelected
    }
}

extension ROIRowView: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField.disableDoubleSpacePeriodIssue(shouldChangeCharactersRange: range, replacementString: string) == false {
            return false
        }
        
        if let text = textField.text, let textRange = Range(range, in: text), !string.isEmpty {
            let updatedText = text.replacingCharacters(in: textRange, with: string)
            
            var maxValue: Float = 0.0
            
            if unit == Constants.CURRENCY_SYMBOL {
                maxValue = 1000000.0
            }
            else {
                let split = updatedText.components(separatedBy: ".")
                let first = split[0]
                
                if first.count > 3 {
                    return false
                }
                maxValue = 100.0
            }
            
            if let value = Float(updatedText) {
                return updatedText.validateAmountString && (value.isLessThanOrEqualTo(maxValue))
            }
        }
        
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        if let text = textField.text, let value = Double(text) {
            textField.text = String(format: "%.2f", value)
        }
        else {
            textField.text = "0.00"
        }
        
        if let text = textField.text, let proposed = Double(text) {
            setWaiverLabel(proposed: proposed)
        }
        
        return true
    }
}
