//
//  BaseListVC.swift
//  mCAS
//
//  Created by Mac on 23/08/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

enum CASETYPE: String {
    case Initiated  = "Initiated"
    case Approved   = "Approved"
    case Rejected   = "Rejected"
    case Cancelled  = "Cancelled"
    case Approval   = "Approval"
    case ToInitiate = "Initiate"
    case ToApprove  = "Approve"
    case ToReject   = "Reject"
    case ToForward  = "Forward"
}

class BaseListVC: UIViewController {
    
    @IBOutlet weak var swipeMenuView: SwipeMenuView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var swipeMenuTopMarginConstraint: NSLayoutConstraint!
    
    private var caseTypes: [CASETYPE] = [.Initiated, .Approved, .Rejected, .Cancelled]
    
    var currentIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        caseTypes.forEach { data in
            let st = UIStoryboard.init(name: Storyboard.RATE_APPROVAL, bundle: nil)
            let vc = st.instantiateViewController(withIdentifier: "CaseListVC") as! CaseListVC
            vc.caseType = data
            self.addChild(vc)
        }
        
        var options: SwipeMenuViewOptions = .init()
        options.tabView.itemView.selectedTextColor = .white
        options.tabView.itemView.textColor = Color.LIGHTER_BLUE
        options.tabView.itemView.margin = 15.0
        options.tabView.itemView.font = CustomFont.shared().GETFONT_MEDIUM(18)
        options.tabView.additionView.backgroundColor = .white
        
        swipeMenuView.delegate = self
        swipeMenuView.dataSource = self
        swipeMenuView.reloadData(options: options)
        swipeMenuView.backgroundColor = Color.BLUE
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "Rate Approval", showBack: true, delegate: self)
            headerView.showHideSearchMikeFilterOption(showSearch: true)
            searchOnOff(isSearching: false)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideSearchMikeFilterOption()
        }
    }
    
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        
        let st = UIStoryboard.init(name: Storyboard.ONLINE_SEARCH, bundle: nil)
        let vc = st.instantiateInitialViewController() as! OnlineSearchVC
        vc.searchType = .RateApproval
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
}

extension BaseListVC: SwipeMenuViewDelegate {
    func swipeMenuView(_ swipeMenuView: SwipeMenuView, viewWillSetupAt currentIndex: Int) {
        //called for first time only
        
        self.currentIndex = currentIndex
        let vc = children[currentIndex] as! CaseListVC
        vc.fetchCases()
    }
    
    func swipeMenuView(_ swipeMenuView: SwipeMenuView, willChangeIndexFrom fromIndex: Int, to toIndex: Int) {
        
        self.currentIndex = toIndex
        let vc = children[toIndex] as! CaseListVC
        if !vc.isServiceCalled {
            vc.fetchCases()
        }
    }
}

extension BaseListVC: SwipeMenuViewDataSource {
    // MARK - SwipeMenuViewDataSource
    
    func numberOfPages(in swipeMenuView: SwipeMenuView) -> Int {
        return children.count
    }
    
    func swipeMenuView(_ swipeMenuView: SwipeMenuView, titleForPageAt index: Int) -> String {
        return children[index].title ?? ""
    }
    
    func swipeMenuView(_ swipeMenuView: SwipeMenuView, viewControllerForPageAt index: Int) -> UIViewController {
        let vc = children[index]
        vc.didMove(toParent: self)
        return vc
    }
}

extension BaseListVC: HeaderDelegate {
    
    func searchOnOff(isSearching: Bool) {
        
        let vc = children[currentIndex] as! CaseListVC
        
        swipeMenuTopMarginConstraint.constant = isSearching ? 0 : 45
        swipeMenuView.contentScrollView?.isScrollEnabled = !isSearching
        
        if isSearching {
            vc.refreshControl.removeFromSuperview()
        }
        else {
            vc.handleSearch(searchTxt: "")
            vc.tableView.addSubview(vc.refreshControl)
        }
    }
    
    func handleSearch(text: String) {
        let vc = children[currentIndex] as! CaseListVC
        vc.handleSearch(searchTxt: text)
    }
    
}
