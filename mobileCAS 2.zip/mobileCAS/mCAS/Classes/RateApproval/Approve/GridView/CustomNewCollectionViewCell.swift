//
//  GridCollectionCell.swift
//  CollectionViewCustom
//
//  Created by iMac on 20/11/19.
//

import UIKit

class GridCollectionCell: UICollectionViewCell {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var lblRequestedRate: UILabel!
    @IBOutlet weak var btnLoanType: UIButton!
    @IBOutlet weak var vw1: UIView!
    @IBOutlet weak var vw2: UIView!
    @IBOutlet weak var vw3: UIView!
    
    @IBOutlet weak var lblLoanAmtName: UILabel!
    @IBOutlet weak var lblChangesCode: UILabel!
    @IBOutlet weak var lblCurrentRate: UILabel!
    @IBOutlet weak var topBgView: UIView!
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    var rateCharges: [RAModelClasses.Rate]?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.backgroundColor = Color.LIGHTER_GRAY
        self.tableView.register(UINib(nibName:  String(describing: InterestRateTableViewCell.self), bundle: Bundle.main), forCellReuseIdentifier: "InterestRateTableViewCell")
    }
    
    func setProperties() {
        
        lblLoanAmtName.textColor = .darkGray
        vw1.backgroundColor = Color.LIGHTER_GRAY
        vw2.backgroundColor = Color.LIGHTER_GRAY
        
        titleLabel.font = CustomFont.shared().GETFONT_MEDIUM(18)
        lblLoanAmtName.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        btnLoanType.layer.cornerRadius = 23
        btnLoanType.layer.borderWidth = 1
        btnLoanType.layer.borderColor = UIColor.gray.cgColor
        
        topBgView.backgroundColor = Color.LIGHTER_GRAY
        bgView.setCornerRadius()
        bgView.setShadow()
        self.tableView.tableFooterView = UIView()
    }
    
    func setData(item: RAModelClasses.RateApprovalRecord) {
        lblLoanAmtName.text = "\(item.loanAmount!) \(Constants.SEPERATOR) \(item.application.applicant.fullName.uppercased())"
        titleLabel.text = item.application.externalRefNumber
        
        if var rateArray = item.rates, !rateArray.isEmpty  {
            if let chargesArray = item.charges, !chargesArray.isEmpty  {
                for itemCharges in chargesArray {
                    if let inititalRate = itemCharges.initialValue, let code = itemCharges.unitType?.code, let proposedRate = itemCharges.proposedValue {
                        let obj = RAModelClasses.Rate(type: RAModelClasses.RType(code: code), initialRate: inititalRate, proposedRate: proposedRate, approvedRate: 0.00, waiverRate: 0.00)
                        rateArray.append(obj)
                    }
                }
            }
            rateCharges = rateArray
            tableView.reloadData()
        }
    }
    
}

extension GridCollectionCell: UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rateCharges?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "InterestRateTableViewCell", for: indexPath) as! InterestRateTableViewCell
        
        if let obj = rateCharges?[indexPath.row]  {
            cell.setupView(dataObj: obj)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}
