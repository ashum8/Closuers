//
//  InterestRateTableViewCell.swift
//  mCAS
//
//  Created by iMac on 02/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class InterestRateTableViewCell: UITableViewCell {
    
    @IBOutlet weak var lblRequestedRate: UILabel!
    @IBOutlet weak var lblCurrentRate: UILabel!
    @IBOutlet weak var lblChargesCode: UILabel!
    
    func setupView(dataObj: RAModelClasses.Rate) {
        
        lblRequestedRate.font = CustomFont.shared().GETFONT_REGULAR(16)
        lblCurrentRate.font = CustomFont.shared().GETFONT_REGULAR(16)
        lblChargesCode.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        let calculatedVal: Double = dataObj.initialRate! - dataObj.proposedRate!
        let formattedString = NSMutableAttributedString()
        if calculatedVal > 0 {
            formattedString
                .attributedText("\(dataObj.proposedRate!)%\n")
                .attributedText("(\(String(format: "%.2f", calculatedVal))%)", color: .red)
        }
        else {
            formattedString
                .attributedText("\(dataObj.proposedRate!)%\n")
                .attributedText("(\(String(format: "%.2f", calculatedVal))%) ", color: Color.GREEN)
        }
        lblRequestedRate.attributedText = formattedString
        lblCurrentRate.text = "\(dataObj.initialRate!)%"
        lblChargesCode.text = dataObj.type?.code
    }
    
}
