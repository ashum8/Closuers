//
//  CustomCollection.swift
//  CollectionViewCustom
//
//  Created by iMac on 21/11/19.
//

import UIKit

class CustomCollection: UIView {
    
    @IBOutlet var vw: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var lblPageCount: UILabel!
    
    let reuseIdentifier = "CustomCell"
    let collectionMargin = CGFloat(16)
    let itemSpacing = CGFloat(4)
    let itemHeight = CGFloat(322)
    var listArrayModel = [RAModelClasses.RateApprovalRecord]()
    var itemWidth = CGFloat(0)
    var currentPage: Int = 0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    func commonInit() {
        
        Bundle.main.loadNibNamed("CustomCollection", owner: self, options: nil)
        vw.fixInView(self)
        vw.backgroundColor = Color.LIGHTER_GRAY
        
        collectionView.register(UINib(nibName: String(describing: GridCollectionCell.self), bundle: Bundle.main), forCellWithReuseIdentifier: reuseIdentifier)
        
        itemWidth =  UIScreen.main.bounds.width - collectionMargin * 2.0
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.itemSize = CGSize(width: itemWidth, height: itemHeight)
        layout.headerReferenceSize = CGSize(width: collectionMargin, height: 0)
        layout.footerReferenceSize = CGSize(width: collectionMargin, height: 0)
        layout.minimumLineSpacing = itemSpacing
        layout.scrollDirection = .horizontal
        collectionView.collectionViewLayout = layout
        collectionView.decelerationRate = .fast
        
        lblPageCount.layer.cornerRadius = 5
        lblPageCount.layer.masksToBounds = true
    }
    
    func collectionViewReloadData() {
        collectionView.reloadData()
        
        if !listArrayModel.isEmpty {
            collectionView.scrollToItem(at: NSIndexPath(item: 0, section: 0) as IndexPath, at: .centeredHorizontally, animated: false)
        }
        
        self.currentPage = 0
        self.setPageIndex()
    }
    
    private func setPageIndex() {
        self.lblPageCount.text = "\(self.currentPage + 1)" + "/" + "\(self.listArrayModel.count)"
    }
}

extension CustomCollection: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listArrayModel.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! GridCollectionCell
        
        // Configure the cell
        cell.setProperties()
        cell.setData(item: self.listArrayModel[indexPath.row])
        return cell
    }
}

extension CustomCollection: UIScrollViewDelegate {
    
    // MARK: - UIScrollViewDelegate protocol
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        
        let pageWidth = Float(itemWidth + itemSpacing)
        let targetXContentOffset = Float(targetContentOffset.pointee.x)
        let contentWidth = Float(collectionView!.contentSize.width)
        var newPage = Float(self.currentPage)
        
        if velocity.x == 0 {
            newPage = floor((targetXContentOffset - Float(pageWidth) / 2) / Float(pageWidth)) + 1.0
        }
        else {
            newPage = Float(velocity.x > 0 ? self.currentPage + 1 : self.currentPage - 1)
            if newPage < 0 {
                newPage = 0
            }
            if (newPage > contentWidth / pageWidth) {
                newPage = ceil(contentWidth / pageWidth) - 1.0
            }
        }
        
        if Int(newPage) + 1 <= listArrayModel.count {
            currentPage = Int(newPage)
            self.setPageIndex()
        }
        
        let point = CGPoint (x: CGFloat(newPage * pageWidth), y: targetContentOffset.pointee.y)
        targetContentOffset.pointee = point
    }
    
}
