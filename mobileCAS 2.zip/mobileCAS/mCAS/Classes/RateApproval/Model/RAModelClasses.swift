//
//  RAModelClasses.swift
//  mCAS
//
//  Created by iMac on 25/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

class RAModelClasses {
    
    struct RateApproverModel: Codable {
        let pageInfo: PageInfo?
        let rateApprovalRecords: [RateApprovalRecord]?
    }
    
    struct RateApprovalRecord: Codable {
        let application: Application
        let rates: [Rate]?
        let charges: [Charge]?
        let taskId: String?
        let taskType: String?
        let requestType: String?
        let loanAmount: String?
        let dynamicFormName: String?
        let dynamicFormData: String?
        let approvers: [Approver]?
        let recommenders: [Recommender]?
        let requestReasons: [RequestReason]?
        let requestComments: String?
    }
    
    struct Approver: Codable {
        let code: String?
        let name: String?
    }
    
    struct Recommender: Codable {
        let code: String?
        let name: String?
    }
    
    struct RequestReason: Codable {
        let code: String?
        let name: String?
    }
    
    struct Application: Codable {
        let applicant: Applicant
        let loanDetail: LoanDetail?
        let externalRefNumber: String
        let sourcingDate: String?
        let sourcingChannel: String?
        let createdBy: CreatedBy?
        let branch: Branch?
        let relationshipManager: RelationshipManager?
    }
    
    struct Applicant: Codable {
        let fullName: String
    }
    
    struct LoanDetail: Codable {
        let productType: ProductType?
        let product: Product?
        let scheme: Scheme?
        let branch: Branch?
    }
    
    struct CreatedBy: Codable {
        let code: String?
    }
    
    struct Branch: Codable {
        let code: String?
    }
    
    struct RelationshipManager: Codable {
        let code: String?
    }
    
    struct Rate: Codable {
        let type: RType?
        let initialRate: Double?
        let proposedRate: Double?
        let approvedRate: Double?
        let waiverRate: Double?
    }
    
    struct Charge: Codable {
        let initialValue: Double?
        let proposedValue: Double?
        let waiverValue: Double?
        let waiverNotAllowed: Bool?
        let chargeDetails: ChargeDetails?
        let unitType: UnitType?
    }
    
    struct ChargeDetails: Codable {
        let name: String?
        let id: NSInteger?
        let masterType: String?
    }
    
    struct UnitType: Codable {
        let code: String?
    }
    
    struct Product: Codable {
        let code: String?
    }
    
    struct ProductType: Codable {
        let code: String?
    }
    
    struct Scheme: Codable {
        let code: String
    }
    
    struct RType: Codable {
        let code: String
    }
    
    struct MultiselectLOVUserModel: Codable {
        let users: [User]?
        let pageInfoVO: PageInfoVO?
    }
    
    struct PageInfoVO: Codable {
        let requestStartIndex: Int?
        let requestPageSize: Int?
    }
    
    struct User: Codable {
        let fullName: String?
        let code: String?
    }
}

