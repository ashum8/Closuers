//
//  AddressListVC.swift
//  mCAS
//
//  Created by iMac on 06/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit


class AddressListVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var legendView: CustomLegendView!
    @IBOutlet weak var legendViewHeight: NSLayoutConstraint!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var nameLabel: UILabel!
    
    private var fivData: FIModelClasses.FIVData!
    private var dataObj = [FIModelClasses.LoanVerificationCategoryVOModel]() //contains all verifications of same application and same customer
    private var listModelArray = [FIModelClasses.AddressListModel]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = Color.LIGHTER_GRAY
        tableView.register(UINib(nibName: "AddressListCell", bundle: nil), forCellReuseIdentifier: "AddressListCell")
        
        nameLabel.font = CustomFont.shared().GETFONT_MEDIUM(19)
        nameLabel.text = self.dataObj.first?.customerName
        
        noDataCapturedView.setProperties()
        
        setupLegendsData()
        
        for item in self.dataObj {
            if let addrs = item.customerAddressVO, let addrsArray = addrs.fivAddressDetailVOList, let firstAddress = addrsArray.first {
                listModelArray.append(FIModelClasses.AddressListModel(name: item.customerName?.uppercased() ?? "", addressType: self.dataObj.first?.theFIVType ?? "", address: "\(firstAddress.address!), \(firstAddress.city!), \(firstAddress.state!), \(firstAddress.country!), \(firstAddress.zipCode!)", addressDistance: "", dataObj: item))
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            headerView.setTitleWith(line1: "Verify Address Details", line2: self.dataObj.first?.applicationId, showBack: true)
            bottomView.isHidden = true
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.setTitleWith()
        }
    }
    
    func setData(fivData: FIModelClasses.FIVData? = nil, data: [FIModelClasses.LoanVerificationCategoryVOModel]) {
        self.dataObj = data
        self.fivData = fivData
    }
    
    func updateListModel(data: FIModelClasses.LoanVerificationCategoryVOModel) {
        
        for (index, addressModel) in listModelArray.enumerated() {
            if addressModel.dataObj.applicationId == data.applicationId && addressModel.dataObj.customerId == data.customerId  {
                listModelArray[index].dataObj = data
                break
            }
        }
        
        tableView.reloadData()
    }
    
    private func setupLegendsData() {
        
        var list = [LegendModel]()
        list.append(LegendModel(bgColor: .systemYellow, title: "Neutral / Not Recommended"))
        list.append(LegendModel(bgColor: .systemBlue, title: "No Action Taken"))
        list.append(LegendModel(bgColor: .systemRed, title: "Negative / Recommended with changes"))
        list.append(LegendModel(bgColor: .systemGreen, title: "Positive / Recommended without changes"))
        
        legendView.setupProperties(arr: list, delegate: self)
    }
}

extension AddressListVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModelArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddressListCell", for: indexPath) as! AddressListCell
        cell.setProperties(dataObj: listModelArray[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let st = UIStoryboard.init(name: Storyboard.FI, bundle: nil)
        if let vc = st.instantiateViewController(withIdentifier: "FIVFormVC") as? FIVFormVC {
            vc.setData(fivData: fivData, data: listModelArray[indexPath.row].dataObj)
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
}

extension AddressListVC: CustomLegendViewDelegate {
    
    func showHideList(show: Bool) {
        legendViewHeight.constant = show ? legendView.tableView.contentSize.height + 60 : 50
    }
}
