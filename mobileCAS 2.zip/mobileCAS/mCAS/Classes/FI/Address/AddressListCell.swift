//
//  AddressListCell.swift
//  mCAS
//
//  Created by iMac on 06/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddressListCell: UITableViewCell {
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var addressTypeLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var directionButton: UIButton!
    @IBOutlet weak var uploadButton: UIButton!
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var buttonView: UIView!
    @IBOutlet weak var callButton: UIButton!
    @IBOutlet weak var dividerView: UIView!
    @IBOutlet weak var colorView: UIView!
    
    private var data: FIModelClasses.AddressListModel!
    
    func setProperties(dataObj: FIModelClasses.AddressListModel) {
        bgView.setShadow()
        bgView.setCornerRadius()
        buttonView.setCornerRadius()
        
        self.data = dataObj
        
        dividerView.backgroundColor = Color.LIGHTER_GRAY
        addressTypeLabel.font = CustomFont.shared().GETFONT_MEDIUM(19)
        
        addressLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        distanceLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        directionButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        uploadButton.setCornerRadius()
        uploadButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        uploadButton.backgroundColor = Color.BLUE
        uploadButton.setTitleColor(.white, for: .normal)
        
        submitButton.setCornerRadius()
        submitButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        submitButton.setTitleColor(.white, for: .normal)
        
        if let fiData = data.dataObj.fiData, !fiData.isEmpty {
            submitButton.backgroundColor = Color.BLUE
            submitButton.isSelected = true
            
            if data.dataObj.productType == ConstantCodes.PRODUCT_TYPE_CC {
                if let decision = data.dataObj.decision {
                    if Int(decision) == 1 {
                        colorView.backgroundColor = .systemGreen
                    }
                    else if Int(decision) == 2 {
                        colorView.backgroundColor = .systemYellow
                    }
                    else {
                        colorView.backgroundColor = .systemRed
                    }
                }
            }
            else {
                if let decision = data.dataObj.decision {
                    if Int(decision) == 1 {
                        colorView.backgroundColor = .systemGreen
                    }
                    else if Int(decision) == 2 {
                        colorView.backgroundColor = .systemRed
                    }
                    else {
                        colorView.backgroundColor = .systemYellow
                    }
                }
            }
        }
        else {
            colorView.backgroundColor = .systemBlue
            
            submitButton.backgroundColor = .gray
            submitButton.isSelected = false
        }
        
        
        callButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(16)
        callButton.layer.cornerRadius = 13
        callButton.layer.borderColor = Color.GREEN.cgColor
        callButton.layer.borderWidth = 1
        
        addressTypeLabel.text = dataObj.addressType
        
        if dataObj.addressDistance.isEmpty {
            distanceLabel.text = ""
        }
        else {
            distanceLabel.text = dataObj.addressDistance + " away"
        }
        
        addressLabel.text = dataObj.address
    }
    
    @IBAction func submitButtonAction(_ sender: UIButton) {
        
        if submitButton.isSelected {
            
            let params: [String: Any] = ["applicationId"    : self.data.dataObj.applicationId!,
                                         "customerId"       : self.data.dataObj.customerId!,
                                         "loanFIVId"        : self.data.dataObj.theFIInitDetailId!,
                                         "verificationType" : self.data.dataObj.verificationNameKey!,
                                         "productType"      : self.data.dataObj.productType!]
            
            Webservices.shared().POST(urlString: ServiceUrl.SUBMIT_FI_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
                if let response = responseObj as? [String: Any]
                {
                    if let isCompleted = response["completed"] as? Int, isCompleted == 1
                    {
                        CommonAlert.shared().showAlert(message: "FIV data is successfully submitted.", okAction: { _ in
                            
                            if let obj = AppDelegate.instance.getSpecificVC(targetClass: FIHomeVC.self) as? FIHomeVC {
                                obj.refreshDataOnViewWillAppear()
                                AppDelegate.instance.applicationNavController.popToViewController(obj, animated: true)
                            }
                        })
                    } 
                }
            }, failure: { (error) in
                
                if let error = error {
                    CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
                }
                
            }, noNetwork: { (error) in
                
            })
        }
    }
    
    @IBAction func uploadButtonAction(_ sender: UIButton) {
        
    }
    
    @IBAction func callButtonAction(_ sender: Any) {
        
        if let obj = self.data.dataObj.customerAddressVO, let phoneNumber = obj.phone {
            CommonUtils.shared().makeCall(mobileNumber: phoneNumber)
        }
    }
    
    @IBAction func directionButtonAction(_ sender: Any) {        
        if let addressVO = self.data.dataObj.customerAddressVO, let addrsArray = addressVO.fivAddressDetailVOList, let firstAddress = addrsArray.first, let address = firstAddress.address, let city = firstAddress.city, let state = firstAddress.state, let country = firstAddress.country {
            
            let suffixURL = "daddr=\(address) \(city) \(state) \(country)&saddr=\(AppDelegate.instance.formattedAddress)".addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed) ?? ""
            
            if let directionURL = URL(string: "comgooglemaps://?\(suffixURL)"), UIApplication.shared.canOpenURL(directionURL) {
                UIApplication.shared.open(directionURL, options: [:])
            }
            else if let directionURL = URL(string: "https://maps.google.com/?\(suffixURL)"), UIApplication.shared.canOpenURL(directionURL) {
                UIApplication.shared.open(directionURL, options: [:])
            }
        }
    }
}
