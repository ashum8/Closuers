//
//  KeyValueFormView.swift
//  mCAS
//
//  Created by iMac on 23/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol KeyValueFormViewDelegate {
    func editDeleteFormAction(identifier: String, arrList: [[String: Any]], isRemove: Bool, index: Int)
}

class KeyValueFormView: UIView {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var removeButton: UIButton!
    
    private var delegate: KeyValueFormViewDelegate?
    private var identifier: String!
    private var arrList: [[String: Any]]!
    private var fieldArrList: [FIModelClasses.DynamicVerificationTypeVOModel]!
    private var index: Int!
    private var dataObj: FIModelClasses.FIVData!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("KeyValueFormView", owner: self, options: nil)
        containerView.fixInView(self)
        self.layer.masksToBounds = true
        tableView.register(UINib.init(nibName: "KeyValueCell", bundle: Bundle.main), forCellReuseIdentifier: "KeyValueCell")
    }
    
    func setProperties(arrList: [[String:Any]], delegate: KeyValueFormViewDelegate, identifier: String, index: Int, fieldDataArr: [FIModelClasses.DynamicVerificationTypeVOModel], dataObj: FIModelClasses.FIVData) {
        
        bgView.layer.borderColor = Color.BLUE.cgColor
        bgView.layer.borderWidth = 1
        bgView.setCornerRadius()
        self.arrList = arrList
        self.delegate = delegate
        self.identifier = identifier
        self.index = index
        self.fieldArrList = fieldDataArr
        self.dataObj = dataObj
    }
    
    @IBAction func editButtonAction(_ sender: Any) {
        delegate?.editDeleteFormAction(identifier: identifier, arrList: arrList, isRemove: false, index: self.index)
    }
    
    @IBAction func deleteButtonAction(_ sender: Any) {
        delegate?.editDeleteFormAction(identifier: identifier, arrList: arrList, isRemove: true, index: self.index)
    }
    
    private func getValueFromKeyLOV(queryType: String, key: String) -> String {
        if let arrayObj = self.dataObj.verificationMasterDetailVOList, !arrayObj.isEmpty {
            let obj = arrayObj.filter({$0.parentKey == queryType})
            
            if let arrayKeyValue = obj.first?.keyValuePairs, !arrayKeyValue.isEmpty {
                let arr = arrayKeyValue.filter({ $0.key == key})
                if !arr.isEmpty {
                    return arr.first?.value ?? ""
                }
            }
        }
        return key
    }
}

extension KeyValueFormView: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "KeyValueCell") as! KeyValueCell
        let model = self.arrList[indexPath.row]
        let fieldId = CommonUtils.shared().getValidatedString(string: model["fieldId"])
        let fieldLabelArr = self.fieldArrList.filter( { $0.fieldId == fieldId} )
        var fieldLabel = ""
        var controlType = ""
        
        if !fieldLabelArr.isEmpty {
            fieldLabel = fieldLabelArr.first?.fieldLabel ?? ""
            controlType = fieldLabelArr.first?.controlType ?? ""
        }
        
        var fieldValue = CommonUtils.shared().getValidatedString(string: model["fieldValue"])
        fieldValue = fieldValue.replacingOccurrences(of: "~", with: " ")
        
        if controlType == "CAL" {
            fieldValue = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: fieldValue)
        }
        else if controlType == "LOV" {
            fieldValue = getValueFromKeyLOV(queryType: fieldLabelArr.first?.controlQuery ?? "", key: fieldValue)
        }
        
        cell.setProperties(key: fieldLabel == "" ? fieldId : fieldLabel, value: fieldValue)
        return cell
    }
}
