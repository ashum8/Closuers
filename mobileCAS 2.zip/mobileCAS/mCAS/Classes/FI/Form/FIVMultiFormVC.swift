//
//  FIVMultiFormVC.swift
//  mCAS
//
//  Created by iMac on 24/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol FIMultiFormDelegate {
    func filledForm(fillDetailArr: [[String: Any]], identifier: String, index: Int?)
}

class FIVMultiFormVC: UIViewController {
    @IBOutlet weak var formView: FICustomFormView!
    @IBOutlet weak var formViewHeight: NSLayoutConstraint!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private var delegate: FIMultiFormDelegate?
    
    private var fivData: FIModelClasses.FIVData!
    private var dataObj: FIModelClasses.LoanVerificationCategoryVOModel!
    private var fieldData: [FIModelClasses.DynamicVerificationTypeVOModel]!
    
    private var buttonIdentifier: String!
    private var autoFillValuesArr :[[String: Any]] = []
    private var index: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        buttonView.setProperties(showNext: true, nextBtnTitle: "Add", delegate: self)
        formView.setProperties(fivData: fivData, fieldData: self.fieldData, delegate: self, autoFillValuesArr: self.autoFillValuesArr)
        updateHeight()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            var title = ""
            if let dataArr = fivData?.loanFieldVerificationDetailVOList, !dataArr.isEmpty {
                title = CommonUtils.shared().getValidatedString(string: dataArr.first?.loanVerificationCategoryVOList?.first?.customerName)
            }
            
            headerView.setTitleWith(line1: title, showBack: true)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.setTitleWith()
        }
    }
    
    func setData(fivData: FIModelClasses.FIVData, fieldData: [FIModelClasses.DynamicVerificationTypeVOModel], delegate: FIMultiFormDelegate, identifier: String = "", autoFillValuesArr: [[String: Any]] = [], index: Int? = nil) {
        self.fivData = fivData
        self.fieldData = fieldData
        self.buttonIdentifier = identifier
        self.delegate = delegate
        self.autoFillValuesArr = autoFillValuesArr
        self.index = index
    }
}

extension FIVMultiFormVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        let dynamicFieldsValue = formView.getAllFieldValues()
        
        if !dynamicFieldsValue.isEmpty {
            delegate?.filledForm(fillDetailArr: dynamicFieldsValue, identifier: buttonIdentifier, index: index)
            self.navigationController?.popViewController(animated: true)
        }
    }
}

extension FIVMultiFormVC: FIFormViewDelegate {
    
    func updateHeight() {
        formViewHeight.constant = formView.formStackView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize).height
    }
}
