//
//  CommonFormUtils.swift
//  mCAS
//
//  Created by iMac on 22/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//
import Foundation

class CommonFormUtils: NSObject {
    
    private static var instance: CommonFormUtils?
    
    static func shared() -> CommonFormUtils{
        if instance == nil {
            instance = CommonFormUtils()
        }
        return instance!
    }
    
    func setupHeadingLabel(title: String, isMandatory: Bool = false, bgColor: UIColor = .clear, isMainHeding: Bool = false)-> UILabel {
        let label = EdgeInsetLabel()
        label.textColor = .darkGray
        label.backgroundColor = bgColor
        
        if isMainHeding {
            label.font = CustomFont.shared().GETFONT_MEDIUM(19)
            label.leftTextInset = 2.0
        }
        else {
            label.font = CustomFont.shared().GETFONT_REGULAR(19)
            label.topTextInset = 10.0
        }
        let formattedString = NSMutableAttributedString()
        if isMandatory {
            formattedString
                .attributedText(title, color: .gray, font: label.font)
                .attributedText("*",color: Color.RED ,font: label.font)
        }
        else {
            formattedString
                .attributedText(title, color: .gray, font: label.font)
        }
        label.attributedText = formattedString
        return label
    }
    
    func setupMultiFormButton(dataObj: FIModelClasses.DynamicVerificationTypeVOModel, tag: Int) -> UIButton {
        let btn = UIButton()
        btn.setCornerRadius()
        btn.layer.borderWidth = 1
        btn.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(19)
        btn.setTitleColor(Color.BLUE, for: .normal)
        btn.layer.borderColor = Color.BLUE.cgColor
        btn.backgroundColor = .white
        btn.accessibilityIdentifier = dataObj.fieldId
        btn.setTitle("+ \(dataObj.fieldLabel!)", for: .normal)
        return btn
    }
    
    func setupCustomTextView(dataObj: FIModelClasses.DynamicVerificationTypeVOModel, tag: Int, delegate:CustomTFViewDelegate? = nil, unitText:String = "", type: FieldType = .Text, preFillValue: String) -> UIView
    {
        let view = CustomTextFieldView()
        view.accessibilityIdentifier = dataObj.fieldId
        view.setProperties(placeHolder: "Enter \(dataObj.fieldLabel!)", type: type, delegate: delegate, unitText: unitText, tag: tag, enabled: dataObj.isFieldDisabled == "Y" ? false : true, removeTopMargin: true)
        view.tag = tag
        view.setFieldValue(text: preFillValue)
        return view
    }
    
    func setupCustomLOVView(dataObj: FIModelClasses.DynamicVerificationTypeVOModel, tag: Int, delegate:SelectedLOVDelegate, preFillValue: String, lovData:FIModelClasses.FIVData) -> UIView
    {
        let view = LOVFieldView()
        view.tag = tag
        view.accessibilityIdentifier = dataObj.fieldId
        view.setLOVProperties(title: dataObj.fieldLabel!, tag: tag, autoFillValue: preFillValue, delegate: delegate, optionArray: getLOVDropDownArray(queryType: dataObj.controlQuery!, fiData: lovData), enable: dataObj.isFieldDisabled == "Y" ? false : true, removeTopMargin: true)
        
        if dataObj.fieldId == "gender" {
            view.autoFillLOVBy(key: preFillValue)
        }
        
        return view
    }
    
    func setupCustomPhoneView(dataObj: FIModelClasses.DynamicVerificationTypeVOModel, tag: Int, delegate:SelectedLOVDelegate, lovData:FIModelClasses.FIVData, preFillValue: String) -> UIView
    {
        let options = getLOVDropDownArray(queryType: dataObj.controlQuery!, fiData: lovData, isAddDisplayValue: true)
        let view = CustomPhoneNumberView()
        view.setProperties(tag: tag, delegate: delegate, optionArray: options, removeTopMargin: true, showExtension: true)
        view.accessibilityIdentifier = dataObj.fieldId
        view.tag = tag
        prefillPhoneView(view: view, preFillValue: preFillValue, optionArray: options)
        return view
    }
    
    func setupCustomMobileView(dataObj: FIModelClasses.DynamicVerificationTypeVOModel, tag: Int, lovDelegate:SelectedLOVDelegate, lovData:FIModelClasses.FIVData, preFillValue: String) -> UIView
    {
        let options = getLOVDropDownArray(queryType: dataObj.controlQuery!, fiData: lovData, isAddDisplayValue: true)
        let view = CustomMobileNumberView()
        view.setProperties(tag: tag, lovDelegate: lovDelegate, optionArray: options, removeTopMargin: true)
        view.accessibilityIdentifier = dataObj.fieldId
        view.tag = tag
        prefillMobileView(view: view, preFillValue: preFillValue, optionArray: options)
        return view
    }
    
    func setupCurrencyView(dataObj: FIModelClasses.DynamicVerificationTypeVOModel, tag: Int, delegate:SelectedLOVDelegate, lovData:FIModelClasses.FIVData, preFillValue: String) -> UIView
    {
        let view = CustomCurrencyView()
        view.accessibilityIdentifier = dataObj.fieldId
        view.setProperties(tag: tag, delegate: delegate, optionArray: getLOVDropDownArray(queryType: dataObj.controlQuery!, fiData: lovData), removeTopMargin: true, preFillValue: preFillValue)
        view.tag = tag
        return view
    }
    
    private func prefillMobileView(view: CustomMobileNumberView, preFillValue: String, optionArray: [DropDown]) {
        var countryKey = CommonUtils.shared().getValidatedString(string: optionArray.first?.code)
        var mobileTFValue = ""

        if !preFillValue.isEmpty, preFillValue.contains("~")
        {
            let arr = preFillValue.split(separator: "~")
            if !arr.isEmpty {
                countryKey = String(arr[0])
                
                if arr.count == 3, String(arr[2]) != "X" {
                    mobileTFValue = String(arr[2])
                }
            }
        }
        
        view.setAutoFillMobileNumber(countryKey: countryKey, mobileNumber: mobileTFValue)
    }
    
    private func prefillPhoneView(view: CustomPhoneNumberView, preFillValue: String, optionArray: [DropDown]) {
        var countryKey = CommonUtils.shared().getValidatedString(string: optionArray.first?.code)
        var stdTFValue = ""
        var phoneTFValue = ""
        var extTFValue = ""
        
        if !preFillValue.isEmpty, preFillValue.contains("~")
        {
            let arr = preFillValue.split(separator: "~")
            if !arr.isEmpty {
                countryKey = String(arr[0])
                
                if arr.count >= 3, String(arr[2]) != "X" {
                    stdTFValue = String(arr[2])
                }
                if arr.count >= 4, String(arr[3]) != "X" {
                    phoneTFValue = String(arr[3])
                }
                if arr.count == 5, String(arr[4]) != "X" {
                    extTFValue = String(arr[4])
                }
            }
        }
        
        view.setAutoFillPhoneNumber(countryKey: countryKey, std: stdTFValue, phoneNumber: phoneTFValue, ext: extTFValue)
    }
    
    private func getLOVDropDownArray(queryType: String, fiData: FIModelClasses.FIVData, isAddDisplayValue: Bool = false) -> [DropDown] {
        var dropdownArray: [DropDown] = []
        if let arrayObj = fiData.verificationMasterDetailVOList, !arrayObj.isEmpty {
            let dictObj = arrayObj.filter({$0.parentKey == queryType})
            if let arrayKeyValue = dictObj.first?.keyValuePairs, !arrayKeyValue.isEmpty {
                if isAddDisplayValue {
                    dropdownArray = arrayKeyValue.map({ DropDown(code: $0.key!, name: $0.value!, listDisplayValue:$0.key!, lovDisplayValue: "\($0.key!) (\($0.value!))")})
                }
                else {
                    dropdownArray = arrayKeyValue.map({ DropDown(code: $0.key!, name: $0.value!)})
                }
            }
        }
        
        return dropdownArray
    }
    
    func fetchAutoFillString(arrList: [[String: Any]], identifier: String) -> String {
        let arr = arrList.filter({CommonUtils.shared().getValidatedString(string: $0["fieldId"]) == identifier})
        if !arr.isEmpty {
            return CommonUtils.shared().getValidatedString(string: arr.first?["fieldValue"])
        }
        return ""
    }
}
