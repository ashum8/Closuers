//
//  FISearchVC.swift
//  mCAS
//
//  Created by iMac on 21/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class FISearchVC: UIViewController {
    
    @IBOutlet weak var applicationIDView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        applicationIDView.setProperties(placeHolder: "Application ID", delegate: self)
        buttonView.setProperties(nextBtnTitle: "Search", delegate: self)
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "Search Application", showBack: true)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.setTitleWith()
        }
    }
}

extension FISearchVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        let params = ["applicationId" : applicationIDView.getFieldValue()]
        
        Webservices.shared().POST(urlString: ServiceUrl.SEARCH_CASES_FI_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
            if let response = responseObj as? [String: Any]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: FIModelClasses.FIVData.self) { list in
                    
                    var listModelArray = [FIModelClasses.LoanVerificationCategoryVOModel]()
                    
                    if let arrObj = list.loanFieldVerificationDetailVOList, !arrObj.isEmpty {
                        listModelArray = arrObj.first?.loanVerificationCategoryVOList ?? []
                    }
                    
                    let st = UIStoryboard.init(name: Storyboard.FI, bundle: nil)
                    if let vc = st.instantiateViewController(withIdentifier: "FISearchResultVC") as? FISearchResultVC {
                        vc.setData(data: listModelArray)
                        self.navigationController?.pushViewController(vc, animated: false)
                    }
                }
            }
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            
        })
    }
}

extension FISearchVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: !applicationIDView.getFieldValue().isEmpty)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        return text.isAlphanumeric && text.count <= Constants.APPLICATION_ID_LENGTH
    }
}
