//
//  FISearchResultVC.swift
//  mCAS
//
//  Created by iMac on 23/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class FISearchResultVC: UIViewController {
    
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var tableView: UITableView!
    private var listModelArray = [FIModelClasses.LoanVerificationCategoryVOModel]()
    private var mainModelArray = [FIModelClasses.LoanVerificationCategoryVOModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        noDataCapturedView.setProperties()
        tableView.register(UINib(nibName: "CasesCell", bundle: nil), forCellReuseIdentifier: "CasesCell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            headerView.setTitleWith(line1: "Search Result (\(self.listModelArray.count))", showBack: true)
            bottomView.isHidden = true
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.setTitleWith()
        }
    }
    
    func updateListModel(data: FIModelClasses.LoanVerificationCategoryVOModel) {
        
        for (index, addressModel) in self.mainModelArray.enumerated() {
            if addressModel.applicationId == data.applicationId && addressModel.customerId == data.customerId {
                self.mainModelArray[index] = data
                break
            }
        }
        
        resetTableData()
        tableView.reloadData()
    }
    
    func setData(data: [FIModelClasses.LoanVerificationCategoryVOModel]) {
        self.mainModelArray = data
        
        resetTableData()
    }
    
    private func resetTableData() {
        self.listModelArray.removeAll()
        
        self.listModelArray = self.mainModelArray.compactMap({
            let item = $0
            if self.listModelArray.isEmpty {
                return $0
            }
            else {
                let arr = self.listModelArray.filter({ ($0.applicationId != item.applicationId) && ($0.customerId != item.customerId)})
                return arr.isEmpty ? nil : arr.first
            }
        })
    }
}

extension FISearchResultVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CasesCell") as! CasesCell
        
        let model = listModelArray[indexPath.row]
        cell.label1.text = model.customerName
        cell.label2.text = model.applicationId
        cell.label3.text = "\(mainModelArray.filter({($0.customerId == model.customerId) && ($0.applicationId == model.applicationId)}).count) verifications required"
        
        cell.loanTypeLabel.text = model.productTypeDesc
        cell.label3.textColor = .orange
        cell.setProperties(cellIndex: indexPath.row, customerType: Constants.CUSTOMER_TYPE_INDV, showArrow: true, productTypeCode: model.productType)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let st = UIStoryboard.init(name: Storyboard.FI, bundle: nil)
        if let vc = st.instantiateViewController(withIdentifier: "AddressListVC") as? AddressListVC {
            let model = listModelArray[indexPath.row]
            vc.setData(data: mainModelArray.filter({($0.customerId == model.customerId) && ($0.applicationId == model.applicationId)}))
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
}
