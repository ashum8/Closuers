//
//  LegendsTableViewCell.swift
//  mCAS
//
//  Created by iMac on 06/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class LegendsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var colorView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    
    func setProperties(dataObj: LegendModel) {
        
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        titleLabel.numberOfLines = 2
        colorView.setCornerRadius()
        colorView.layer.masksToBounds = true
        colorView.setShadow()
        
        colorView.backgroundColor = dataObj.bgColor
        titleLabel.text = dataObj.title
    }
}
