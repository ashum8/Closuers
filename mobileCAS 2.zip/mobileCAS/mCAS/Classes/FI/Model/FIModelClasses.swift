//
//  File.swift
//  mCAS
//
//  Created by iMac on 21/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import Foundation

class FIModelClasses {
    
    struct FIVData: Codable {
        let dynamicVerificationTypeVOList : [DynamicVerificationTypeVOModel]?
        let loanFieldVerificationDetailVOList : [LoanFieldVerificationDetailVOList]?
        let verificationMasterDetailVOList : [VerificationMasterDetailVOModel]?
    }
    
    struct DynamicVerificationTypeVOModel: Codable {
        let verificationType : String?
        let fieldLabel : String?
        let fieldType : String?
        let fieldName : String?
        let fieldId : String?
        let fieldLength : String?
        let isFieldMandatory : String?
        let isFieldDisabled : String?
        let fieldValue : String?
        let controlType : String?
        let controlQuery : String?
        let groupId : String?
        let groupDescription : String?
        let productType : String?
        let multiEntryDynamicFormVOList : [DynamicVerificationTypeVOModel]?
    }
    
    struct LoanFieldVerificationDetailVOList: Codable {
        let loanVerificationCategoryVOList : [LoanVerificationCategoryVOModel]?
    }
    
    struct LoanVerificationCategoryVOModel: Codable {
        let applicationId : String?
        let customerId : String?
        let theFIVType : String?
        let theFIInitDetailId : String?
        let verificationNameKey : String?
        let verificationStatus : String?
        let customerName : String?
        let productType : String?
        let productTypeDesc : String?
        let customerAddressVO : CustomerAddressVO?
        let decision : String?
        let remarks : String?
        var fiData : [FIFillData]?
    }
    
    struct FIFillData: Codable {
        let fieldId : String?
        let fieldValue : String?
    }
    
    struct CustomerAddressVO: Codable {
        let phone : String?
        let fivAddressDetailVOList : [FivAddressDetailVOModel]?
    }
    
    struct FivAddressDetailVOModel: Codable {
        let addressType : String?
        let address : String?
        let city : String?
        let state : String?
        let country : String?
        let zipCode : String?
        let districtName : String?
    }
    
    struct VerificationMasterDetailVOModel: Codable {
        let verificationType : String?
        let parentKey : String?
        let keyValuePairs : [KeyValuePair]?
    }
    
    struct KeyValuePair: Codable {
        let key : String?
        let value : String?
    }
    
    struct AddressListModel {
        let name: String
        let addressType: String
        let address: String
        let addressDistance: String
        var dataObj: LoanVerificationCategoryVOModel
    }
}
