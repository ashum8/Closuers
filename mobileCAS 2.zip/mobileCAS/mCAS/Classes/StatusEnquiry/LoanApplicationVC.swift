//
//  LoanApplicationVC.swift
//  mCAS
//
//  Created by iMac on 24/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class LoanApplicationVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var dataShownForLabel: UILabel!
    @IBOutlet weak var daysLeftButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var daysFilterView: UIView!
    @IBOutlet weak var daysFilterViewHeight: NSLayoutConstraint!
    @IBOutlet weak var searchExternalButton: UIButton!
    @IBOutlet weak var filterView: UIView!
    @IBOutlet weak var filterViewHeight: NSLayoutConstraint!
    @IBOutlet weak var tagView: TagListView!
    @IBOutlet weak var clearFilterButton: UIButton!
    
    private enum HeaderOptions: String {
        case exSearch = "Search External"
    }
    
    private var dateRangeView: DateRangeFilterView!
    private var daysListArray: [DAYFILTER] = [.SevenDay, .FifteenDay, .ThirtyDay, .Range]
    private var headerOptionArray: [HeaderOptions] = [.exSearch]
    
    private var listModelArray = [SEModelClasses.ApplicationStatusList]()
    private var filteredModelArray = [SEModelClasses.ApplicationStatusList]()
    
    private var selectedDay: DAYFILTER = .SevenDay
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        noDataCapturedView.setProperties()
        daysFilterView.layer.masksToBounds = true
        filterView.layer.masksToBounds = true
        clearFilterButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(17)
        clearFilterButton.setTitleColor(Color.BLUE, for: .normal)
        
        setButtonTitleAndIcon(text: selectedDay.rawValue, up: false)
        dataShownForLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        
        tableView.register(UINib.init(nibName: "CasesCell", bundle: Bundle.main), forCellReuseIdentifier: "CasesCell")
        tableView.tableFooterView = UIView()
        
        setTagsViewProperties()
        searchExternalButton.setButtonProperties()
        fetchCases()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "Status", showBack: true, delegate: self)
            headerView.showHideSearchMikeFilterOption(showSearch: true, showFilter: true, showOption: true, dropdownListArray: headerOptionArray.map({ $0.rawValue }))
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideSearchMikeFilterOption()
        }
    }
    
    @IBAction func searchExternalButtonAction(_ sender: Any) {
        
        let storyboard = UIStoryboard.init(name: Storyboard.STATUS_ENQUIRY, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "ExternalSearchVC") as? ExternalSearchVC {
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
    
    func filterButtonAction() {
       
        if !self.listModelArray.isEmpty {
            let storyboard = UIStoryboard.init(name: Storyboard.STATUS_ENQUIRY, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "SEFilterVC") as? SEFilterVC {
                let selectedTags = tagView.tagViews.map({ $0.currentTitle!})
                
                vc.setData(title: "Product Type", masterName: Entity.PRODUCT_CATEGORY, delegate: self, selectedTags: selectedTags)
                AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
            }
        }
        else {
            CommonAlert.shared().showAlert(message: "Sorry! There is no data to filter")
        }
    }
    
    private func setButtonTitleAndIcon(text: String, up: Bool) {
        if up {
            daysLeftButton.setButtonTextAndRightIcon(title: text, image: "list_arrow_up")
        }
        else {
            daysLeftButton.setButtonTextAndRightIcon(title: text, image: "list_arrow_down")
        }
    }
    
    private func setTagsViewProperties() {
        tagView.textFont = CustomFont.shared().GETFONT_REGULAR(15)
        tagView.textColor = .darkGray
        tagView.tagBackgroundColor = Color.LIGHTER_GRAY
        tagView.alignment = .left
        tagView.enableRemoveButton = true
        tagView.removeButtonIconSize = 10
        tagView.removeIconLineWidth = 2
        tagView.removeIconLineColor = .darkGray
        tagView.cornerRadius = 15
        tagView.paddingX = 10
        tagView.paddingY = 10
        tagView.marginX = 10
        tagView.marginY = 10
        tagView.borderWidth = 1
        tagView.borderColor = .lightGray
        tagView.selectedTextColor = .darkGray
        tagView.delegate = self
    }
    
    private func fetchCases() {
        
        listModelArray.removeAll()
        filteredModelArray.removeAll()

        let dates = CommonUtils.shared().fetchFromDateAndToDateForDayFilter(from: self.dateRangeView?.dateFromView.getFieldValue() ?? "", to: self.dateRangeView?.dateToView.getFieldValue() ?? "", selectedDay: selectedDay)
        
        let param : [String:Any] = ["fromDate"  : dates.0,
                                    "toDate"    : dates.1]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_ALL_CASES_SE_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [[String : AnyObject]]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: [SEModelClasses.ApplicationStatusList].self) { list in
                    self.listModelArray.append(contentsOf: list)
                    self.filteredModelArray = self.listModelArray
                }
            }
            
            self.setListData()
            
        }, failure: { (error) in
            
            self.setListData()
            
        }, noNetwork: { (error) in
            
            self.setListData()
        })
    }
    
    private func setListData(isSearchON: Bool = false) {
        
        daysFilterViewHeight.constant = (isSearchON || !tagView.tagViews.isEmpty) ? 0 : 45
        tableView.isHidden = filteredModelArray.isEmpty
        noDataCapturedView.isHidden = !filteredModelArray.isEmpty || isSearchON
        searchExternalButton.isHidden = !filteredModelArray.isEmpty || isSearchON
        tableView.reloadData()
    }
    
    private func updateTagViewHeightAndFilterData() {
        if let lastView = tagView.rowViews.last {
            filterViewHeight.constant = lastView.frame.origin.y + lastView.frame.size.height + 10
        }
        else {
            filterViewHeight.constant = 0
        }
        
        let arr = tagView.tagViews.map({ $0.currentTitle?.lowercased() })
        
        if arr.isEmpty {
           filteredModelArray = listModelArray
        }
        else {
            filteredModelArray = listModelArray.filter {
                return arr.contains($0.loanDetail?.productType?.name?.lowercased())
            }
        }
                
        self.setListData()
    }
    
    @IBAction func daysLeftButtonClicked(_ sender: Any) {
        
        let listArray = daysListArray.map({ $0.rawValue })
        
        let obj = SimpleListVC.init(nibName: "SimpleListVC", bundle: nil)
        obj.setData(listArray: listArray, selectedValue: self.selectedDay.rawValue, delegate: self)
        
        if let popoverPresentationController = obj.popoverPresentationController {
            self.view.endEditing(true)
            popoverPresentationController.permittedArrowDirections = .up
            popoverPresentationController.sourceView = self.daysLeftButton
            popoverPresentationController.sourceRect = self.daysLeftButton.bounds
            popoverPresentationController.delegate = self
            present(obj, animated: true, completion: nil)
        }
    }
    
    @IBAction func clearFilterButtonAction(_ sender: Any) {
        tagView.removeAllTags()
        updateTagViewHeightAndFilterData()
    }
    
    private func getDataFromApplicationNumber(neoRefNumber: String) {
        let params = ["searchParameters" : ["applicationNumber" : neoRefNumber]]
        
        Webservices.shared().POST(urlString: ServiceUrl.SEARCH_CASES_SE_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
            if let response = responseObj as? [[String: Any]]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: [SEModelClasses.StatusEnquiryRecords].self) { list in
                    
                    let storyboard = UIStoryboard.init(name: Storyboard.STATUS_ENQUIRY, bundle: nil)
                    
                    if let vc = storyboard.instantiateViewController(withIdentifier: "LoanApplicationDetailVC") as? LoanApplicationDetailVC {
                        //Due to filter handlling - when we move to next screen - reset search
                        self.searchOnOff(isSearching: false)

                        vc.setDate(data: list[0])
                        AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
                    }
                }
            }
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            
        })
    }
}

extension LoanApplicationVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CasesCell") as! CasesCell
        
        let model = filteredModelArray[indexPath.row]
        let customerType = model.applicant?.customerType?.code
        let productTypeCode = model.loanDetail?.productType?.code

        cell.label1.text = model.applicant?.getFullName()
        cell.label2.text = "\(model.neoReferenceNumber ?? "") \(Constants.SEPERATOR) " + "\(model.loanDetail?.loanAmount ?? 0)".formatCurrency
        cell.loanTypeLabel.text = model.loanDetail?.productType?.name
        cell.setProperties(cellIndex: indexPath.row, customerType: customerType, showArrow: true, productTypeCode: productTypeCode)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        getDataFromApplicationNumber(neoRefNumber: filteredModelArray[indexPath.row].neoReferenceNumber ?? "")
    }
}


extension LoanApplicationVC: HeaderDelegate {
    
    func searchOnOff(isSearching: Bool) {
        tagView.removeAllTags()
        updateTagViewHeightAndFilterData()

        handleSearch(text: "")
        setListData(isSearchON: isSearching)
    }
    
    func handleSearch(text: String) {
        
        if !text.isEmpty {
            filteredModelArray = listModelArray.filter {
                let searchText = text.lowercased()
                
                return ($0.applicant!.getFullName().lowercased().contains(searchText)) || ($0.neoReferenceNumber!.lowercased().contains(searchText))
            }
        }
        else {
            filteredModelArray = listModelArray
        }
        
        setListData(isSearchON: true)
    }
    
    func handleSelectedOption(index: Int) {
        let selectedItem = self.headerOptionArray[index]
        
        if selectedItem == .exSearch {
            searchExternalButton.sendActions(for: .touchUpInside)
        }
    }
}

extension LoanApplicationVC: TagListViewDelegate {
    
    func tagRemoveButtonPressed(_ title: String, tagView: TagView, sender: TagListView) {
        self.tagView.removeTagView(tagView)
        updateTagViewHeightAndFilterData()
    }
}

extension LoanApplicationVC: SimpleListVCDelegate {
    
    func selectedListOption(index: Int) {
        
        self.dismiss(animated: true) {
            
            let item = self.daysListArray[index]
            
            if item == .Range {
                if self.dateRangeView == nil {
                    self.dateRangeView = .fromNib()
                    self.dateRangeView.setProperties(width: self.view.frame.size.width, height: self.view.frame.size.height, delegate: self)
                    self.view.addSubview(self.dateRangeView)
                }
                
                self.dateRangeView.alpha = 1
            }
            else {
                self.selectedDay = item
                self.setButtonTitleAndIcon(text: self.selectedDay.rawValue, up: false)
                self.fetchCases()
            }
        }
    }
}

extension LoanApplicationVC: DateRangeViewDelegate {
    
    func dateRangeFilterCall(fromDate: String, toDate: String) {
        self.selectedDay = .Range
        self.setButtonTitleAndIcon(text: "\(fromDate) - \(toDate)", up: false)
        self.fetchCases()
    }
}

extension LoanApplicationVC: UIPopoverPresentationControllerDelegate {
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
    func popoverPresentationControllerDidDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) {
        popoverPresentationController.delegate = nil
    }
    
    func popoverPresentationControllerShouldDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) -> Bool {
        return true
    }
}

extension LoanApplicationVC: FilterVCDelegate {
    
    func selectedFilters(selectedFilterArray: [DropDown]) {
        tagView.removeAllTags()
        
        for obj in selectedFilterArray {
            tagView.addTag(obj.name)
        }
        
        updateTagViewHeightAndFilterData()
    }
}


