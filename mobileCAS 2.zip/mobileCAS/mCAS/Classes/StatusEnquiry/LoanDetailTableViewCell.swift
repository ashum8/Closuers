//
//  LoanDetailTableViewCell.swift
//  mCAS
//
//  Created by iMac on 24/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


protocol LDTableViewDelegate {
    func reloadCell()
}

class LoanDetailTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var separatorView: UIView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var arrowButton: UIButton!
    @IBOutlet weak var arrowButtonHeight: NSLayoutConstraint!
    
    private var listModelArray: [KeyValueModel] = []
    private var filteredListModelArray: [KeyValueModel] = []
    private var delegate: LDTableViewDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        tableView.register(UINib(nibName: "KeyValueCell", bundle: nil), forCellReuseIdentifier: "KeyValueCell")
    }
    
    func setProperties(title: String = "", arrList: [KeyValueModel], delegate: LDTableViewDelegate? = nil, isCollapsable: Bool = false) {
        titleLabel.font = CustomFont.shared().GETFONT_MEDIUM(18)
        titleLabel.text = title
        separatorView.backgroundColor = Color.LIGHTER_GRAY
        containerView.setCornerRadius()
        containerView.setShadow()
        
        self.listModelArray = arrList
        self.delegate = delegate
        
        if isCollapsable {
            arrowButtonHeight.constant = (title == "") ? 0 : 20
            titleLabel.isUserInteractionEnabled = true
            titleLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tapedOnLabel)))
            separatorView.isHidden = !(arrowButton.isSelected && !listModelArray.isEmpty)
        }
        else {
            separatorView.isHidden = (title == "")
            self.filteredListModelArray = self.listModelArray
        }
    }
    
    @IBAction func arrowButtonAction(_ sender: UIButton) {
        tapedOnLabel()
    }
    
    @objc func tapedOnLabel() {
        arrowButton.isSelected = !arrowButton.isSelected
        
        if arrowButton.isSelected {
            self.filteredListModelArray = self.listModelArray
        }
        else {
            self.filteredListModelArray.removeAll()
        }
        tableView.reloadData()
        delegate?.reloadCell()
    }
}


extension LoanDetailTableViewCell: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredListModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let model = filteredListModelArray[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "KeyValueCell") as! KeyValueCell
        cell.setProperties(key: model.fieldName, value: model.fieldValue, showStatus: model.isStatus, showHeading: model.isHeading)
        return cell
    }
}
