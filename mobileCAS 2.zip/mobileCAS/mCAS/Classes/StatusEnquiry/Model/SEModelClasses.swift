//
//  SEModelClasses.swift
//  mCAS
//
//  Created by iMac on 13/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import Foundation

class SEModelClasses {
    
    struct ApplicantDetailModel {
        var name : String?
        var role : String?
        var image : String?
        var data : StatusEnquiryRecords!
    }
    
    struct StatusEnquiryRecords: Codable {
        let applicants : [Applicant]?
        let loanDetail : LoanDetail?
        let neoReferenceNumber : String?
        let stages : String?
        let currentStage : CurrentStage?
    }
    
    struct Applicant: Codable {
        let applicantRole : ApplicantRole?
        let customerType : CustomerType?
        let salutation : Salutation?
        let firstName : String?
        let middleName : String?
        let lastName : String?
        let emailAddress : String?
        let dateOfBirth : String?
        let gender : Gender?
        let maritalStatus : MaritalStatus?
        let mobileNumber : String?
        let customerCategory : CustomerCategory?
        let phoneNumber : String?
        let numOfDependents : Int?
        let nationality : Nationality?
        let identificationDetails : [IdentificationDetails]?
        let addressDetails : [AddressDetails]?
        let employmentDetails : [EmploymentDetails]?
        
        let institutionName : String?
        let name : String?
        let applicantType : ApplicantType?
        
        
        func getFullName() -> String {
            var name = ""

            if self.customerType?.code == Constants.CUSTOMER_TYPE_CORP || self.applicantType?.code == Constants.CUSTOMER_TYPE_CORP {
                if let instName = self.institutionName {
                    name = instName
                }
            }
            else {
                if let fName = self.firstName {
                    name = fName
                }
                if let mName = self.middleName {
                    name = "\(name) \(mName)"
                }
                if let lName = self.lastName {
                    name = "\(name) \(lName)"
                }
            }
            
            return name.capitalized
        }
    }
    
    struct LoanDetail: Codable {
        let loanAmount : Int?
        let loanAmountApproved : Int?
        let productType : ProductType?
        let product : Product?
        let currency : Currency?
        let scheme : Scheme?
        let branch : Branch?
        let tenure : Int?
        let tenureApproved : Int?
        let applicationType : ApplicationType?
    }
    
    struct CurrentStage: Codable {
        let code : String?
        let name : String?
    }
    
    struct ApplicantRole: Codable {
        let code : String?
        let name : String?
    }
    
    struct CustomerType: Codable {
        let code : String?
        let name : String?
    }
    
    struct Salutation: Codable {
        let code : String?
        let name : String?
    }
    
    struct Gender: Codable {
        let code : String?
        let name : String?
    }
    
    struct MaritalStatus: Codable {
        let code : String?
        let name : String?
    }
    
    struct CustomerCategory: Codable {
        let code : String?
        let name : String?
    }
    
    struct Nationality: Codable {
        let code : String?
        let name : String?
    }
    
    struct Branch: Codable {
        let code : String?
        let name : String?
    }
    
    struct City: Codable {
        let code : String?
        let name : String?
    }
    struct Country: Codable {
        let code : String?
        let name : String?
    }
    struct Currency: Codable {
        let code : String?
        let name : String?
    }
    
    struct State: Codable {
        let code : String?
        let name : String?
    }
    
    struct IdentificationDetails: Codable {
        let identificationType : IdentificationType?
        let identificationValue : String?
        let issueDate : String?
        let expiryDate : String?
        let issuingCountry : IssuingCountry?
        let attemptsDone : Int?
    }
    
    struct AddressDetails: Codable {
        let fullAddress : String?
        let landmark : String?
        let communicationAddress : Bool?
        let addressType : AddressType?
        let state : State?
        let city : City?
        let country : Country?
        let postalCode : PostalCode?
        let residentialStatus : ResidentialStatus?
        let numberOfYearsAtAddress : Int?
        let numberOfMonthsAtAddress : Int?
        let numberOfYearsAtCity : Int?
        let numberOfMonthsAtCity : Int?
        let sameAsOfficeAddr : Bool?
        let sameAsPermanentAddr : Bool?
        let sameAsResidentialAddr : Bool?
    }
    
    struct EmploymentDetails: Codable {
        let employmentType : EmploymentType?
        let joiningDate : String?
        let employerName : EmployerName?
        let majorOccupation : Bool?
        let natureOfBusiness : NatureOfBusiness?
    }
    
    struct ResidentialStatus: Codable {
        let code : String?
        let name : String?
    }
    
    struct AddressType: Codable {
        let code : String?
        let name : String?
    }
    
    struct ApplicationType: Codable {
        let code : String?
        let name : String?
    }
    
    struct EmployerName: Codable {
        let name : String?
    }
    
    struct EmploymentType: Codable {
        let code : String?
        let name : String?
    }
    
    struct IdentificationType: Codable {
        let code : String?
        let name : String?
    }
    
    struct IssuingCountry: Codable {
        let code : String?
        let name : String?
    }
    
    struct NatureOfBusiness: Codable {
        let code : String?
        let name : String?
    }
    
    struct PostalCode: Codable {
        let code : String?
        let name : String?
    }
    
    struct Product: Codable {
        let code : String?
        let name : String?
    }
    
    struct ProductType: Codable {
        let code : String?
        let name : String?
    }
    
    struct Scheme: Codable {
        let code : String?
        let name : String?
    }
    
    //Third party response
    
    struct ApplicantAdditionalDetails: Codable  {
        let requestReferenceNumber : String?
        let productProcessor : String?
        let applicationNumber : String?
        let applicationStatus : String?
        let productCode : String?
        let productType : String?
        let schemeCode : String?
        let fraudResponse : [FraudResponse]?
        let creditPolicyResponse : CreditPolicyResponse?
        let creditBureauResponse : CreditBureauResponse?
        let fieldInvestigationResponse : FieldInvestigationResponse?
        let collateralVerificationResponse : [CollateralVerificationResponse]?
        let creditScoreResponse : CreditScoreResponse?
        let eligibilityResponse : EligibilityResponse?
    }
    
    struct FraudResponse: Codable {
        let applicantInfo : ApplicantInfo?
        let fraudInterfaceResult : [FraudInterfaceResult]?
    }
    
    struct FraudInterfaceResult: Codable {
        let fraudInterfaceName : String?
        let serviceExecuted : String?
        let fraudResponseStatus : String?
        let fraudStatusDescription : String?
    }
    
    struct CreditPolicyResponse: Codable {
        let policyResult : String?
        let policyCode : String?
        let policyName : String?
        let executionStatus : String?
    }
    
    struct CreditBureauResponse: Codable {
        let bureauResult : String?
        let executionStatus : String?
        let bureauResponseRecords : [BureauResponseRecords]?
    }
    
    struct FieldInvestigationResponse: Codable {
        let executionStatus : String?
        let customerFIRecords : [CustomerFIRecords]?
    }
    
    struct CollateralVerificationResponse: Codable {
        let verificationStatus : String?
        let verificationDate : String?
        let valuationStatus : String?
        let valuationDate : String?
        let collateralType : String?
        let collateralSubType : String?
        let collateralNumber : String?
        let collateralReferenceNumber : String?
    }
    
    struct CreditScoreResponse: Codable {
        let scoringCriteria : String?
        let scoreValue : String?
        let executionStatus : String?
        let customerCreditScores : [CustomerCreditScores]?
    }
    
    struct EligibilityResponse: Codable {
        let recommendedLimit : RecommendedLimit?
        let applicantName : String?
        let customerType : String?
        let criteria : String?
        let eligibilitySetName : String?
        let executionStatus : String?
    }
    
    struct ApplicantInfo: Codable {
        let customerNumber : String?
        let customerType : String?
        let applicantFirstName : String?
        let applicantMiddleName : String?
        let applicantLastName : String?
    }
    
    struct BureauResponseRecords: Codable {
        let customerNumber : String?
        let bureauCode : String?
        let applicantName : String?
        let applicantRole : String?
        let matchFound : Bool?
        let responseStatus : String?
    }
    
    struct CustomerFIRecords: Codable {
        let applicantName : String?
        let applicantRole : String?
        let waivedOff : Bool?
        let customerFIEntries : [String]?
    }
    
    struct CustomerCreditScores: Codable {
        let applicantName : String?
        let applicantRole : String?
        let scoreCardName : String?
        let scoreValue : String?
    }
    
    struct RecommendedLimit: Codable {
        let name : String?
    }
    
    struct ApplicationStatusList: Codable {
        let applicant : Applicant?
        let loanDetail : LoanDetail?
        let neoReferenceNumber : String?
    }
    
    struct DocumentDetails: Codable {
        let name : String?
        let external : Bool?
        let casDocReferenceId : String?
        let applicant : Applicant?
        let category : String?
        let isGroupDoc : Bool?
        let mandatory : Bool?
        let originalRecord : Bool?
        let captured : Bool?
        let recieved : Bool?
    }
    
    struct ApplicantType: Codable {
        let code : String?
        let name : String?
    }
}
