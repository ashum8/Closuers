//
//  UserDetailVC.swift
//  mCAS
//
//  Created by iMac on 27/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

struct UserDetail  {
    let title: String
    let imageName: String
}

class UserDetailVC: UIViewController {
    
    @IBOutlet weak var userDetailView: UIView!
    @IBOutlet weak var userDetailStackView: UIStackView!
    @IBOutlet weak var userDetailViewHeight: NSLayoutConstraint!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    
    private var userDetailArray: [UserDetail] = []
    private var listModelArray: [KeyValueModel] = []
    private var applicantTitleLabel: EdgeInsetLabel = EdgeInsetLabel()
    private var dataObj: SEModelClasses.StatusEnquiryRecords!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setApplicantLabelProperties(title: "Primary Applicant")
        addSubviews()
        setUpTableViewData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            
            if let applicants = dataObj.applicants, !applicants.isEmpty {
                headerView.setTitleWith(line1: applicants[0].getFullName(), showBack: true)
            }
            
            addApplicantLabel(view: headerView)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        applicantTitleLabel.removeFromSuperview()
    }
    
    func setDate(data: SEModelClasses.StatusEnquiryRecords) {
        self.dataObj = data
    }
    
    private func setApplicantLabelProperties(title: String) {
        applicantTitleLabel.setEdgeInsets()
        applicantTitleLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        applicantTitleLabel.text = title
        applicantTitleLabel.textColor = .darkGray
        applicantTitleLabel.backgroundColor = .white
        applicantTitleLabel.setCornerRadius()
        applicantTitleLabel.layer.masksToBounds = true
    }
    
    private func addApplicantLabel(view: UIView) {
        let topPadding = AppDelegate.instance.getTopPadding()
        let yCord = topPadding + (view.frame.size.height - topPadding - 25)/2
        let width = applicantTitleLabel.text!.widthOfString(usingFont: applicantTitleLabel.font)
        applicantTitleLabel.frame = CGRect(x: view.frame.size.width - width - 20, y: yCord, width: width + 10, height: 25)
        view.addSubview(applicantTitleLabel)
    }
    
    private func addSubviews() {
        if let applicantArr = dataObj.applicants {
            
            for item in applicantArr {
                userDetailArray.append(UserDetail(title: (item.gender?.name)!, imageName: "gender_icon"))
                userDetailArray.append(UserDetail(title: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: item.dateOfBirth), imageName: "birthday_icon"))
                userDetailArray.append(UserDetail(title: item.mobileNumber ?? "", imageName: "cell_phone_icon"))
                
                if let addressObj = item.addressDetails, !addressObj.isEmpty {
                    userDetailArray.append(UserDetail(title: (addressObj[0].fullAddress)!, imageName: "address_icon"))
                }
            }
            
            userDetailViewHeight.constant = CGFloat(userDetailArray.count*38)
            
            for (_, item) in userDetailArray.enumerated() {
                let view = CustomUserDetailView()
                view.setProperties(title:item.title, imageName: item.imageName)
                userDetailStackView.addArrangedSubview(view)
            }
        }
    }
    
    func setUpTableViewData() {
        tableView.register(UINib(nibName: "LoanDetailTableViewCell", bundle: nil), forCellReuseIdentifier: "LoanDetailTableViewCell")
        
        if let applicantArr = dataObj.applicants {
            
            for item in applicantArr {
                listModelArray.append(KeyValueModel(fieldName: "Customer Name", fieldValue: item.getFullName()))
                listModelArray.append(KeyValueModel(fieldName: "Father's Name", fieldValue: ""))
                listModelArray.append(KeyValueModel(fieldName: "Mother's Maiden Name", fieldValue: ""))
                listModelArray.append(KeyValueModel(fieldName: "Marital Status", fieldValue: CommonUtils.shared().getValidatedString(string: item.maritalStatus?.name)))
                listModelArray.append(KeyValueModel(fieldName: "No. Of Dependants", fieldValue: "0"))
                listModelArray.append(KeyValueModel(fieldName: "Category", fieldValue: CommonUtils.shared().getValidatedString(string: item.customerCategory?.name)))
                listModelArray.append(KeyValueModel(fieldName: "Citizenship", fieldValue: (item.nationality?.name)!))
                
                if let addressObj = item.addressDetails, !addressObj.isEmpty {
                    listModelArray.append(KeyValueModel(fieldName: "Residential Status", fieldValue: CommonUtils.shared().getValidatedString(string: addressObj[0].residentialStatus?.name)))
                }
                
                listModelArray.append(KeyValueModel(fieldName: "Email ID", fieldValue: item.emailAddress!))
                listModelArray.append(KeyValueModel(fieldName: "Mobile Number", fieldValue: item.mobileNumber!))
                listModelArray.append(KeyValueModel(fieldName: "Phone Number", fieldValue: item.phoneNumber!))
                listModelArray.append(KeyValueModel(fieldName: "Perferred Language", fieldValue: ""))
                
                if let identityObj = item.identificationDetails {
                    
                    let ids = identityObj.map({$0.identificationType?.name ?? ""}).joined(separator: ", ")
                    listModelArray.append(KeyValueModel(fieldName: "ID's Added", fieldValue: ids))
                    
                    listModelArray.append(contentsOf: identityObj.map({ KeyValueModel(fieldName: ($0.identificationType?.name)!, fieldValue: $0.identificationValue!) }))
                }
                
                if let empObj = item.employmentDetails {
                    for item in empObj {
                        listModelArray.append(KeyValueModel(fieldName: "Employment Type", fieldValue: CommonUtils.shared().getValidatedString(string:item.employmentType?.name)))
                        listModelArray.append(KeyValueModel(fieldName: "Employer Name", fieldValue: CommonUtils.shared().getValidatedString(string:item.employerName?.name)))
                        listModelArray.append(KeyValueModel(fieldName: "Employed From", fieldValue: CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: item.joiningDate)))
                    }
                }
                
                if let addressObj = item.addressDetails {
                    listModelArray.append(contentsOf: addressObj.map({ KeyValueModel(fieldName: CommonUtils.shared().getValidatedString(string:$0.addressType?.name), fieldValue: $0.fullAddress!) }))
                }
            }
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
}

extension UserDetailVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "LoanDetailTableViewCell", for: indexPath) as! LoanDetailTableViewCell
        cell.setProperties(title: "Details", arrList: self.listModelArray)
        tableViewHeight.constant = cell.tableView.contentSize.height + 80
        return cell
    }
}
