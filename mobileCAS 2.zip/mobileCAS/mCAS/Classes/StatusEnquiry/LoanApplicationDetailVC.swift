//
//  LoanApplicationDetailVC.swift
//  mCAS
//
//  Created by iMac on 24/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//


import UIKit


class LoanApplicationDetailVC: UIViewController {
    
    let SECTION_APPLICATION = "APPLICATION"
    let SECTION_APPLICANT = "APPLICANT"
    let SECTION_ELIGIBILITY = "ELIGIBILITY"
    let SECTION_CREDIT_POLICY = "CREDIT_POLICY"
    let SECTION_CREDIT_BUREAU = "CREDIT_BUREAU"
    let SECTION_CREDIT_SCORE = "CREDIT_SCORE"
    let SECTION_COLLATERAL = "COLLATERAL"
    let SECTION_FRAUD = "FRAUD"
    let SECTION_FIELD_INVESTIGTION = "FIELD_INVESTIGTION"
    let SECTION_BUTTON = "BUTTON"
    
    @IBOutlet weak var tableView: UITableView!
    
    private var dataObj: SEModelClasses.StatusEnquiryRecords!
    
    private var applicationDataModelArray: [KeyValueModel] = []
    private var eligibilityModelArray: [KeyValueModel] = []
    private var CPResponseModelArray: [KeyValueModel] = []
    private var CBResponseModelArray: [KeyValueModel] = []
    private var CSResponseModelArray: [KeyValueModel] = []
    private var CollateralModelArray: [KeyValueModel] = []
    private var fraudModelArray: [KeyValueModel] = []
    private var fivModelArray: [KeyValueModel] = []
    
    private var applicantsModelArray: [SEModelClasses.ApplicantDetailModel] = []
    private var tableSectionArray: [MenuModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        tableView.register(UINib(nibName: "ApplicantsListTableViewCell", bundle: nil), forCellReuseIdentifier: "ApplicantsListTableViewCell")
        tableView.register(UINib(nibName: "ButtonTableViewCell", bundle: nil), forCellReuseIdentifier: "ButtonTableViewCell")
        
        setMainData()
        fetchThirdPartyResponse()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "Application Details", showBack: true)
        }
    }
    
    func setDate(data: SEModelClasses.StatusEnquiryRecords) {
        self.dataObj = data
    }
    
    private func setMainData() {
        tableSectionArray.append(MenuModel(title: dataObj.neoReferenceNumber!, menuID: SECTION_APPLICATION))
        tableSectionArray.append(MenuModel(title: "Applicants", menuID: SECTION_APPLICANT))
        
        if let loanObj = dataObj.loanDetail {
            applicationDataModelArray.append(KeyValueModel(fieldName: "Product", fieldValue: CommonUtils.shared().getValidatedString(string: loanObj.productType?.name)))
            applicationDataModelArray.append(KeyValueModel(fieldName: "Product Category", fieldValue: CommonUtils.shared().getValidatedString(string: loanObj.product?.name)))
            applicationDataModelArray.append(KeyValueModel(fieldName: "Scheme", fieldValue: CommonUtils.shared().getValidatedString(string: loanObj.scheme?.name)))
            applicationDataModelArray.append(KeyValueModel(fieldName: "Type", fieldValue: CommonUtils.shared().getValidatedString(string: loanObj.applicationType?.name)))
            applicationDataModelArray.append(KeyValueModel(fieldName: "Status", fieldValue: CommonUtils.shared().getValidatedString(string: dataObj.currentStage?.name), isStatus: true))
            applicationDataModelArray.append(KeyValueModel(fieldName: "Stage", fieldValue: CommonUtils.shared().getValidatedString(string: dataObj.stages)))
            applicationDataModelArray.append(KeyValueModel(fieldName: "Branch", fieldValue: CommonUtils.shared().getValidatedString(string: loanObj.branch?.name)))
            applicationDataModelArray.append(KeyValueModel(fieldName: "Loan Amount Requested", fieldValue: "\(loanObj.loanAmount!)".formatCurrency))
            applicationDataModelArray.append(KeyValueModel(fieldName: "Tenure Requested (months)", fieldValue: "\(loanObj.tenure!)"))
        }
        
        if let applicants = dataObj.applicants {
            applicantsModelArray = applicants.map({
                SEModelClasses.ApplicantDetailModel(name: $0.getFullName(), role: $0.applicantRole?.name, image: "", data: dataObj)
            })
        }
    }
    
    private func setThirdPartyData(thirdPartyData: SEModelClasses.ApplicantAdditionalDetails) {
        
        if let eligibilityObj = thirdPartyData.eligibilityResponse {
            
            tableSectionArray.append(MenuModel(title: "Eligibility Response", menuID: SECTION_ELIGIBILITY))
            
            eligibilityModelArray.append(KeyValueModel(fieldName: "Applicant Name", fieldValue: CommonUtils.shared().getValidatedString(string: eligibilityObj.applicantName)))
            eligibilityModelArray.append(KeyValueModel(fieldName: "Customer Type", fieldValue: CommonUtils.shared().getValidatedString(string: eligibilityObj.customerType)))
            eligibilityModelArray.append(KeyValueModel(fieldName: "Criteria", fieldValue: CommonUtils.shared().getValidatedString(string: eligibilityObj.criteria)))
            eligibilityModelArray.append(KeyValueModel(fieldName: "Eligibility Set Name", fieldValue: CommonUtils.shared().getValidatedString(string: eligibilityObj.eligibilitySetName)))
            eligibilityModelArray.append(KeyValueModel(fieldName: "Recommended Limit", fieldValue: CommonUtils.shared().getValidatedString(string: eligibilityObj.recommendedLimit?.name)))
        }
        
        if let creditObj = thirdPartyData.creditPolicyResponse {
            
            tableSectionArray.append(MenuModel(title: "Credit Policy Response", menuID: SECTION_CREDIT_POLICY))
            
            CPResponseModelArray.append(KeyValueModel(fieldName: "Credit Policy Name", fieldValue: CommonUtils.shared().getValidatedString(string: creditObj.policyName)))
            CPResponseModelArray.append(KeyValueModel(fieldName: "Credit Policy Code", fieldValue: CommonUtils.shared().getValidatedString(string: creditObj.policyCode)))
            CPResponseModelArray.append(KeyValueModel(fieldName: "Credit Policy Result", fieldValue: CommonUtils.shared().getValidatedString(string: creditObj.policyResult)))
            CPResponseModelArray.append(KeyValueModel(fieldName: "Credit Policy Status", fieldValue: CommonUtils.shared().getValidatedString(string: creditObj.executionStatus)))
        }
        
        if let creditBureauObj = thirdPartyData.creditBureauResponse {
            
            tableSectionArray.append(MenuModel(title: "Credit Bureau Response", menuID: SECTION_CREDIT_BUREAU))
            
            CBResponseModelArray.append(KeyValueModel(fieldName: "Bureau Result", fieldValue: CommonUtils.shared().getValidatedString(string: creditBureauObj.bureauResult)))
            
            if let bureauObj = creditBureauObj.bureauResponseRecords {
                
                for item in bureauObj {
                    CBResponseModelArray.append(KeyValueModel(fieldName: "", fieldValue: CommonUtils.shared().getValidatedString(string: item.bureauCode), isHeading: true))
                    CBResponseModelArray.append(KeyValueModel(fieldName: "Customer Number", fieldValue: CommonUtils.shared().getValidatedString(string: item.customerNumber)))
                    CBResponseModelArray.append(KeyValueModel(fieldName: "Bureau Code", fieldValue: CommonUtils.shared().getValidatedString(string: item.bureauCode)))
                    CBResponseModelArray.append(KeyValueModel(fieldName: "Score", fieldValue: ""))
                    CBResponseModelArray.append(KeyValueModel(fieldName: "Applicant Name", fieldValue: CommonUtils.shared().getValidatedString(string: item.applicantName)))
                    CBResponseModelArray.append(KeyValueModel(fieldName: "Applicant Role", fieldValue: CommonUtils.shared().getValidatedString(string: item.applicantRole)))
                    CBResponseModelArray.append(KeyValueModel(fieldName: "Match Found", fieldValue: String(item.matchFound!)))
                    CBResponseModelArray.append(KeyValueModel(fieldName: "Response Status", fieldValue: CommonUtils.shared().getValidatedString(string: item.responseStatus)))
                }
            }
        }
        
        if let creditScoreObj = thirdPartyData.creditScoreResponse {
            
            tableSectionArray.append(MenuModel(title: "Credit Score Response", menuID: SECTION_CREDIT_SCORE))
            
            CSResponseModelArray.append(KeyValueModel(fieldName: "Score Criteria", fieldValue: CommonUtils.shared().getValidatedString(string: creditScoreObj.scoringCriteria)))
            CSResponseModelArray.append(KeyValueModel(fieldName: "Score Value", fieldValue: CommonUtils.shared().getValidatedString(string: creditScoreObj.scoreValue)))
            CSResponseModelArray.append(KeyValueModel(fieldName: "Execution Status", fieldValue: CommonUtils.shared().getValidatedString(string: creditScoreObj.executionStatus)))
            
            if let CSObj = creditScoreObj.customerCreditScores {
                
                CSResponseModelArray.append(KeyValueModel(fieldName: "", fieldValue: "Customer Credit Score", isHeading: true))
                
                for item in CSObj {
                    CSResponseModelArray.append(KeyValueModel(fieldName: "Applicant Name", fieldValue: CommonUtils.shared().getValidatedString(string: item.applicantName)))
                    CSResponseModelArray.append(KeyValueModel(fieldName: "Applicant Role", fieldValue: CommonUtils.shared().getValidatedString(string: item.applicantRole)))
                    CSResponseModelArray.append(KeyValueModel(fieldName: "Score Card Name", fieldValue: CommonUtils.shared().getValidatedString(string: item.scoreCardName)))
                    CSResponseModelArray.append(KeyValueModel(fieldName: "Score Value", fieldValue: CommonUtils.shared().getValidatedString(string: item.scoreValue)))
                }
            }
        }
        
        if let collateralObj = thirdPartyData.collateralVerificationResponse {
            
            tableSectionArray.append(MenuModel(title: "Collateral Verification Response", menuID: SECTION_COLLATERAL))
            
            for item in collateralObj {
                CollateralModelArray.append(KeyValueModel(fieldName: "", fieldValue: CommonUtils.shared().getValidatedString(string: item.collateralType), isHeading: true))
                CollateralModelArray.append(KeyValueModel(fieldName: "Verification Status", fieldValue: CommonUtils.shared().getValidatedString(string: item.verificationStatus)))
                CollateralModelArray.append(KeyValueModel(fieldName: "Verification Date", fieldValue: CommonUtils.shared().getValidatedString(string: item.verificationDate)))
                CollateralModelArray.append(KeyValueModel(fieldName: "Valuation Status", fieldValue: CommonUtils.shared().getValidatedString(string: item.valuationStatus)))
                CollateralModelArray.append(KeyValueModel(fieldName: "Valuation Date", fieldValue: CommonUtils.shared().getValidatedString(string: item.valuationDate)))
                CollateralModelArray.append(KeyValueModel(fieldName: "Collateral Type", fieldValue: CommonUtils.shared().getValidatedString(string: item.collateralType)))
                CollateralModelArray.append(KeyValueModel(fieldName: "Collateral Number", fieldValue: CommonUtils.shared().getValidatedString(string: item.collateralNumber)))
                CollateralModelArray.append(KeyValueModel(fieldName: "Collateral Ref Number", fieldValue: CommonUtils.shared().getValidatedString(string: item.collateralReferenceNumber)))
                CollateralModelArray.append(KeyValueModel(fieldName: "Collateral Sub Type", fieldValue: CommonUtils.shared().getValidatedString(string: item.collateralSubType)))
                CollateralModelArray.append(KeyValueModel(fieldName: "Accepted value", fieldValue: ""))
            }
        }
        
        if let fraudObj = thirdPartyData.fraudResponse {
            
            tableSectionArray.append(MenuModel(title: "Fraud Response", menuID: SECTION_FRAUD))
            
            for item in fraudObj {
                
                if let applicantObj = item.applicantInfo {
                    fraudModelArray.append(KeyValueModel(fieldName: "", fieldValue: CommonUtils.shared().getValidatedString(string: applicantObj.customerNumber), isHeading: true))
                    fraudModelArray.append(KeyValueModel(fieldName: "Customer Number", fieldValue: CommonUtils.shared().getValidatedString(string: applicantObj.customerNumber)))
                    fraudModelArray.append(KeyValueModel(fieldName: "Customer Type", fieldValue: CommonUtils.shared().getValidatedString(string: applicantObj.customerType)))
                    fraudModelArray.append(KeyValueModel(fieldName: "Institution Name", fieldValue: ""))
                    fraudModelArray.append(KeyValueModel(fieldName: "Applicant Name", fieldValue: "\(CommonUtils.shared().getValidatedString(string: applicantObj.applicantFirstName)) \(CommonUtils.shared().getValidatedString(string: applicantObj.applicantMiddleName)) \(CommonUtils.shared().getValidatedString(string: applicantObj.applicantLastName))".capitalized))
                }
                
                if let fInterfaceObj = item.fraudInterfaceResult {
                    for item in fInterfaceObj {
                        fraudModelArray.append(KeyValueModel(fieldName: "", fieldValue: CommonUtils.shared().getValidatedString(string: item.fraudInterfaceName), isHeading: true))
                        fraudModelArray.append(KeyValueModel(fieldName: "Interface Name", fieldValue: CommonUtils.shared().getValidatedString(string: item.fraudInterfaceName)))
                        fraudModelArray.append(KeyValueModel(fieldName: "Fraud Message", fieldValue: ""))
                        fraudModelArray.append(KeyValueModel(fieldName: "Status Change Date", fieldValue: ""))
                        fraudModelArray.append(KeyValueModel(fieldName: "Response Status", fieldValue: CommonUtils.shared().getValidatedString(string: item.fraudResponseStatus)))
                        fraudModelArray.append(KeyValueModel(fieldName: "Status Description", fieldValue: CommonUtils.shared().getValidatedString(string: item.fraudStatusDescription)))
                    }
                }
            }
        }
        
        if let fiResponse = thirdPartyData.fieldInvestigationResponse {
            
            tableSectionArray.append(MenuModel(title: "Field Investigation Response", menuID: SECTION_FIELD_INVESTIGTION))
            
            fivModelArray.append(KeyValueModel(fieldName: "Verification Status", fieldValue: ""))
            fivModelArray.append(KeyValueModel(fieldName: "Verification Status Date", fieldValue: ""))
            
            if let customerObj = fiResponse.customerFIRecords {
                for item in customerObj {
                    fivModelArray.append(KeyValueModel(fieldName: "", fieldValue: item.applicantName!, isHeading: true))
                    fivModelArray.append(KeyValueModel(fieldName: "Applicant Role", fieldValue: item.applicantRole!))
                    fivModelArray.append(KeyValueModel(fieldName: "Waived Off", fieldValue: String(item.waivedOff!)))
                }
            }
        }
        
        self.reloadTable()
    }
    
    private func reloadTable() {
        tableSectionArray.append(MenuModel(title: "Add/View Documents", menuID: SECTION_BUTTON))
        self.tableView.reloadData()
        
        //Reload again to set frames properly on first time view load
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    private func fetchThirdPartyResponse() {
        
        let params = ["applicationId" : dataObj.neoReferenceNumber!]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_CASE_DETAIL_SE_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String: Any]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: SEModelClasses.ApplicantAdditionalDetails.self) { list in
                    self.setThirdPartyData(thirdPartyData: list)
                }
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            self.reloadTable()
            
        }, noNetwork: { (error) in
            
            self.reloadTable()
        })
    }
}

extension LoanApplicationDetailVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return tableSectionArray.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let menu: MenuModel = tableSectionArray[indexPath.section]
        
        if(menu.menuID == SECTION_APPLICANT) {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ApplicantsListTableViewCell") as! ApplicantsListTableViewCell
            cell.setProperties(title: menu.title + " (\(applicantsModelArray.count))", list: applicantsModelArray)
            return cell
        }
        else if(menu.menuID == SECTION_BUTTON) {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ButtonTableViewCell") as! ButtonTableViewCell
            cell.setProperties(title: menu.title, delegate: self)
            return cell
        }
        else {
            if menu.menuID == SECTION_APPLICATION {
                return self.setCellData(menu: menu, list: self.applicationDataModelArray)
            }
            else if menu.menuID == SECTION_ELIGIBILITY {
                return self.setCellData(menu: menu, list: self.eligibilityModelArray)
            }
            else if menu.menuID == SECTION_CREDIT_POLICY {
                return self.setCellData(menu: menu, list: self.CPResponseModelArray)
            }
            else if(menu.menuID == SECTION_CREDIT_BUREAU) {
                return self.setCellData(menu: menu, list: self.CBResponseModelArray)
            }
            else if(menu.menuID == SECTION_CREDIT_SCORE) {
                return self.setCellData(menu: menu, list: self.CSResponseModelArray)
            }
            else if(menu.menuID == SECTION_COLLATERAL) {
                return self.setCellData(menu: menu, list: self.CollateralModelArray)
            }
            else if(menu.menuID == SECTION_FRAUD) {
                return self.setCellData(menu: menu, list: self.fraudModelArray)
            }
            else if(menu.menuID == SECTION_FIELD_INVESTIGTION) {
                return self.setCellData(menu: menu, list: self.fivModelArray)
            }
            
            return UITableViewCell()
        }
    }
    
    private func setCellData(menu: MenuModel, list: [KeyValueModel]) -> LoanDetailTableViewCell {
        let identifier = "LoanDetailTVCell_\(menu.menuID!)"
        var cell = tableView.dequeueReusableCell(withIdentifier: identifier) as? LoanDetailTableViewCell
        
        if cell == nil {
            tableView.register(UINib(nibName: "LoanDetailTableViewCell", bundle: nil), forCellReuseIdentifier: identifier)
            cell = tableView.dequeueReusableCell(withIdentifier: identifier) as? LoanDetailTableViewCell
        }
        
        cell!.setProperties(title: menu.title, arrList: list)
        return cell!
    }
}

extension LoanApplicationDetailVC: ButtonTVCDelegate {
    
    func buttonAction() {
        
        let storyboard = UIStoryboard.init(name: Storyboard.STATUS_ENQUIRY, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "ApplicantDocSearchVC") as? ApplicantDocSearchVC {
            vc.setDate(data: dataObj)
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
}
