//
//  ButtonTableViewCell.swift
//  mCAS
//
//  Created by iMac on 26/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

protocol ButtonTVCDelegate {
    func buttonAction()
}

class ButtonTableViewCell: UITableViewCell {
    @IBOutlet weak var button: UIButton!
    
    private var delegate: ButtonTVCDelegate?
    
    func setProperties(title: String, delegate: ButtonTVCDelegate) {
        button.setTitle(title, for: .normal)
        button.setButtonProperties()
        self.delegate = delegate
    }
    
    @IBAction func buttonAction(_ sender: Any) {
        delegate?.buttonAction()
    }
}
