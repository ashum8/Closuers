//
//  ApplicantDocSearchResultVC.swift
//  mCAS
//
//  Created by iMac on 14/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class ApplicantDocSearchResultVC: UIViewController {
    @IBOutlet weak var stageLOV: LOVFieldView!
    @IBOutlet weak var tableView: UITableView!
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var listModelArray = [SEModelClasses.DocumentDetails]()
    
    private let TAG_STAGE = 1000
    
    private var applicantType: String!
    private var applicationNumber: String!
    private var stage: String!
    private var fullName: String!
    private var referenceType: String!
    private var optionArray: [DropDown]!
    private var dataObj: SEModelClasses.StatusEnquiryRecords!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        stageLOV.setLOVProperties(title: "Stage", tag: TAG_STAGE, autoFillValue: stage, delegate: self, optionArray: optionArray)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            
            if let applicant = dataObj.applicants, !applicant.isEmpty {
                headerView.setTitleWith(line1: applicant[0].getFullName(), line2: dataObj.neoReferenceNumber!, showBack: true)
            }
        }
    }
    
    func setData(applicantType: String, applicationNumber: String, stage: String, fullName: String, referenceType: String, optionArray: [DropDown],data: SEModelClasses.StatusEnquiryRecords) {
        self.applicantType = applicantType
        self.applicationNumber = applicationNumber
        self.stage = stage
        self.fullName = fullName
        self.referenceType = referenceType
        self.optionArray = optionArray
        self.dataObj = data
    }
    
    private func fetchData() {
        
        let params = ["applicantType"           : applicantType,
                      "applicationNumber"       : applicationNumber,
                      "stage"                   : stage,
                      "fullName"                : fullName,
                      "referenceType"           : referenceType]
        
        self.listModelArray.removeAll()
        self.tableView.reloadData()
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_DOC_CHECKLIST_SE_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
            if let response = responseObj as? [[String: Any]]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: [SEModelClasses.DocumentDetails].self) { list in
                    self.listModelArray.append(contentsOf: list)
                    self.tableView.reloadData()
                }
                
            }
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
        })
    }
}

extension ApplicantDocSearchResultVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ApplicantDocumentsTVCell") as! ApplicantDocumentsTVCell
        
        cell.celltitleLabel.text = "Document \(indexPath.row)"
        cell.titleLabel1.text = "Original Reqd"
        cell.valueLabel1.text = listModelArray[indexPath.row].originalRecord ?? false ? "YES" : "NO"
        
        cell.titleLabel2.text = "Mandatory"
        cell.valueLabel2.text = listModelArray[indexPath.row].mandatory ?? false ? "YES" : "NO"
        
        if listModelArray[indexPath.row].captured ?? false {
            cell.titleLabel3.text = "Attachments"
            cell.valueLabel3.text = ""
            cell.setProperties(showAttachment: true)
        }
        else {
            cell.setProperties()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}


extension ApplicantDocSearchResultVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        stage = selectedObj.name
        fetchData()
    }
}
