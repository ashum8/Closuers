//
//  ApplicantDocumentsTVCell.swift
//  mCAS
//
//  Created by iMac on 19/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class ApplicantDocumentsTVCell: UITableViewCell {
    @IBOutlet weak var celltitleLabel: UILabel!
    @IBOutlet weak var titleLabel1: UILabel!
    @IBOutlet weak var titleLabel2: UILabel!
    @IBOutlet weak var titleLabel3: UILabel!
    @IBOutlet weak var valueLabel1: UILabel!
    @IBOutlet weak var valueLabel2: UILabel!
    @IBOutlet weak var valueLabel3: UILabel!
    @IBOutlet weak var replaceButton: UIButton!
    @IBOutlet weak var viewButton: UIButton!
    @IBOutlet weak var uploadButton: UIButton!
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var attachmentViewHeight: NSLayoutConstraint!
    @IBOutlet weak var separatorView: UIView!
    @IBOutlet weak var attachmentView: UIView!    
    
    func setProperties(showAttachment: Bool = false) {
        
        bgView.setShadow()
        bgView.setCornerRadius()
        attachmentView.layer.masksToBounds = true
        separatorView.backgroundColor = Color.LIGHTER_GRAY
        
        celltitleLabel.font = CustomFont.shared().GETFONT_MEDIUM(19)
        
        titleLabel1.font = CustomFont.shared().GETFONT_REGULAR(19)
        valueLabel1.font = CustomFont.shared().GETFONT_REGULAR(19)
        
        titleLabel2.font = CustomFont.shared().GETFONT_REGULAR(19)
        valueLabel2.font = CustomFont.shared().GETFONT_REGULAR(19)
        
        titleLabel3.font = CustomFont.shared().GETFONT_REGULAR(19)
        valueLabel3.font = CustomFont.shared().GETFONT_REGULAR(19)
        
        viewButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        viewButton.setTitleColor(Color.BLUE, for: .normal)
        
        replaceButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        replaceButton.setTitleColor(Color.BLUE, for: .normal)
        
        uploadButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        uploadButton.setTitleColor(Color.BLUE, for: .normal)
        
        if showAttachment {
            attachmentViewHeight.constant = 36
            uploadButton.isHidden = true
        }
        else {
            attachmentViewHeight.constant = 0
            uploadButton.isHidden = false
        }
    }
    
    @IBAction func uploadButtonAction(_ sender: Any) {
        
    }
    @IBAction func replaceButtonAction(_ sender: Any) {
        
    }
    @IBAction func viewButtonAction(_ sender: Any) {
        
    }
}
