//
//  ExternalSearchVC.swift
//  mCAS
//
//  Created by iMac on 13/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class ExternalSearchVC: UIViewController {
    
    @IBOutlet weak var appIdButton: UIButton!
    @IBOutlet weak var nameDOBButton: UIButton!
    @IBOutlet weak var idTypeButton: UIButton!
    @IBOutlet weak var applicationIDView: CustomTextFieldView!
    @IBOutlet weak var applicationIDViewHeight: NSLayoutConstraint!
    @IBOutlet weak var dobView: CustomTextFieldView!
    @IBOutlet weak var dobViewHeight: NSLayoutConstraint!
    @IBOutlet weak var identificationTypeLOV: LOVFieldView!
    @IBOutlet weak var identificationTypeLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var idNumberView: CustomTextFieldView!
    @IBOutlet weak var idNumberViewHeight: NSLayoutConstraint!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private let TAG_IDTYPE = 1000
    private var selectedLOVDic: [String: DropDown] = [:]
    private var listModelArray = [SEModelClasses.StatusEnquiryRecords]()
    private var optionArray = [DropDown]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.showHideWhiteHeader(isHide: false, title: "Search External")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader()
        }
    }
    
    private func setupView() {
        
        appIdButton.sendActions(for: .touchUpInside)

        CoreDataOperations.shared().fetchRecordsForMaster(masterName: Entity.ID_TYPE) { (records) in
            if let records = records {
                self.optionArray.append(contentsOf: records)
            }
        }
        optionArray.append(DropDown(code: ConstantCodes.ID_TYPE_CODE_MOBILE, name: ConstantCodes.ID_TYPE_NAME_MOBILE))
        
        identificationTypeLOV.setLOVProperties(title: "Identification Type", tag: TAG_IDTYPE, delegate: self, optionArray: optionArray)
        
        applicationIDView.setProperties(placeHolder: "Application ID", delegate: self)
        dobView.setProperties(placeHolder: "Date Of Birth", type: .DOB, delegate: self)
        idNumberView.setProperties(placeHolder: "ID Number", delegate: self)
        
        buttonView.setProperties(nextBtnTitle: "Search", delegate: self)
    }
    
    @IBAction func searchTypeButtonAction(_ sender: UIButton) {
        refreshFieldData()
        
        switch sender {
        case appIdButton:
            appIdButton.setSelectedSegmentButtonProperties()
            nameDOBButton.resetSegmentButtonProperties()
            idTypeButton.resetSegmentButtonProperties()
            applicationIDView.setFieldPlaceHolder(placeHolder: "Application ID")
            applicationIDViewHeight.constant = 65
            dobViewHeight.constant = 0
            identificationTypeLOVHeight.constant = 0
            idNumberViewHeight.constant = 0
            
        case nameDOBButton:
            appIdButton.resetSegmentButtonProperties()
            nameDOBButton.setSelectedSegmentButtonProperties()
            idTypeButton.resetSegmentButtonProperties()
            applicationIDView.setFieldPlaceHolder(placeHolder: "Customer Name")
            applicationIDViewHeight.constant = 65
            dobViewHeight.constant = 65
            identificationTypeLOVHeight.constant = 0
            idNumberViewHeight.constant = 0
            
        case idTypeButton:
            appIdButton.resetSegmentButtonProperties()
            nameDOBButton.resetSegmentButtonProperties()
            idTypeButton.setSelectedSegmentButtonProperties()
            applicationIDViewHeight.constant = 0
            dobViewHeight.constant = 0
            identificationTypeLOVHeight.constant = 65
            idNumberViewHeight.constant = 65
            
        default:
            break
        }
	
        validateFields()
    }
    
    private func refreshFieldData() {
        
        identificationTypeLOV.resetLOVWithMaster(list: self.optionArray)
        selectedLOVDic["\(TAG_IDTYPE)"] = nil
        applicationIDView.setFieldValue()
        dobView.setFieldValue()
        idNumberView.setFieldValue()
        idNumberView.hideKeyboard()
        dobView.hideKeyboard()
        applicationIDView.hideKeyboard()
    }
}

extension ExternalSearchVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        self.listModelArray.removeAll()

        var params: [String: Any] = [:]
        if appIdButton.isSelected {
            params = ["searchParameters" : ["applicationNumber" : applicationIDView.getFieldValue()]]
        }
        else if nameDOBButton.isSelected {
            params = ["searchParameters" : ["fullName"      : applicationIDView.getFieldValue(),
                                            "applicantDOB"  : dobView.getFieldValue()]]
        }
        else if idTypeButton.isSelected {
            params = ["searchParameters" : ["identificationDetail" : ["identificationValue"    : idNumberView.getFieldValue(),
                                                                      "identificationType"     : ["code": selectedLOVDic["\(TAG_IDTYPE)"]?.code]]]]
        }
        
        Webservices.shared().POST(urlString: ServiceUrl.SEARCH_CASES_SE_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [[String: Any]]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: [SEModelClasses.StatusEnquiryRecords].self) { list in
                    self.listModelArray.append(contentsOf: list)
                    
                    let storyboard = UIStoryboard.init(name: Storyboard.STATUS_ENQUIRY, bundle: nil)
                    
                    if let vc = storyboard.instantiateViewController(withIdentifier: "ExternalSearchResultVC") as? ExternalSearchResultVC {
                        vc.setData(arr: self.listModelArray)
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                }
            }
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            
        })
    }
}

extension ExternalSearchVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        
        if appIdButton.isSelected {
            isEnabled = !applicationIDView.getFieldValue().isEmpty
        }
        else if nameDOBButton.isSelected {
            isEnabled = !(applicationIDView.getFieldValue().isEmpty || dobView.getFieldValue().isEmpty)
        }
        else if idTypeButton.isSelected {
            isEnabled = !(selectedLOVDic["\(TAG_IDTYPE)"] == nil || idNumberView.getFieldValue().isEmpty)
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        if appIdButton.isSelected {
            return text.isAlphanumeric && text.count <= Constants.APPLICATION_ID_LENGTH
        }
        else if nameDOBButton.isSelected {
            return text.isAlphanumericAndSpace
        }
        else if idTypeButton.isSelected {
            
            if let selectedObj = selectedLOVDic["\(TAG_IDTYPE)"]
            {
                if selectedObj.code == ConstantCodes.ID_TYPE_AADHAR {
                    return text.isNumeric && text.count <= Constants.AADHAR_LENGTH
                }
                else if selectedObj.code == ConstantCodes.ID_TYPE_PAN {
                    return text.isAlphanumeric && text.count <= Constants.PAN_LENGTH
                }
                else if selectedObj.code == ConstantCodes.ID_TYPE_CODE_MOBILE {
                    return text.isNumeric && text.count <= Constants.MOBILE_NUMBER_LENGTH
                }
            }
            return text.isAlphanumeric
        }
        return text.isAlphanumeric
    }
}

extension ExternalSearchVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        idNumberView.setFieldPlaceHolder(placeHolder: "Enter \(selectedObj.name ?? "")")
        
        validateFields()
    }
}
