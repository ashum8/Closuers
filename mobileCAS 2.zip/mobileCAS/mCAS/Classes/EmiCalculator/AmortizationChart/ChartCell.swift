//
//  ChartCell.swift
//  mCAS
//
//  Created by iss on 28/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class ChartCell: UITableViewCell {
    
    @IBOutlet weak var srNumLabel: UILabel!
    @IBOutlet weak var principalLabel: UILabel!
    @IBOutlet weak var interestLabel: UILabel!
    @IBOutlet weak var outstandingLabel: UILabel!
    
    func setData(index: Int, chartData: CalculatorModelClasses.ChartModel?) {
        if index == 0 {
            self.backgroundColor = Color.LIGHTER_GRAY
            
            self.srNumLabel.font = CustomFont.shared().GETFONT_MEDIUM(16)
            self.principalLabel.font = CustomFont.shared().GETFONT_MEDIUM(16)
            self.interestLabel.font = CustomFont.shared().GETFONT_MEDIUM(16)
            self.outstandingLabel.font = CustomFont.shared().GETFONT_MEDIUM(16)
            
            self.srNumLabel.text = "Sr. No."
            self.principalLabel.text = "Principal"
            self.interestLabel.text = "Interest"
            self.outstandingLabel.text = "Outstanding"
        }
        else {
            if index % 2 == 0 {
                self.backgroundColor = Color.EXTREME_LIGHT_GRAY
            }
            else {
                self.backgroundColor = .clear
            }
            
            self.srNumLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
            self.principalLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
            self.interestLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
            self.outstandingLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
            
            self.srNumLabel.text = "\(index)"
            
            if let cData = chartData {
                self.principalLabel.text = String(cData.principalAmount).formatCurrency
                self.interestLabel.text = String(cData.interestAmount).formatCurrency
                self.outstandingLabel.text = String(cData.balanceAmount).formatCurrency
            }
        }
    }
}
