//
//  AmortizationChartVC.swift
//  mCAS
//
//  Created by iss on 27/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit
import Charts

class AmortizationChartVC: UIViewController {
    
    @IBOutlet weak var pieChartView: PieChartView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var monthlyEMIKeyLabel: UILabel!
    @IBOutlet weak var monthlyEMIValueLabel: UILabel!
    @IBOutlet weak var principalAmountKeyLabel: UILabel!
    @IBOutlet weak var principalAmountValueLabel: UILabel!
    @IBOutlet weak var totalInterestKeyLabel: UILabel!
    @IBOutlet weak var totalInterestValueLabel: UILabel!
    @IBOutlet weak var periodicInterestKeyLabel: UILabel!
    @IBOutlet weak var periodicInterestValueLabel: UILabel!
    @IBOutlet weak var totalAmountKeyLabel: UILabel!
    @IBOutlet weak var totalAmountValueLabel: UILabel!
    
    fileprivate var chartArray: [CalculatorModelClasses.ChartModel] = []
    
    var installmentLabelName: String!
    var tenureLoanType: String!
    var emiAmount: Double = 0
    var principalAmount: Double = 0
    var tenure: Double = 0
    var tenureInYears: Double = 0
    var ratePerAnnum: Double = 0
    var periodicInterest: Double = 0
    fileprivate var emailButton: UIButton!
    private var esv: EmailSendView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        tableView.tableFooterView = UIView(frame: .zero)
        
        monthlyEMIKeyLabel.text = installmentLabelName
        
        monthlyEMIKeyLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        principalAmountKeyLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        totalInterestKeyLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        periodicInterestKeyLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        totalAmountKeyLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        monthlyEMIValueLabel.font = CustomFont.shared().GETFONT_MEDIUM(18)
        principalAmountValueLabel.font = CustomFont.shared().GETFONT_MEDIUM(18)
        totalInterestValueLabel.font = CustomFont.shared().GETFONT_MEDIUM(18)
        periodicInterestValueLabel.font = CustomFont.shared().GETFONT_MEDIUM(18)
        totalAmountValueLabel.font = CustomFont.shared().GETFONT_MEDIUM(18)
        
        principalAmountValueLabel.textColor = Color.GREEN
        totalInterestValueLabel.textColor = Color.BLUE
        
        let totalAmount = emiAmount * tenure
        let totalInterest = totalAmount - principalAmount
        
        monthlyEMIValueLabel.text = String(emiAmount).formatCurrency
        principalAmountValueLabel.text = String(principalAmount).formatCurrency
        totalInterestValueLabel.text = String(totalInterest).formatCurrency
        periodicInterestValueLabel.text = String(format: "%.2f", periodicInterest)+"%"
        totalAmountValueLabel.text = String(totalAmount).formatCurrency
        
        if let headerView = AppDelegate.instance.headerView {
            let yCord = AppDelegate.instance.getTopPadding()
            let height = headerView.frame.size.height - yCord
            let margin: CGFloat = 5
            
            emailButton = UIButton(frame: CGRect(x: self.view.frame.size.width - (height+margin), y: yCord, width: height, height: height))
            emailButton.setImage(UIImage(named: "send_mail_icon"), for: .normal)
            emailButton.addTarget(self, action:#selector(emailButtonAction(_:)), for: .touchUpInside)
        }
        
        esv = .fromNib()
        esv.setProperties(delegate: self)
        self.view.addSubview(esv)
        esv.alpha = 0
        
        setChart(values: [principalAmount, totalInterest])
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        calculateEMIChart()
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.setTitleWith(line1: "Amortization Chart", showBack: true)
            headerView.addSubview(emailButton)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        emailButton.removeFromSuperview()
    }
    
    @objc func emailButtonAction(_ sender: UIButton) {
        if esv.alpha == 0 {
            esv.alpha = 1
        }
        else {
            esv.alpha = 0
            self.view.endEditing(true)
        }
    }
    
    func setChart(values: [Double]) {
        
        let dataEntries: [ChartDataEntry] = values.map { (value) -> ChartDataEntry in
            return PieChartDataEntry(value: value)
        }
        
        let set = PieChartDataSet(entries: dataEntries, label: "")
        set.drawIconsEnabled = false
        set.sliceSpace = 5
        set.colors = [Color.GREEN, Color.BLUE]
        set.selectionShift = 0
        
        let data = PieChartData(dataSet: set)
        data.setDrawValues(false)
        
        pieChartView.data = data
        pieChartView.holeRadiusPercent = 0.82
        pieChartView.legend.enabled = false
        pieChartView.rotationEnabled = false
        pieChartView.highlightPerTapEnabled = false
        pieChartView.usePercentValuesEnabled = false
        pieChartView.drawEntryLabelsEnabled = false
    }
    
    func calculateEMIChart() {
        let r = periodicInterest / 100
        let rPower = pow(1 + r, tenure)
        let monthlyPayment = principalAmount * r * rPower / (rPower - 1)
        var balance = principalAmount
        
        chartArray = []
        
        for i in 1...Int(tenure) {
            let interestPayment = balance * r
            let principalPayment = monthlyPayment - interestPayment
            balance -= principalPayment
            
            if i == Int(tenure), balance < 0 { balance = 0 }
            
            chartArray.append(CalculatorModelClasses.ChartModel(principalAmount: principalPayment, interestAmount: interestPayment, balanceAmount: balance))
        }
    }
}

extension AmortizationChartVC: EmailSendViewDelegate {
    func callEmailService(toEmail: String, ccEmail: String) {
        
        let param : [String:Any] = ["originalPrincipalAmount"  :String(principalAmount),
                                    "tenureInYears"            :String(format: "%.2f", tenureInYears),
                                    "tenureLoanType"           :tenureLoanType ?? "",
                                    "annualInterest"           :ratePerAnnum,
                                    "mailTo"                   :toEmail,
                                    "mailCc"                   :ccEmail]
        
        Webservices.shared().POST(urlString: ServiceUrl.EMAIL_AMORTIZATION_SCHEDULE_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            CommonAlert.shared().showAlert(message: NSLocalizedString("Email sent successfully", comment: ""))
            self.emailButtonAction(self.emailButton)
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in })
    }
}

extension AmortizationChartVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chartArray.count+1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChartCell", for: indexPath as IndexPath) as! ChartCell
        
        if indexPath.row == 0 {
            cell.setData(index: indexPath.row, chartData: nil)
        }
        else {
            cell.setData(index: indexPath.row, chartData: chartArray[indexPath.row-1])
        }
        
        return cell
    }
}
