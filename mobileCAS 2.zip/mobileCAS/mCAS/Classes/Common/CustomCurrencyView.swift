//
//  CustomCurrencyView.swift
//  mCAS
//
//  Created by iMac on 24/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class CustomCurrencyView: UIView {
    
    @IBOutlet weak var currencyLOV: LOVFieldView!
    @IBOutlet weak var amountTFView: CustomTextFieldView!
    @IBOutlet var containerView: UIView!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomCurrencyView", owner: self, options: nil)
        containerView.fixInView(self)
    }
    
    func setProperties(tag:Int, delegate: SelectedLOVDelegate, optionArray: [DropDown], removeTopMargin: Bool = false, preFillValue: String = "") {
        
        var lovAutoFillValue = ""
        var amountTFValue = ""
        if !preFillValue.isEmpty, preFillValue.contains("~") {
            let arr = preFillValue.split(separator: "~")
            if !arr.isEmpty {
                lovAutoFillValue = String(arr[0])
                amountTFValue = String(arr[1])
            }
        }
        
        amountTFView.setProperties(placeHolder: "Enter Value", type: .Number, delegate: self, removeTopMargin: removeTopMargin)
        amountTFView.setFieldValue(text: amountTFValue)
        currencyLOV.setLOVProperties(title: "Currency Code", tag: tag, autoFillValue: lovAutoFillValue.isEmpty ? Constants.DEFAULT_CURRENCY_VALUE : lovAutoFillValue, delegate: delegate, optionArray: optionArray, removeTopMargin: removeTopMargin)
    }
}

extension CustomCurrencyView: CustomTFViewDelegate {
    func validateFields() {
        
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        let amount = Int(text) ?? 0
        return text.count < 10 && amount > 0
    }
}
