//
//  CustomTextFieldView.swift
//  mCAS
//
//  Created by iMac on 16/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

enum FieldType {
    case Text
    case Mobile
    case Amount
    case Number
    case Decimal
    case Email
    case DOB
    case DATE
    case Password
}

@objc protocol CustomTFViewDelegate {
    func validateFields()
    @objc optional func textFieldEditing(text: String, tag: Int) -> Bool
}

class CustomTextFieldView: UIView {
    
    @IBOutlet private var customContainerVw: UIView!
    @IBOutlet weak private var textField: JVFloatLabeledTextField!
    @IBOutlet weak private var currencyLabel: EdgeInsetLabel!
    @IBOutlet weak private var unitLabel: EdgeInsetLabel!
    @IBOutlet weak private var textFieldView: UIView!
    @IBOutlet weak private var calendarIcon: UIImageView!
    @IBOutlet weak private var calendarIconWidth: NSLayoutConstraint!
    @IBOutlet weak var textFieldTopMargin: NSLayoutConstraint!
    
    private(set) var textFieldType: FieldType!
    private var delegate: CustomTFViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomTextFieldView", owner: self, options: nil)
        customContainerVw.fixInView(self)
        self.layer.masksToBounds = true
    }
    
    func getFieldValue() -> String {
        return textField.text ?? ""
    }
    
    func setFieldValue(text: String? = nil) {
        if let text = text {
            textField.text = text
            
            if textFieldType == .DOB || textFieldType == .DATE {
                if let datePicker = textField.inputView as? UIDatePicker, let preSelectedData = CustomDateFormatter.shared().getRespectiveDateFromString(inputString: text) {
                    datePicker.date = preSelectedData
                }
            }
        }
        else {
            //Reset value
            textField.text = ""
        }
    }
    
    func setFieldPlaceHolder(placeHolder: String) {
        textField.placeholder = placeHolder
    }
    
    func hideKeyboard() {
        textField.resignFirstResponder()
    }
    
    func setProperties(placeHolder: String, type: FieldType? = .Text, delegate: CustomTFViewDelegate? = nil, unitText: String? = "", tag: Int? = 999999, enabled: Bool? = true, minimumDate: Date? = nil, maximumDate: Date? = Date(), removeTopMargin: Bool = false) {
        
        textFieldType = type
        textFieldView.tag = tag!
        textField.isEnabled = enabled!
        textField.inputView = .none
        textField.isSecureTextEntry = false

        self.delegate = delegate
        
        currencyLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        currencyLabel.text = (type == .Amount) ? Constants.CURRENCY_SYMBOL : ""
        
        unitLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        unitLabel.text = unitText
        
        textFieldView.setTextFieldViewProperties()
        setFieldPlaceHolder(placeHolder: placeHolder)
        textFieldTopMargin.constant = removeTopMargin ? 0 : 15
        calendarIcon.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(calendarTapped)))
        calendarIcon.isUserInteractionEnabled = true
        calendarIconWidth.constant = (type == .DOB || type == .DATE) ? 30 : 0
        
        switch type {
        case .Email:
            textField.keyboardType = .emailAddress
            
        case .Password:
            textField.keyboardType = .default
            textField.isSecureTextEntry = true
            
        case .Mobile:
            textField.keyboardType = .phonePad
            
        case .Number:
            textField.keyboardType = .numberPad
            
        case .Amount:
            textField.keyboardType = .decimalPad
            
        case .Decimal:
            textField.keyboardType = .decimalPad
            
        case .DOB:
            let maxDate = Calendar.current.date(byAdding: .year, value: -18, to: Date())! //Min Age of 18 years
            
            setInputViewAsDatePicker(minimumDate: getMinDate(), maximumDate: maxDate)
            
        case .DATE:
            if let minDate = minimumDate {
                setInputViewAsDatePicker(minimumDate: minDate, maximumDate: maximumDate)
            }
            else {
                setInputViewAsDatePicker(minimumDate: getMinDate(), maximumDate: maximumDate)
            }
            
        default:
            textField.keyboardType = .default
        }
    }
    
    @objc private func calendarTapped() {
        textField.becomeFirstResponder()
    }
    
    private func getMinDate() -> Date? {
        return CustomDateFormatter.shared().getRespectiveDateFromString(inputString: "01-01-1900")
    }
    
    private func setInputViewAsDatePicker(minimumDate: Date?, maximumDate: Date?) {
        
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        datePicker.date = Date()
        datePicker.minimumDate = minimumDate
        datePicker.maximumDate = maximumDate
        datePicker.addTarget(self, action: #selector(doneButtonClicked), for: .valueChanged)
        
        //on click of done button set datePicker.date by default in textfield
        textField.addTarget(self, action: #selector(doneButtonClicked), for: .editingDidBegin)
        textField.inputView = datePicker
        textField.clearButtonMode = .never
    }
    
    @objc func doneButtonClicked() {
        
        if let datePicker = textField.inputView as? UIDatePicker {
            textField.text = datePicker.date.getFormatedDateString(outputFormat: Constants.DATE_FORMAT_VIEW)
        }
    }
}

extension CustomTextFieldView: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textFieldView.layer.borderColor = Color.BLUE.cgColor
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        textFieldView.layer.borderColor = UIColor.lightGray.cgColor
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {

        if textField.disableDoubleSpacePeriodIssue(shouldChangeCharactersRange: range, replacementString: string) == false {
            return false
        }

        if let text = textField.text, let textRange = Range(range, in: text), !string.isEmpty {
            let updatedText = text.replacingCharacters(in: textRange, with: string)

            switch textFieldType {
            case .Email:
                //Space and contineous dots not allowed in email
                if string == " " || updatedText.contains("..") { return false }
                
            case .Mobile:
                return updatedText.isNumeric && updatedText.count <= Constants.MOBILE_NUMBER_LENGTH
                
            case .Amount:
                return updatedText.validateAmountString && delegate?.textFieldEditing?(text: updatedText, tag: textFieldView.tag) ?? true
                
            case .Password:
                return updatedText.count <= 15
                
            case .Decimal:
                return updatedText.validateAmountString && delegate?.textFieldEditing?(text: updatedText, tag: textFieldView.tag) ?? true
                
            case .Number:
                return updatedText.isNumeric && delegate?.textFieldEditing?(text: updatedText, tag: textFieldView.tag) ?? true
                
            case .Text:
                return delegate?.textFieldEditing?(text: updatedText, tag: textFieldView.tag) ?? true
                
            default:
                return true
            }
        }
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {

        if textFieldType == .Decimal || textFieldType == .Amount {
            if let text = textField.text, let value = Double(text) {
                textField.text = String(format: "%.2f", value)
            }
            else {
                textField.text = "0.00"
            }
        }
        else if textFieldType == .Number {
            if let text = textField.text, let value = Int(text), value == 0 {
                textField.text = "0"
            }
        }
        
        if let delegate = self.delegate {
            delegate.validateFields()
        }
    }
}

