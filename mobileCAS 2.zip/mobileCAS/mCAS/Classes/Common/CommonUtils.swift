//
//  CommonUtils.swift
//  mCAS
//
//  Created by Mac on 06/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import Foundation

class CommonUtils: NSObject {
    
    private static var instance: CommonUtils?
    
    static func shared() -> CommonUtils{
        if instance == nil {
            instance = CommonUtils()
        }
        return instance!
    }
    
    func JSONtoData(jsonObject: [String: AnyObject], completion: (_ data: Data) -> Void) {
        do {
            let data = try JSONSerialization.data(withJSONObject: jsonObject, options: [])
            completion(data)
        }
        catch { debugPrint(error) }
    }
    
    func dataToJSON(data: Data, completion: (_ json: AnyObject) -> Void) {
        do {
            let nsJSON = try JSONSerialization.jsonObject(with: data, options: [])
            completion(nsJSON as AnyObject)
        }
        catch { debugPrint(error) }
    }
    
    func JSONToString(jsonObject: Any) -> String{
        do {
            let data =  try JSONSerialization.data(withJSONObject: jsonObject, options: .fragmentsAllowed)
            return String(data: data, encoding: String.Encoding.utf8) ?? ""
        }
        catch { return "" }
    }
    
    func JSONtoModel<T>(jsonObject: Any, type: T.Type, completion: (_ list: T) -> Void) where T : Decodable {
        do {
            let jsonData = try JSONSerialization.data(withJSONObject:jsonObject, options:[])
            let list = try JSONDecoder().decode(type.self, from: jsonData)
            completion(list)
        }
        catch { debugPrint(error) }
    }
    
    func modelToData<T: Encodable>(_ object: T, completion: (_ data: Data) -> Void) {
        do {
            let data = try JSONEncoder().encode(object)
            completion(data)
        }
        catch { debugPrint(error) }
    }
    
    func dataToModel<T: Decodable>(data: Data, type: T.Type, completion: (_ type: T) -> Void) {
        do {
            let model = try JSONDecoder().decode(type, from: data)
            completion(model)
        }
        catch { debugPrint(error) }
    }
    
    func checkForReachabilityMode() -> Bool {
        if !ReachabilityManager.isReachable() {
            CommonAlert.shared().showOfflineAlert()
            return false
        }
        return true
    }
    
    func saveData(value: Any, key: String) {
        UserDefaults.standard.setSecretObject(value, forKey: key)
    }
    
    func getDataFromSecretUserDefault(key: String) -> Any? {
        return UserDefaults.standard.secretObject(forKey: key)
    }
    
    func getIconFor(productTypeCode: String) -> String {
        switch productTypeCode {
        case ConstantCodes.PRODUCT_TYPE_CON_VEH:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_PF:
            return "loan_icon_personal"
        case ConstantCodes.PRODUCT_TYPE_CL:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_HL:
            return "loan_icon_home"
        case ConstantCodes.PRODUCT_TYPE_LAP:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_CC:
            return "loan_icon_creditcard"
        case ConstantCodes.PRODUCT_TYPE_CV:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_EQUIPMNT:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_MHL:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_FE:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_EDU:
            return "loan_icon_education"
        case ConstantCodes.PRODUCT_TYPE_AGRL:
            return "loan_icon_agriculture"
        case ConstantCodes.PRODUCT_TYPE_KCC:
            return "loan_icon_creditcard"
        default:
            return "loan_icon_auto"
        }
    }
    
    func fetchFromDateAndToDateForDayFilter(from: String, to: String, selectedDay: DAYFILTER) -> (String, String) {
        
        var fromDate = ""
        var toDate = ""
        
        if selectedDay == .Range {
            fromDate = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: from, outputFormat: Constants.DATE_FORMAT_SERVICE)
            toDate = CustomDateFormatter.shared().getFormatedDateStringFrom(inputString: to, outputFormat: Constants.DATE_FORMAT_SERVICE)
        }
        else {
            var dayDiff: Double = 7
            
            switch selectedDay {
            case .FifteenDay:
                dayDiff = 15
            case .ThirtyDay:
                dayDiff = 30
            default:
                dayDiff = 7
            }
            
            toDate = Date().getFormatedDateString(outputFormat: Constants.DATE_FORMAT_SERVICE)
            fromDate = Date().addingTimeInterval(-dayDiff*24*60*60).getFormatedDateString(outputFormat: Constants.DATE_FORMAT_SERVICE)
        }
        
        return (fromDate, toDate)
    }
    
    func getDeviceID() -> String {
        
        //Fetch 16 digit uuid
        let myPasteboard = UIPasteboard.init(name: UIPasteboard.Name(rawValue: "mCASPasteboard"), create: false)
        
        if let uuid = myPasteboard?.string {
            return uuid
        }
        else {
            var uuid = NSNumber(value: 1 + arc4random_uniform(9)).stringValue
            var i = 0
            
            while i < 16 {
                uuid.append(NSNumber(value: arc4random_uniform(10)).stringValue)
                i += 1
            }
            
            let myPasteboard = UIPasteboard.init(name: UIPasteboard.Name(rawValue: "mCASPasteboard"), create: true)
            myPasteboard?.string = uuid
            return uuid
        }
        
        //        return UIDevice.current.identifierForVendor!.uuidString
    }
    
    func getValidatedString(string: Any?) -> String {
        if let str = string as? String {
            return str
        }
        else if let str = string as? Double {
            return "\(str)"
        }
        else if let str = string as? Int {
            return "\(str)"
        }
        
        return ""
    }
    
    func makeCall(mobileNumber: String) {
        if let phoneCallURL = URL(string: "tel://\(mobileNumber)"), UIApplication.shared.canOpenURL(phoneCallURL) {
            UIApplication.shared.open(phoneCallURL, options: [:])
        }
    }
}
