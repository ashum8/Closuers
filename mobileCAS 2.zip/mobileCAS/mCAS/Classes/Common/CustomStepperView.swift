//
//  CustomStepperView.swift
//  mCAS
//
//  Created by iMac on 22/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class CustomStepperView: UIView {
    @IBOutlet var containerView: UIView!
    @IBOutlet weak var textFieldView: CustomTextFieldView!
    @IBOutlet weak var stepperView: UIView!
    
    private var selectedSteps = 0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomStepperView", owner: self, options: nil)
        containerView.fixInView(self)
        self.layer.masksToBounds = true
    }
    
    func getFieldValue() -> String {
        return textFieldView.getFieldValue()
    }
    
    func setProperties(title: String) {
        stepperView.setMainViewProperties()
        textFieldView.setProperties(placeHolder: title)
    }
    
    @IBAction func plusButtonAction(_ sender: Any) {
        if selectedSteps < 10 {
            selectedSteps = selectedSteps + 1
            textFieldView.setFieldValue(text: "\(selectedSteps)")
        }
    }
    
    @IBAction func minusButtonAction(_ sender: Any) {
        if selectedSteps > 0 {
            selectedSteps = selectedSteps - 1
            textFieldView.setFieldValue(text: "\(selectedSteps)")
        }
    }
}
