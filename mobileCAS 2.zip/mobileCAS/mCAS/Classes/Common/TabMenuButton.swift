//
//  TabMenuButton.swift
//  mCAS
//
//  Created by Mac on 20/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


@objc protocol TabMenuButtonDelegate {
    func changeTabButtonSelection(id: String)
}

class TabMenuButton: UIButton {
    
    private(set) var btnModel: ButtonModel!
    weak private var delegate: TabMenuButtonDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    init(frame: CGRect, btnModel: ButtonModel, delegate: TabMenuButtonDelegate) {
        // set other operations after super.init, if required
        super.init(frame: frame)
        
        self.btnModel = btnModel
        self.delegate = delegate
        
//        self.setImage(image1?.maskWithColor(color: Constant.getGreenColor()), for: .selected)
        self.setImage(UIImage(named: btnModel.activeIcon), for: .selected)
        self.setImage(UIImage(named: btnModel.buttonImage), for: .normal)
        self.setTitle(btnModel.buttonText, for: .normal)
        self.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(13)
        self.setTitleColor(.black, for: .normal)
        self.setTitleColor(Color.BLUE, for: .selected)
        self.addTarget(self, action:#selector(tabButtonAction), for: .touchUpInside)
        self.setAlignmentOfButton(isTab: true)
    }
    
    @objc func tabButtonAction() {
        
        if (!self.isSelected) {
            self.delegate?.changeTabButtonSelection(id: self.btnModel.buttonID)
            
            AppDelegate.instance.tabsButtonAction(tabID: btnModel.buttonID)
        }
    }
}
