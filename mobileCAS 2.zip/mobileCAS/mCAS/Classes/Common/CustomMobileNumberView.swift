//
//  CustomMobileNumberView.swift
//  mCAS
//
//  Created by iMac on 22/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class CustomMobileNumberView: UIView {
    @IBOutlet weak var countryCodeLOV: LOVFieldView!
    @IBOutlet weak var mobileNoTFView: CustomTextFieldView!
    @IBOutlet var containerView: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomMobileNumberView", owner: self, options: nil)
        containerView.fixInView(self)
    }
    
    func setProperties(tag:Int, lovDelegate: SelectedLOVDelegate, tfDelegate: CustomTFViewDelegate? = nil, optionArray: [DropDown] = [], removeTopMargin: Bool = false) {
        
        mobileNoTFView.setProperties(placeHolder: "Mobile Number", type: .Mobile, delegate: tfDelegate, removeTopMargin: removeTopMargin)
        
        //FIV Case
        if !optionArray.isEmpty {
            countryCodeLOV.setLOVProperties(title: "Country Code", tag: tag, delegate: lovDelegate, optionArray: optionArray, removeTopMargin: removeTopMargin)
        }
        else {
            countryCodeLOV.setLOVProperties(masterName: Entity.PHONE_COUNTRYCODE, title: "Country Code", tag: tag, delegate: lovDelegate, removeTopMargin: removeTopMargin)
            countryCodeLOV.autoFillLOVBy(key: Constants.DEFAULT_COUNTRY_CODE)
        }
    }
    
    func setAutoFillMobileNumber(countryKey: String? = nil, mobileNumber: String = "") {
        countryCodeLOV.autoFillLOVBy(key: countryKey)
        mobileNoTFView.setFieldValue(text: mobileNumber)
    }
}

