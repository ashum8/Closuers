//
//  CustomPhoneNumberView.swift
//  mCAS
//
//  Created by iMac on 22/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit


@objc protocol CustomPhoneViewDelegate {
    @objc optional func validatePhoneField()
}

class CustomPhoneNumberView: UIView {
    @IBOutlet var containerView: UIView!
    @IBOutlet weak var countryCodeLOV: LOVFieldView!
    @IBOutlet weak var stdCodeView: CustomTextFieldView!
    @IBOutlet weak var phoneNumberTFView: CustomTextFieldView!
    @IBOutlet weak var extensionView: CustomTextFieldView!
    @IBOutlet weak var extensionViewWidth: NSLayoutConstraint!
    
    private var delegate: CustomPhoneViewDelegate?

    private let TAG_STD_CODE = 1001
    private let TAG_PHONE_NUMER = 1002
    private let TAG_EXTENSION = 1003
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomPhoneNumberView", owner: self, options: nil)
        containerView.fixInView(self)
    }
    
    func setProperties(tag: Int, delegate: SelectedLOVDelegate, phoneViewdelegate: CustomPhoneViewDelegate? = nil, optionArray: [DropDown] = [], removeTopMargin: Bool = false, showExtension: Bool = false, isFieldOptional: Bool = false)
    {
        self.delegate = phoneViewdelegate
        
        stdCodeView.setProperties(placeHolder: isFieldOptional ? "STD Code (Optional)" : "STD Code", type: .Number, delegate: self, tag: TAG_STD_CODE, removeTopMargin: removeTopMargin)
        
        phoneNumberTFView.setProperties(placeHolder: isFieldOptional ? "Phone Number (Optional)" : "Phone Number", type: .Number, delegate: self, tag: TAG_PHONE_NUMER, removeTopMargin: removeTopMargin)
        
        if !optionArray.isEmpty {
            countryCodeLOV.setLOVProperties(title: isFieldOptional ? "Country Code (Optional)" : "Country Code", tag: tag, delegate: delegate, optionArray: optionArray, removeTopMargin: removeTopMargin)
        }
        else {
            countryCodeLOV.setLOVProperties(masterName: Entity.PHONE_COUNTRYCODE, title: isFieldOptional ? "Country Code (Optional)" : "Country Code", tag: tag, delegate: delegate, removeTopMargin: removeTopMargin)
            countryCodeLOV.autoFillLOVBy(key: Constants.DEFAULT_COUNTRY_CODE)
        }
                
        if showExtension {
            extensionViewWidth = extensionViewWidth.changeMultiplier(multiplier: 0.18)
            extensionView.setProperties(placeHolder: "Ext", type: .Number, delegate: self, tag: TAG_EXTENSION, removeTopMargin: removeTopMargin)
        }
        else {
            extensionViewWidth = extensionViewWidth.changeMultiplier(multiplier: 0.0)
        }
    }
    
    func setAutoFillPhoneNumber(countryKey: String? = nil, std: String = "", phoneNumber: String = "", ext: String = "") {
        countryCodeLOV.autoFillLOVBy(key: countryKey)
        stdCodeView.setFieldValue(text: std)
        phoneNumberTFView.setFieldValue(text: phoneNumber)
        extensionView.setFieldValue(text: ext)
    }
}

extension CustomPhoneNumberView: CustomTFViewDelegate {
    func validateFields() {
        self.delegate?.validatePhoneField?()
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        switch tag {
        case TAG_PHONE_NUMER:
            return text.count <= 6
            
        case TAG_STD_CODE:
            return text.count <= 4
            
        case TAG_EXTENSION:
            return text.count <= 3
            
        default:
            return true
        }
    }
}
