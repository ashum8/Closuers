//
//  LOVFieldView.swift
//  mCAS
//
//  Created by iMac on 11/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

protocol SelectedLOVDelegate {    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int)
}

class LOVFieldView: UIView {
    
    @IBOutlet private var LOVContainerView: UIView!
    @IBOutlet weak private var LOVButton: UIButton!
    @IBOutlet weak private var bgview: UIView!
    @IBOutlet weak var topMargin: NSLayoutConstraint!
    
    private var delegate: SelectedLOVDelegate?
    private var dropDownList:[DropDown] = []
    
    private var parentKey: String?
    private var masterName: String!
    private var titleStr: String!
    private var allowLOVSetText: Bool!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("LOVFieldView", owner: self, options: nil)
        LOVContainerView.fixInView(self)
        self.layer.masksToBounds = true
    }
    
    func setLOVProperties(masterName: String = "", title: String, tag: Int, autoFillValue: String? = nil, delegate: SelectedLOVDelegate, optionArray: [DropDown]? = nil, allowLOVSetText: Bool = true, parentKey: String? = nil, enable: Bool = true, removeTopMargin: Bool = false) {
        
        bgview.setMainViewProperties()
        
        self.delegate = delegate
        self.titleStr = title
        self.allowLOVSetText = allowLOVSetText
        self.parentKey = parentKey
        
        LOVButton.tag = tag
        LOVButton.setTitle(self.titleStr, for: .normal)
        LOVButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        LOVButton.titleLabel?.numberOfLines = 2
        LOVButton.addTarget(self, action: #selector(lovButtonAction(_:)), for: .touchUpInside)
        enableLOV(isEnable: enable)

        if let optionArray = optionArray {
            self.dropDownList = optionArray
        }
        else {
            self.masterName = masterName
        }
	
        if let value = autoFillValue {
            autoFillLOVBy(value: value)
        }
        
        topMargin.constant = removeTopMargin ? 0 : 15
    }
    
    func enableLOV(isEnable: Bool = true) {
        LOVButton.isEnabled = isEnable
    }
    
    func autoFillLOVBy(key: String? = nil, value: String? = nil) {
        fetchMasterRecords()
        
        if let selectedObj = self.dropDownList.filter({
            
            if let key = key, !key.isEmpty {
                return ($0.code.lowercased() == key.lowercased())
            }
            else if let value = value,  !value.isEmpty {
                return ($0.name.lowercased() == value.lowercased())
            }
            else {
                return false
            }
            
        }).first {
            self.selectedLOV(selectedObj: selectedObj)
        }
    }
    
    private func fetchMasterRecords() {
        if let masterEntity = self.masterName, self.dropDownList.isEmpty {
            // fetch the dropdownList according to master name
            CoreDataOperations.shared().fetchRecordsForMaster(masterName: masterEntity, parentKey: self.parentKey) { (records) in
                
                if let records = records {
                    self.dropDownList.append(contentsOf: records)
                }
            }
        }
    }
    
    func resetLOVWithParentKey(key: String? = nil) {
        self.parentKey = key
        LOVButton.setAttributedTitle(NSAttributedString(), for: .normal)
        self.dropDownList.removeAll()
    }
    
    func resetLOVWithMaster(list: [DropDown]) {
        self.dropDownList = list
        LOVButton.setAttributedTitle(NSAttributedString(), for: .normal) 
    }
    
    func setLOVText(selectedObj: DropDown) {
        self.dropDownList = self.dropDownList.map({(item) -> DropDown in
            item.isSelectedFlag = ((selectedObj.code == item.code) && (selectedObj.name == item.name))
            return item
        })
        
        //Set LOV title in async mode as due to autofill value LOVButton width do not set
        DispatchQueue.main.async {
            let truncatedString = self.getTruncatedString(width: self.LOVButton.frame.width - 35, font: CustomFont.shared().GETFONT_REGULAR(14), text: self.titleStr)
            self.LOVButton.setLOVSelectedText(line1: truncatedString, line2: selectedObj.lovDisplayValue)
        }
    }
    
    private func getTruncatedString(width: CGFloat, font: UIFont, text: String) -> String {
        var truncatedString = text
        
        var truncatedStrWidth = truncatedString.widthOfString(usingFont: font)
        if truncatedStrWidth > width {
            
            let widthIn = width - "...".widthOfString(usingFont: font)
            
            while truncatedStrWidth > widthIn {
                truncatedString.removeLast()
                truncatedStrWidth = truncatedString.widthOfString(usingFont: font)
            }
            
            truncatedString = truncatedString + "..."
        }
        return truncatedString
    }
    
    @objc func lovButtonAction(_ sender: UIButton) {
        
        fetchMasterRecords()
        
        let storyboard = UIStoryboard.init(name: Storyboard.LOV_LIST, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "LOVListVC") as? LOVListVC {
            vc.setData(dropDownList: self.dropDownList, delegate: self, title: self.titleStr ?? "", selectedButton: sender)
            AppDelegate.instance.applicationNavController.pushViewController(vc, animated: true)
        }
    }
}

extension LOVFieldView: LOVListDelegate {
    
    func selectedLOV(selectedObj: DropDown) {
        
        if self.allowLOVSetText {
            self.setLOVText(selectedObj: selectedObj)
        }
        delegate?.selectedLOVResult(selectedObj: selectedObj, btntag: LOVButton.tag)
    }
    
}
