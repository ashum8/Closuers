//
//  HeaderView.swift
//  mCAS
//
//  Created by Mac on 19/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class LOVHeaderView: UIView {
    private var titleLabel: UILabel!
    private var closeButton: UIButton!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let view: UIView = UIView(frame: CGRect(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height))
        view.backgroundColor = .white
        self.addSubview(view)
        
        let lineView: UIView = UIView(frame: CGRect(x: 0, y: view.frame.size.height - 1, width: view.frame.size.width, height: 1))
        lineView.backgroundColor = .lightGray
        self.addSubview(lineView)
        
        let yCord = AppDelegate.instance.getTopPadding()
        let buttonWidth = view.frame.size.height-yCord
        
        titleLabel = UILabel(frame: CGRect(x: buttonWidth, y: yCord, width: view.frame.size.width-(2*buttonWidth), height: buttonWidth))
        titleLabel.lineBreakMode = .byWordWrapping
        titleLabel.numberOfLines = 2
        titleLabel.textAlignment = .center
        titleLabel.textColor = .darkGray
        view.addSubview(titleLabel)
        
        closeButton = UIButton(frame: CGRect(x: titleLabel.frame.origin.x + titleLabel.frame.size.width, y: yCord, width: buttonWidth, height: buttonWidth))
        closeButton.setImage(UIImage(named: "close_gray_icon"), for: .normal)
        closeButton.addTarget(self, action:#selector(closeButtonAction(_:)), for: .touchUpInside)
        closeButton.isHidden = true
        view.addSubview(closeButton)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setTitle(title: String) {
        titleLabel.font = CustomFont.shared().GETFONT_MEDIUM(19)
        titleLabel.text = title
    }
    
    func hideShowCloseButton(hide: Bool) {
        self.closeButton.isHidden = hide
    }
    
    @objc private func closeButtonAction(_ sender: UIButton) {
        AppDelegate.instance.applicationNavController.popViewController(animated: false)
    }
    
    @objc func setAttributedTitle(line1: String, line2: String) {
        titleLabel.setHeaderTitleOnWhiteBG(line1: line1, line2: line2)
    }
}
