//
//  DashboardHeaderView.swift
//  mCAS
//
//  Created by Mac on 19/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class DashboardHeaderView: UIView {
    private var titleLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let view: UIView = UIView(frame: CGRect(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height))
        view.backgroundColor = Color.BLUE
        self.addSubview(view)
        
        let yCord = AppDelegate.instance.getTopPadding()
        let height = view.frame.size.height-yCord
        let buttonWidth: CGFloat = height
        let firstButtonXCord: CGFloat = view.frame.size.width - (buttonWidth*3) - 10
        
        titleLabel = UILabel(frame: CGRect(x: 10, y: yCord, width: firstButtonXCord, height: height))
        titleLabel.textColor = .white
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        view.addSubview(titleLabel)
        
        self.setTitle(text: "Hi! \(AppDelegate.instance.getSavedUserID().capitalized)")
        
//        let searchButton = UIButton(frame: CGRect(x: firstButtonXCord, y: yCord, width: buttonWidth, height: height))
//        searchButton.setImage(UIImage(named: "search_icon_white"), for: .normal)
//        searchButton.addTarget(self, action:#selector(searchButtonAction(_:)), for: .touchUpInside)
//        view.addSubview(searchButton)
//        
//        let notificationButton = UIButton(frame: CGRect(x: firstButtonXCord + buttonWidth, y: yCord, width: buttonWidth, height: height))
//        notificationButton.setImage(UIImage(named: "notification_icon"), for: .normal)
//        notificationButton.addTarget(self, action:#selector(notificationButtonAction(_:)), for: .touchUpInside)
//        view.addSubview(notificationButton)
        
        let profileButton = UIButton(frame: CGRect(x: firstButtonXCord + (buttonWidth*2), y: yCord, width: buttonWidth, height: height))
        profileButton.setImage(UIImage(named: "user_profile_icon"), for: .normal)
        profileButton.addTarget(self, action:#selector(profileButtonAction(_:)), for: .touchUpInside)
        view.addSubview(profileButton)
    }
    
    func setTitle(text: String) {
        titleLabel.text = text
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func searchButtonAction(_ sender: UIButton) {
        
    }
    
    @objc private func notificationButtonAction(_ sender: UIButton) {
        
    }
    
    @objc private func profileButtonAction(_ sender: UIButton) {
        
        CommonAlert.shared().showAlert(message: "Are you sure you want to logout?", okTitle: "Yes", cancelTitle: "No", okAction: { _ in
            
            AppDelegate.instance.presentLoginViewController()
            
            Webservices.shared().logoutFromServer(allowOfflineAlert: false) { _ in }
        })
    }
    
}
