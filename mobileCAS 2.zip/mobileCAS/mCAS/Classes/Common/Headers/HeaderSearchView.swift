//
//  HeaderSearchView.swift
//  DemoView
//
//  Created by Ashutosh Mishra on 04/12/19.
//  Copyright © 2019 Ashutosh Mishra. All rights reserved.
//

import UIKit

protocol HeaderSearchDelegate {
    func searchDataFromString(text: String)
    func searchBackAction()
}

class HeaderSearchView: UIView {
    
    @IBOutlet var contentView: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var delegate: HeaderSearchDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("HeaderSearchView", owner: self, options: nil)
        contentView.fixInView(self)
        
        searchBar.backgroundImage = UIImage()
        searchBar.setProperties()
    }
    
    @IBAction func btnBackClicked(_ sender: Any) {
        self.searchBar.text = ""
        self.searchBar.resignFirstResponder()
        self.isHidden = true
        delegate?.searchBackAction()
    }
}


extension HeaderSearchView: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        delegate?.searchDataFromString(text: searchBar.text ?? "")
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        delegate?.searchDataFromString(text: searchBar.text ?? "")
    }
    
    //on keyboard clear button this method is called
    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {
        delegate?.searchDataFromString(text: searchBar.text ?? "")
        return true
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        searchBar.resignFirstResponder()
        delegate?.searchDataFromString(text: searchBar.text ?? "")
    }
}

