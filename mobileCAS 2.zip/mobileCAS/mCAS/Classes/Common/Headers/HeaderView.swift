//
//  HeaderView.swift
//  mCAS
//
//  Created by Mac on 19/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit
import AudioToolbox

@objc protocol HeaderDelegate {
    @objc optional func searchOnOff(isSearching: Bool)
    @objc optional func handleSearch(text: String)
    
    @objc optional func handleSelectedOption(index: Int)
    @objc optional func filterButtonAction()
}

class HeaderView: UIView {
    private var titleLabel: UILabel!
    private var backButton: UIButton!
    private var dashboardHV: DashboardHeaderView!
    private var whiteHeader: LOVHeaderView!
    private(set) var stepsHV: StepsHeaderView!
    private(set) var searchView = HeaderSearchView()
    
    private var searchMikeFilterView = UIStackView()
    
    private var searchButton: UIButton!
    private var mikeButton: UIButton!
    private var filterButton: UIButton!
    private var optionButton: UIButton!
    private var arrowButton: UIButton!
    
    private var speechController = SpeechController()
    private var overlay: MRProgressOverlayView!
    
    private var selectedSimpleListValue = ""
    private var maxTitleWidth: CGFloat = 0
    
    private var delegate: HeaderDelegate?
    private var dropdownListArray: [String] = []
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let view: UIView = UIView(frame: CGRect(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height))
        view.backgroundColor = Color.BLUE
        self.addSubview(view)
        
        let yCord = AppDelegate.instance.getTopPadding()
        let height = view.frame.size.height-yCord
        let margin: CGFloat = 5
        
        backButton = UIButton(frame: CGRect(x: margin, y: yCord, width: height, height: height))
        backButton.setImage(UIImage(named: "back_icon_white"), for: .normal)
        backButton.addTarget(self, action:#selector(backButtonAction(_:)), for: .touchUpInside)
        backButton.isHidden = true
        view.addSubview(backButton)
        
        var xCord = backButton.frame.origin.x+backButton.frame.size.width+10
        
        titleLabel = UILabel(frame: CGRect(x: xCord, y: yCord, width: view.frame.size.width-xCord-margin, height: height))
        titleLabel.lineBreakMode = .byWordWrapping
        titleLabel.numberOfLines = 2
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        titleLabel.textColor = .white
        titleLabel.isHidden = true
        view.addSubview(titleLabel)
        
        self.maxTitleWidth = titleLabel.frame.size.width
        xCord = titleLabel.frame.origin.x+maxTitleWidth+10
        
        arrowButton = UIButton(frame: CGRect(x: xCord, y: yCord, width: height, height: height))
        arrowButton.setImage(UIImage(named: "white_arrow_icon_down"), for: .normal)
        arrowButton.setImage(UIImage(named: "white_arrow_icon_up"), for: .selected)
        arrowButton.addTarget(self, action:#selector(arrowButtonAction(_:)), for: .touchUpInside)
        arrowButton.isHidden = true
        view.addSubview(arrowButton)
        
        setupSearchMikeFilterOptions(view: view)
        addStepHeader(view: view)
        addDashboardHeader(view: view)
        addLOVWhiteHeader(view: view)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setTitleWith(line1: String? = nil, line2: String? = nil, showBack: Bool = false, showDropdownArrow: Bool = false, delegate: HeaderDelegate? = nil, dropdownListArray: [String] = []) {
        
        self.delegate = delegate
        self.dropdownListArray = dropdownListArray
        
        self.isHidden = false
        titleLabel.isHidden = false
        backButton.isHidden = !showBack
        arrowButton.isHidden = !showDropdownArrow
        arrowButton.isSelected = false
        
        var lineFirst = ""
        
        if let line1 = line1, !line1.isEmpty {
            lineFirst = line1
        }
        
        if !self.arrowButton.isHidden {
            selectedSimpleListValue = self.dropdownListArray.isEmpty ? "" : self.dropdownListArray[0]
            lineFirst = selectedSimpleListValue
        }
        
        setTitleTextAndFrame(line1: lineFirst, line2: line2)
    }
    
    private func setTitleTextAndFrame(line1: String, line2: String? = nil) {
        
        var frame = titleLabel.frame
        
        if let line2 = line2 {
            titleLabel.setHeaderTitleOnBlueBG(line1: line1, line2: line2)
            frame.size.width = min(titleLabel.attributedText!.widthOfString(), self.maxTitleWidth)
        }
        else {
            titleLabel.text = line1
            frame.size.width = min(titleLabel.text!.widthOfString(usingFont: titleLabel.font), self.maxTitleWidth)
        }
        
        if backButton.isHidden {
            frame.origin.x = 10
        }
        else {
            frame.origin.x = backButton.frame.origin.x+backButton.frame.size.width+10
        }
        
        titleLabel.frame = frame
        
        if let arrowButton = arrowButton, !arrowButton.isHidden {
            let xCord = titleLabel.frame.origin.x+titleLabel.frame.size.width
            
            frame = arrowButton.frame
            frame.origin.x = xCord
            arrowButton.frame = frame
        }
    }
    
    @objc private func backButtonAction(_ sender: UIButton) {
        AppDelegate.instance.applicationNavController.popViewController(animated: false)
    }
    
    private func setupSearchMikeFilterOptions(view: UIView) {
        
        let yCord = AppDelegate.instance.getTopPadding()
        let height = view.frame.size.height-yCord
        
        searchMikeFilterView = UIStackView()
        searchMikeFilterView.backgroundColor = .clear
        searchMikeFilterView.axis = .horizontal
        searchMikeFilterView.translatesAutoresizingMaskIntoConstraints = false
        searchMikeFilterView.spacing = 15
        view.addSubview(searchMikeFilterView)
        
        view.addConstraint(NSLayoutConstraint(item: searchMikeFilterView, attribute: .trailing, relatedBy: .equal, toItem: view, attribute: .trailing, multiplier: 1, constant: -15))
        view.addConstraint(NSLayoutConstraint(item: searchMikeFilterView, attribute: .top, relatedBy: .equal, toItem: view, attribute: .top, multiplier: 1, constant: yCord))
        view.addConstraint(NSLayoutConstraint(item: searchMikeFilterView, attribute: .bottom, relatedBy: .equal, toItem: view, attribute: .bottom, multiplier: 1, constant: 0))
        
        searchButton = UIButton(frame: CGRect(x: 0, y: 0, width: height, height: height))
        searchButton.contentHorizontalAlignment = .center
        searchButton.setImage(UIImage(named: "search_icon_white"), for: .normal)
        searchButton.addTarget(self, action:#selector(searchButtonAction(_:)), for: .touchUpInside)
        
        mikeButton = UIButton(frame: CGRect(x: 0, y: 0, width: height, height: height))
        mikeButton.contentHorizontalAlignment = .center
        mikeButton.setImage(UIImage(named: "mike_icon"), for: .normal)
        mikeButton.addTarget(self, action:#selector(stopRecording), for: .touchUpInside)
        mikeButton.addTarget(self, action:#selector(startRecording), for: .touchDown)
        mikeButton.addTarget(self, action:#selector(stopRecording), for: .touchUpOutside)
        
        filterButton = UIButton(frame: CGRect(x: 0, y: 0, width: height, height: height))
        filterButton.contentHorizontalAlignment = .center
        filterButton.setImage(UIImage(named: "filter_icon"), for: .normal)
        filterButton.addTarget(self, action:#selector(filterButtonAction(_:)), for: .touchUpInside)
        
        optionButton = UIButton(frame: CGRect(x: 0, y: 0, width: height, height: height))
        optionButton.contentHorizontalAlignment = .center
        optionButton.setImage(UIImage(named: "more_3dots_white"), for: .normal)
        optionButton.addTarget(self, action:#selector(arrowButtonAction(_:)), for: .touchUpInside)
        
        searchMikeFilterView.addArrangedSubview(searchButton)
        searchMikeFilterView.addArrangedSubview(mikeButton)
        searchMikeFilterView.addArrangedSubview(filterButton)
        searchMikeFilterView.addArrangedSubview(optionButton)
        
        searchView.frame = CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height)
        searchView.delegate = self
        view.addSubview(searchView)
        
        showHideSearchMikeFilterOption()
        speechController.delegate = self
    }
    
    
    func showHideSearchMikeFilterOption(showSearch: Bool = false, showFilter: Bool = false, showOption: Bool = false, dropdownListArray:[String] = []) {
        self.dropdownListArray = dropdownListArray
        
        filterButton.isHidden = !showFilter
        optionButton.isHidden = !showOption
        searchMikeFilterView.isHidden = !showSearch
        searchView.isHidden = true
    }
    
    @objc private func filterButtonAction(_ sender: UIButton) {
        self.delegate?.filterButtonAction?()
    }
    
    @objc private func searchButtonAction(_ sender: UIButton) {
        searchView.isHidden = false
        searchView.searchBar.becomeFirstResponder()
        searchView.searchBar.text = ""
        delegate?.searchOnOff?(isSearching: true)
    }
    
    @objc private func startRecording() {
        searchView.searchBar.text = ""
        searchView.searchBar.resignFirstResponder()
        
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
        
        do {
            try self.speechController.startRecording()
            
            if let vc = AppDelegate.instance.applicationNavController.viewControllers.last {
                overlay =  MRProgressOverlayView.showOverlayAdded(to: vc.view, animated: true)
            }
            overlay.titleLabelText = NSLocalizedString("Listening...", comment:"")
        }
        catch {
            overlay.titleLabelText = NSLocalizedString("Press and hold microphone to record", comment:"")
        }
    }
    
    @objc private func stopRecording() {
        
        speechController.stopRecording()
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
        
        overlay.titleLabelText = NSLocalizedString("Press and hold microphone to record", comment:"")
        overlay.dismiss(true)
    }
    
    @objc private func arrowButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        
        let obj = SimpleListVC.init(nibName: "SimpleListVC", bundle: nil)
        if sender == optionButton {
            obj.setData(listArray: dropdownListArray, delegate: self)
        }
        else {
            //For EMI Calculator - show popover in full width
            obj.setData(listArray: dropdownListArray, selectedValue: selectedSimpleListValue, delegate: self, width: self.frame.size.width)
        }
        
        if let popoverPresentationController = obj.popoverPresentationController {
            if let vc = AppDelegate.instance.applicationNavController.viewControllers.last {
                vc.view.endEditing(true)
            }
            
            popoverPresentationController.permittedArrowDirections = .up
            popoverPresentationController.sourceView = sender
            popoverPresentationController.sourceRect = sender.bounds
            popoverPresentationController.delegate = self
            AppDelegate.instance.applicationNavController?.present(obj, animated: true, completion: nil)
        }
    }
    
    private func addStepHeader(view: UIView) {
        if stepsHV == nil {
            stepsHV = StepsHeaderView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height))
            view.addSubview(stepsHV)
        }
        
        showHideStepHeader()
    }
    
    func showHideStepHeader(isHide: Bool = true, title: String = "", step: String = "", landingPage: UIViewController? = nil) {
        stepsHV.setData(isHide: isHide, title: title, step: step, landingPage: landingPage)
    }
    
    private func addDashboardHeader(view: UIView) {
        if dashboardHV == nil {
            dashboardHV = DashboardHeaderView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height))
            view.addSubview(dashboardHV)
        }
        
        showHideDashboardHeader()
    }
    
    func showHideDashboardHeader(isHide: Bool = true) {
        dashboardHV.isHidden = isHide
    }
    
    private func addLOVWhiteHeader(view: UIView) {
        if whiteHeader == nil {
            whiteHeader = LOVHeaderView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height))
            view.addSubview(whiteHeader)
        }
        
        showHideWhiteHeader()
    }
    
    func showHideWhiteHeader(isHide: Bool = true, hideCloseButton: Bool = false, title: String? = "", line1: String? = "", line2: String? = "") {
        whiteHeader.isHidden = isHide
        
        if let title = title, !title.isEmpty {
            whiteHeader.setTitle(title: title)
        }
        else {
            whiteHeader.setAttributedTitle(line1: line1!, line2: line2!)
        }
        
        whiteHeader.hideShowCloseButton(hide: hideCloseButton)
    }
}

extension HeaderView: HeaderSearchDelegate {
    
    func searchDataFromString(text : String) {
        delegate?.handleSearch?(text: text)
    }
    
    func searchBackAction() {
        delegate?.searchOnOff?(isSearching: false)
    }
}

extension HeaderView: SpeechControllerDelegate {
    func speechController(_ speechController: SpeechController, didRecogniseText text: String) {
        searchView.searchBar.text = text
        delegate?.handleSearch?(text: text)
        
        searchView.isHidden = false
        delegate?.searchOnOff?(isSearching: true)
    }
}

extension HeaderView: SimpleListVCDelegate {
    
    func selectedListOption(index: Int) {
        
        DispatchQueue.main.async {
            AppDelegate.instance.applicationNavController?.dismiss(animated: true) {
                
                if !self.arrowButton.isHidden {
                    //In case of EMI calculator show selected value in header title
                    self.selectedSimpleListValue = self.dropdownListArray[index]
                    self.setTitleTextAndFrame(line1: self.selectedSimpleListValue)
                    self.arrowButton.isSelected = false
                }
                self.delegate?.handleSelectedOption?(index: index)
            }
        }
    }
}

extension HeaderView: UIPopoverPresentationControllerDelegate {
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
    func popoverPresentationControllerDidDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) {
        popoverPresentationController.delegate = nil
        arrowButton?.isSelected = false
    }
    
    func popoverPresentationControllerShouldDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) -> Bool {
        return true
    }
}

