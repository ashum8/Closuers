//
//  CustomPopupView.swift
//  mCAS
//
//  Created by iMac on 18/03/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class CustomPopupView: UIView {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var popupView: UIView!
    @IBOutlet weak var textView: UITextView!
        
    func setProperties(width: CGFloat, height: CGFloat, message: String) {
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        
        // Do any additional setup after loading the view.
        
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        titleLabel.text = "Remarks"
        
        closeButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(25)
        popupView.layer.cornerRadius = 8
        
        textView.text = message
        
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        self.alpha = 0
    }
    
}


