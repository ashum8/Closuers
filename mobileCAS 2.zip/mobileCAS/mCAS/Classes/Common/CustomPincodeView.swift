//
//  CustomPincodeView.swift
//  mCAS
//
//  Created by iMac on 05/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol CustomPincodeDelegate {
    func validatePincode()
}

class CustomPincodeView: UIView {
    @IBOutlet var containerView: UIView!
    @IBOutlet weak var textField: JVFloatLabeledTextField! //SK Change - should use CustomTextField
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var textFieldView: UIView!
    
    private var arrList = [DropDown]()
    private var cityCode: String!
    
    private var delegate: CustomPincodeDelegate?
    
    private var pinCodeValue: String!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomPincodeView", owner: self, options: nil)
        containerView.fixInView(self)
        self.layer.masksToBounds = true
    }
    
    func setProperties(delegate: CustomPincodeDelegate? = nil) {
        textFieldView.setTextFieldViewProperties()
        textField.placeholder = "Pincode"
        textField.text = ""
        textField.delegate = self
        textField.keyboardType = .numberPad

        self.delegate = delegate
        
        self.cityCode = ""
        arrList.removeAll()
    }
    
    func getFieldValue() -> String {
        return textField.text!
    }
    
    func getFieldKeyValue() -> String {
        if let pincode = pinCodeValue {
            return pincode
        }
        else {
            return getFieldValue()
        }
    }
    
    func setCity(code: String) {
        self.cityCode = code
        textField.text = ""
        arrList.removeAll()
    }
    
    func setFieldValue(text: String? = nil) {
        if let text = text {
            textField.text = text
        }
        else {
            setCity(code: "")
        }
    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        
        if cityCode.isEmpty {
            CommonAlert.shared().showAlert(message: "Please select city first")
            return
        }
        
        let param = ["city" : cityCode]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_PINCODE_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [[String: Any]]
            {
                self.arrList = response.map {
                    return DropDown(code: CommonUtils.shared().getValidatedString(string: $0["code"]),
                                    name: CommonUtils.shared().getValidatedString(string: $0["name"]),
                                    listDisplayValue: "\(CommonUtils.shared().getValidatedString(string: $0["name"])) (\(CommonUtils.shared().getValidatedString(string: $0["code"])))")
                }
                
                let storyboard = UIStoryboard.init(name: Storyboard.LOV_LIST, bundle: nil)
                
                if let vc = storyboard.instantiateViewController(withIdentifier: "LOVListVC") as? LOVListVC {
                    vc.setData(dropDownList: self.arrList, delegate: self, title: "Pincode")
                    AppDelegate.instance.applicationNavController.pushViewController(vc, animated: true)
                }
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            
        })
    }
}

extension CustomPincodeView: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textFieldView.layer.borderColor = Color.BLUE.cgColor
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        textFieldView.layer.borderColor = UIColor.lightGray.cgColor
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField.disableDoubleSpacePeriodIssue(shouldChangeCharactersRange: range, replacementString: string) == false {
            return false
        }
        
        if let text = textField.text, let textRange = Range(range, in: text), !string.isEmpty {
            let updatedText = text.replacingCharacters(in: textRange, with: string)
            return updatedText.isNumeric && updatedText.count <= 6
        }
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        delegate?.validatePincode()
    }
}

extension CustomPincodeView: LOVListDelegate {
    
    func selectedLOV(selectedObj: DropDown) {
        textField.text = selectedObj.code
        pinCodeValue = selectedObj.name
    }
}
