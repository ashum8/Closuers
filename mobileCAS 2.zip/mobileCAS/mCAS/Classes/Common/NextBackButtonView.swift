//
//  NextBackButtonView.swift
//  mCAS
//
//  Created by iMac on 09/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

@objc protocol NextBackButtonDelegate {
    @objc optional func nextButtonAction()
    @objc optional func backButtonAction()
}

class NextBackButtonView: UIView {
    
    @IBOutlet var containerVw: UIView!
    @IBOutlet weak var backButtonRightMargin: NSLayoutConstraint!
    @IBOutlet weak var nextButtonLeftMargin: NSLayoutConstraint!
    @IBOutlet weak var nextViewWidth: NSLayoutConstraint!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    
    private var delegate: NextBackButtonDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("NextBackButtonView", owner: self, options: nil)
        containerVw.fixInView(self)
    }
    
    func setProperties(showBack: Bool = false, backBtnTitle: String = "Back", showNext: Bool = true, nextBtnTitle: String = "Next", delegate: NextBackButtonDelegate) {
        
        self.layer.masksToBounds = true

        backButton.setBackButtonProperties()
        backButton.setTitle(backBtnTitle, for: .normal)
        
        nextButton.setButtonProperties()
        nextButton.setTitle(nextBtnTitle, for: .normal)
        
        backButton.isHidden = !showBack
        nextButton.isHidden = !showNext
        
        self.delegate = delegate
        
        if !showBack && showNext {
            nextViewWidth = nextViewWidth.changeMultiplier(multiplier: 1.0)
            nextButtonLeftMargin.constant = 20
        }
        else if !showNext && showBack {
            nextViewWidth = nextViewWidth.changeMultiplier(multiplier: 0.0)
            backButtonRightMargin.constant = 20
        }
    }
    
    @IBAction func doneButtonAction(_ sender: Any) {
        delegate?.nextButtonAction?()
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        delegate?.backButtonAction?()
    }
}
