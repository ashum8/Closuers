//
//  Webservices.swift
//  mCAS
//
//  Created by Mac on 20/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


class Webservices {
    
    public let HTTP_HEADER_TOKEN = "X-CSRF-TOKEN"
    public let HTTP_HEADER_COOKIE = "Set-Cookie"
    
//    fileprivate let BASE_URL = "http://10.1.52.209:8081"  //KUSHAL
//    fileprivate let BASE_URL = "http://10.1.52.81:8081"   //SIDDHARTHA
//    fileprivate let BASE_URL = "http://10.1.52.244:8082"    //NIKHIL
//    fileprivate let BASE_WEBAPP_URL = "/neutron-web/mobility/mcas"
    
//    fileprivate let BASE_URL = "http://10.1.61.204:8474"
//    fileprivate let BASE_URL = "http://10.1.61.204:8081"
    fileprivate let BASE_URL = "http://10.1.60.162:7373"    //QCT-28
//    fileprivate let BASE_URL = "http://10.1.61.179:7373"    //QCT-30
    fileprivate let BASE_WEBAPP_URL = "/neutron-webapp/mobility/mcas"
    
    private static var instance: Webservices?
    
    static func shared() -> Webservices {
        if instance == nil {
            instance = Webservices()
        }
        return instance!
    }
    
    private func getDefaultHeaders() -> [String : String] {
        let token = CommonUtils.shared().getValidatedString(string: CommonUtils.shared().getDataFromSecretUserDefault(key: HTTP_HEADER_TOKEN))
        let cookie = CommonUtils.shared().getValidatedString(string: CommonUtils.shared().getDataFromSecretUserDefault(key: HTTP_HEADER_COOKIE))
        
        return ["Accept"        : "application/json",
                "Content-Type"  : "application/json",
                "X-CSRF-TOKEN"  : token,
                "Cookie"        : cookie,
                "Cache-Control" : "no-cache"]
    }
    
    func POST(urlString: String, headers: [String : String]? = nil, paramaters: Any? = nil, autoHandleLoader: Bool? = nil, allowOfflineAlert: Bool = true, success:@escaping (_ headerDetail: [String : String]?, _ responseObject: Any) -> Void, failure: @escaping (_ error: String?) -> Void, noNetwork: @escaping (_ error: Bool?) -> Void) {
        
        if ReachabilityManager.isReachable() {
            
            do {
                self.showLoader(showLoader: autoHandleLoader)
                var params: Any?
                
                if paramaters == nil {
                    params = [:]
                }
                else {
                    params = paramaters
                }
                
                let postData = try JSONSerialization.data(withJSONObject: params as Any, options: [])
                
                let request = NSMutableURLRequest(url: NSURL(string: BASE_URL+BASE_WEBAPP_URL+urlString)! as URL,
                                                  cachePolicy: .useProtocolCachePolicy,
                                                  timeoutInterval: 30.0)
                request.httpMethod = "POST"
                request.httpBody = postData as Data
                request.httpShouldHandleCookies = false
                
                if headers == nil {
                    request.allHTTPHeaderFields = getDefaultHeaders()
                }
                else {
                    request.allHTTPHeaderFields = headers
                }
                
                print("URL = \(BASE_URL+BASE_WEBAPP_URL+urlString) \n HEADERS = \(String(describing: request.allHTTPHeaderFields)) \n\n\n\n")
                print("Request =======>>>>",NSString(data: postData, encoding: String.Encoding.utf8.rawValue)! as String)

                
                let dataTask = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
                    if error == nil {
                        
                        if let httpResponse = response as? HTTPURLResponse, let headerDetail = httpResponse.allHeaderFields as? [String : String], httpResponse.statusCode == 200 {
                            
                            do {
                                let jsonObject = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
								
                                if let cookie = headerDetail[self.HTTP_HEADER_COOKIE], !cookie.isEmpty {
                                    if let sessionID = cookie.components(separatedBy: ";").first {
                                        CommonUtils.shared().saveData(value: sessionID, key: self.HTTP_HEADER_COOKIE)
                                    }
                                }
                                
                                if let token = headerDetail[self.HTTP_HEADER_TOKEN] {
                                    CommonUtils.shared().saveData(value: token, key: self.HTTP_HEADER_TOKEN)
                                }
                                
                                self.hideLoader(hideLoader: autoHandleLoader)
                                
                                DispatchQueue.main.sync { success(headerDetail, jsonObject) }
                                
                                print("Response =======>>>>",NSString(data: data!, encoding: String.Encoding.utf8.rawValue)! as String)
                                
                                return
                            }
                            catch {}
                        }
                        else {
                            do {
                                print("Error =======>>>>",NSString(data: data!, encoding: String.Encoding.utf8.rawValue)! as String)

                                let jsonObject = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
                                
                                if let dictionary = jsonObject as? [String : Any] {
                                    
                                    if let errors = dictionary["errorEntries"] as? [[String : Any]], !errors.isEmpty, let code = errors[0]["errorCode"] as? String {
                                        
                                        var alert = ""
                                        
                                        switch code {
                                        case "ACCOUNT_LOCKED":
                                            alert = "Your account has been locked. Please contact system administrator"
                                            
                                        case "accountLocked":
                                            alert = "Your account has been locked. Please contact system administrator"
                                            
                                        case "ACCOUNT_EXPIRED":
                                            alert = "Your account has been expired. Please contact system administrator"
                                            
                                        case "CREDENTIALS_EXPIRED":
                                            alert = "Your credential has been expired. Please contact system administrator"
                                            
                                        case "USER_DISABLED":
                                            alert = "Your account is not enabled. Please contact system administrator"
                                            
                                        case "BAD_CREDENTIALS":
                                            alert = "Please enter a valid userid or password"
                                            
                                        case "USER_NOT_EXISTS":
                                            alert = "Unable to send OTP at the moment. Please try after sometime"
                                            
                                        case "ERROR_IN_SENDING_SMS":
                                            alert = "Unable to send OTP at the moment. Please try after sometime"
                                            
                                        case "user_not_authenticated":
                                            alert = "User is not authenticated"
                                            
                                        case "badCredentials":
                                            alert = "Please enter a valid userid or password"
                                            
                                        case "password_matches_recent_password":
                                            alert = "New password matches recent password.Please use different password"
                                            
                                        case "wrong_old_password":
                                            alert = "Password is not correct"
                                            
                                        case "maximum_number_of_attempts_exceeded":
                                            alert = "Maximum number of attempts exceeded"
                                            
                                        case "User_security_answers_not_complete":
                                            alert = "User security answers not complete"
                                            
                                        case "Two_security_question_answers_should_be_there":
                                            alert = "Two security question answers should be there"
                                            
                                        case "INVALID_MODULE_CODE":
                                            alert = "Invalid Module Code"
                                            
                                        case "INVALID_MODULE_CREDENTIALS":
                                            alert = "Invalid Module Credentials"
                                            
                                        case "LOGIN_NOT_ALLOWED_IN_MODULE":
                                            alert = "You are not allowed to login in this module"
                                            
                                        case "UNRECOGNIZED_DEVICE":
                                            alert = "Unrecognized Device"
                                            
                                        case "NO_DATA_AVAILABLE":
                                            alert = ServiceUrl.ALERT_NO_DATA
                                            
                                        case "SERVER_ERROR":
                                            alert = "Server Error"
                                            
                                        case "SESSION_EXPIRED":
                                            alert = "SESSION EXPIRED"
                                            
                                        case "INVALID_OR_MISSING_CSRF":
                                            alert = "SESSION EXPIRED"
                                            
                                        case "INVALID_PINCODE":
                                            alert = "Please enter valid pincode"
                                            
                                        case "FORM_NOT_FOUND":
                                            alert = "You can not perform this operation as template data is not available"
                                            
                                        default:
                                            alert = ServiceUrl.ALERT_SERVICE_ERROR
                                        }
                                        
                                        self.hideLoader(hideLoader: autoHandleLoader)
                                        
                                        if alert == "SESSION EXPIRED" {
                                            DispatchQueue.main.async {
                                                failure(nil)
                                                CommonAlert.shared().showAlertForInvalidSession()
                                            }
                                        }
                                        else if alert == ServiceUrl.ALERT_SERVICE_ERROR, let message = errors[0]["errorMessage"] as? String {
                                            DispatchQueue.main.async { failure(message) }
                                        }
                                        else {
                                            DispatchQueue.main.async { failure(alert) }
                                        }
                                        
                                        return
                                    }
                                    else {
                                        self.hideLoader(hideLoader: autoHandleLoader)
                                        
                                        if let message = dictionary["error"] as? String {
                                            DispatchQueue.main.async { failure(message) }
                                            return
                                        }
                                    }
                                }
                            }
                            catch {}
                        }
                    }
                    
                    DispatchQueue.main.async { failure(ServiceUrl.ALERT_SERVICE_ERROR) }
                    
                    self.hideLoader(hideLoader: autoHandleLoader)
                })
                
                dataTask.resume()
            }
            catch {
                DispatchQueue.main.async { failure(ServiceUrl.ALERT_SERVICE_ERROR) }
                
                self.hideLoader(hideLoader: autoHandleLoader)
            }
        }
        else {
            if allowOfflineAlert {
                CommonAlert.shared().showOfflineAlert()
            }
            DispatchQueue.main.async { noNetwork(true) }
        }
    }
    
    private func showLoader(showLoader: Bool? = nil) {
        DispatchQueue.main.async {
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
            
            if let vc = AppDelegate.instance.applicationNavController.viewControllers.last, showLoader == true {
                MRProgressOverlayView.showOverlayAdded(to: vc.view, animated: true)
            }
        }
    }
    
    private func hideLoader(hideLoader: Bool? = nil) {
        DispatchQueue.main.async {
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            
            if let vc = AppDelegate.instance.applicationNavController.viewControllers.last, hideLoader == true {
                MRProgressOverlayView.dismissAllOverlays(for: vc.view, animated: true)
            }
        }
    }
    
    func logoutFromServer(username: String? = nil, allowOfflineAlert: Bool = true, success:@escaping (_ success: Bool?) -> Void) {
        var usrName = ""
        if username == nil {
            usrName = AppDelegate.instance.getSavedUserID()
        }
        
        let param = ["username"     : usrName,
                     "moduleCode"   : "mCAS"]
        
        POST(urlString: ServiceUrl.LOGOUT_URL, paramaters: param, allowOfflineAlert: allowOfflineAlert, success: { (header ,responseObj) in
            success(true)
            
        }, failure: { (error) in    success(false) },
           noNetwork: { (error) in  success(false) })
    }
    
    func getTokenFromServer(withSession: Bool, success:@escaping (_ token: String?) -> Void) {
        
        var headers: [String : String]
        
        if withSession {
            headers = getDefaultHeaders()
        }
        else {
            headers = ["Accept"        : "application/json",
                       "Content-Type"  : "application/json",
                       "Cache-Control" : "no-cache"]
        }
        
        POST(urlString: ServiceUrl.CREATE_TOKEN_URL, headers: headers, success: { (headerDetail, responseObj) in
            
            if let dictionary = responseObj as? [String : String], let syncToken = dictionary["synchronizerToken"] {
                success(syncToken)
            }
            else {
                success(nil)
                CommonAlert.shared().showAlert(message: NSLocalizedString(ServiceUrl.ALERT_SERVICE_ERROR, comment: ""))
            }
            
        }, failure: { (error) in
            success(nil)
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (noNetwork) in
            success(nil)
        })
    }
    
    func fetchDecisionReasonMaster() {
        let param = ["stage" : "Waiver"]
        
        POST(urlString: ServiceUrl.GET_DECISION_REASONS_URL, paramaters: param, allowOfflineAlert: false, success: { (header ,responseObj) in
            if let masters = responseObj as? [[String : String]] {
                CommonRAData.shared().reasonMasterArray = masters
                CommonRAData.shared().reasonMasterArray.insert(["code"        : "Other",
                                                                "name"        : "other",
                                                                "masterType"  : "Other"], at: 0)
            }
            
        }, failure: { (error) in },
           noNetwork: { (error) in })
    }
    
    func loadMasterData() {
        var tempArray:[[String:String]] = []
        
        if let timeStampArray = AppDelegate.instance.currentLoggedInUser.getDropDownEntityUpdateArray(), !timeStampArray.isEmpty {
            
            tempArray = timeStampArray.map({ (dropDownCD) -> [String:String] in
                
                ["masterName"       : dropDownCD.masterName!,
                 "lastUpdatedTime"   : dropDownCD.timeStamp ?? ""]
            })
        }
        
        fetchMasterByGroupID(tempArray: tempArray, groupID: "1")
        fetchMasterByGroupID(tempArray: tempArray, groupID: "2")
        fetchMasterByGroupID(tempArray: tempArray, groupID: "3")
        fetchMasterByGroupID(tempArray: tempArray, groupID: "4")
        fetchMasterByGroupID(tempArray: tempArray, groupID: "5")
        fetchMasterByGroupID(tempArray: tempArray, groupID: "6")
        fetchMasterByGroupID(tempArray: tempArray, groupID: "7")
        fetchMasterByGroupID(tempArray: tempArray, groupID: "8")
    }
    
    private func fetchMasterByGroupID(tempArray:[[String:String]], groupID: String) {
        let param = ["groupId"      : groupID,
                     "masterStatus" : tempArray] as [String : Any]
        
        POST(urlString: ServiceUrl.GET_MASTERS_URL, paramaters: param, allowOfflineAlert: false, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let outerMasterObj = response["masters"] as? [[String : Any]]
            {
                for dic in outerMasterObj
                {
                    CoreDataOperations.shared().updateMasterRecords(dic: dic)
                }
            }
            
        }, failure: { (error) in },
           noNetwork: { (error) in })
    }
    
    func viewPdfReport(params: [String: String]) {
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_LOAN_REPORT_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
            
            if let response = responseObj as? [String: Any]
            {
                let pdfData = CommonUtils.shared().getValidatedString(string: response["pdfData"])
                
                if !pdfData.isEmpty {
                    let storyboard = UIStoryboard.init(name: Storyboard.EXISTING_LOANS, bundle: nil)
                    
                    if let vc = storyboard.instantiateViewController(withIdentifier: "PDFViewer") as? PDFViewer {
                        vc.setData(base64Str: pdfData)
                        AppDelegate.instance.applicationNavController.pushViewController(vc, animated: true)
                    }
                }
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            
        })
    }
    
    func emailPdfReport(params: [String: String]) {
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_LOAN_REPORT_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
            
            CommonAlert.shared().showAlert(message: "Email has been sent successfully.")
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            
        })
    }
}
