//
//  ServiceUrl.swift
//  mCAS
//
//  Created by Mac on 27/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation


@objcMembers
public class ServiceUrl: NSObject {
    
    public static let ALERT_SERVICE_ERROR               = "Service Error"
    public static let ALERT_NO_DATA                     = "No Data Found"
    
    //Login/Change Password
    public static let CREATE_TOKEN_URL                  = "/handshake"
    public static let LOGIN_URL                         = "/login/submit/formbased"
    public static let LOGOUT_URL                        = "/logout/submit"
    public static let CHANGE_PASSWORD_URL               = "/change-password"
    public static let FORGOT_PASSWORD_URL               = "/rest/password/forgot"
    public static let RESET_PASSWORD_GET_OTP_URL        = "/forgot-password/generate-otp"
    public static let RESET_PASSWORD_VERIFY_OTP_URL     = "/forgot-password/verify-otp"
    public static let RESET_PASSWORD_URL                = "/forgot-password/reset-password"
    public static let FORCE_CHANGE_PASSWORD_URL         = "/first-login/force-change-password"
    
    //Masters
    public static let GET_MASTERS_URL                   = "/getmastersbygroup"
    public static let GET_PINCODE_URL                   = "/master/getzipcodes"
    public static let GET_ALL_DEALER_MASTER_URL         = "/master/getdealer"
    public static let GET_ALL_DETAILBYZIP_MASTER_URL    = "/master/getdetailsbyzipcode"

    
    //EMI Calculator
    public static let EMAIL_AMORTIZATION_SCHEDULE_URL   = "/rest/amortizationcalculator/emailAmortizationSchedule"
       
    //Rate Approval
    public static let SEARCH_APPLICATION_URL            = "/rate-approval/search-applications"
    public static let GET_CASE_DETAIL_URL               = "/rate-approval/get-application-details"
    public static let SUBMIT_APPLICATION_URL            = "/rate-approval/submit-application"
    public static let BULK_ACTION_URL                   = "/rate-approval/bulk-action"
    public static let GET_AUTHORITIES_URL               = "/getcurrentuserauthorities"
    public static let GET_DECISION_REASONS_URL          = "/getdecisionreasonbystage"
    public static let GET_USERS_URL                     = "/user/searchusersbyrole"

    //Lead
    public static let GET_LEAD_LIST_URL                 = "/lead/getforrange"
    public static let CREATE_LEAD_URL                   = "/lead/create"
    
    
    //Existing Loans
    public static let GET_EXISTING_LOANS_URL            = "/existingloans/search"
    public static let GET_LOAN_REPORT_URL               = "/reportparameter/execute"
    public static let GET_IT_CERTIFICATE_MASTER_URL     = "/itc/masters"
    public static let GET_LOAN_TRANSACTIONS_URL         = "/transaction/getall"
    public static let GET_MASTERS_RAISE_REQUEST_URL     = "/customerrequest/getmasters"
    public static let RAISE_REQUEST_URL                 = "/customerrequest/create"
    
    //Sourcing
    public static let GET_SOURCING_LIST_URL             = "/loancontract/getall"
    public static let SAVE_LOAN_URL                     = "/loancontract/save"
    public static let GET_LOAN_DETAIL_URL               = "/loancontract/get"
    public static let GET_ALL_CUSTOMERS_URL             = "/loancontract/getallcustomers"
    public static let SAVE_CUSTOMER_URL                 = "/customer/save"
    public static let DELETE_CUSTOMER_URL               = "/customer/delete"
    public static let GET_CUSTOMER_URL                  = "/customer/get"
    public static let SAVE_IDENTIFICATION_URL           = "/identification/save"
    public static let GET_ALL_IDENTIFICATION_URL        = "/identification/getall"
    public static let DELETE_IDENTIFICATION_URL         = "/identification/del"
    public static let SAVE_EMPLOYMENT_URL               = "/employment/save"
    public static let GET_ALL_EMPLOYMENT_URL            = "/employment/getall"
    public static let DELETE_EMPLOYMENT_URL             = "/employment/del"
    public static let GET_ALL_ADDRESS_URL               = "/address/getall"
    public static let SAVE_ADDRESS_URL                  = "/address/save"
    public static let DELETE_ADDRESS_URL                = "/address/del"
    public static let GET_ALL_INCOME_URL                = "/income/getall"
    public static let SAVE_INCOME_URL                   = "/income/save"
    public static let DELETE_INCOME_URL                 = "/income/del"
    public static let GET_ALL_DEDUCTION_URL             = "/deduction/getall"
    public static let SAVE_DEDUCTION_URL                = "/deduction/save"
    public static let DELETE_DEDUCTION_URL              = "/deduction/del"
    public static let GET_ALL_EXPENSE_URL               = "/expense/getall"
    public static let SAVE_EXPENSE_URL                  = "/expense/save"
    public static let DELETE_EXPENSE_URL                = "/expense/del"
    public static let GET_ALL_ASSET_URL                 = "/incomeasset/getall"
    public static let SAVE_ASSET_URL                    = "/incomeasset/save"
    public static let DELETE_ASSET_URL                  = "/incomeasset/del"
    public static let GET_ALL_LIABILITY_URL             = "/liability/getall"
    public static let SAVE_LIABILITY_URL                = "/liability/save"
    public static let DELETE_LIABILITY_URL              = "/liability/del"
    public static let GET_ALL_COLLATERAL_URL            = "/loancontract/getcollateral"
    public static let SAVE_COLLATERAL_URL               = "/loancollateral/save"
    public static let DELETE_COLLATERAL_URL             = "/loancollateral/delete"
    public static let GET_ALL_APPLICATION_DETAIL_URL    = "/loancontract/getalldetails"
    public static let SUBMIT_SOURCING_APPLICATION_URL   = "/loancontract/submit"
    public static let REJECT_SOURCING_APPLICATION_URL   = "/loancontract/reject"
    public static let SUBMIT_REFERENCE_URL              = "/loanreference/create"
    public static let GET_ALL_REFERENCE_URL             = "/loanreference/getAll"
    public static let DELETE_REFERENCE_URL              = "/loanreference/delete"
    public static let GET_ALL_PROCESSING_FEE_URL        = "/imd/get"
    public static let SAVE_PROCESSING_FEE_URL           = "/imd/save"
    public static let DELETE_PROCESSING_FEE_URL         = "/imd/delete"
    
    
    

    
    
    //Sourcing - Interfaces
    public static let INITIATE_POSIDEX_URL              = "/posidex/initiate"
    public static let GET_POSIDEX_REPORT_URL            = "/posidex/report"

    
    //FIV
    public static let GET_ALL_FI_CASES_URL              = "/fiv/getAssignedCases"
    public static let SEARCH_CASES_FI_URL               = "/fiv/onlineSearch"
    public static let GET_DYNAMIC_FORM_ONLINE_FI_URL    = "/fiv/getDynamicFormOnline"
    public static let SAVE_DATA_FI_URL                  = "/fiv/saveData"
    public static let SUBMIT_FI_URL                     = "/fiv/submit"

    //Status Enquiry
    public static let GET_ALL_CASES_SE_URL              = "/statusenquiry/getapplicationsfordaterange"
    public static let SEARCH_CASES_SE_URL               = "/statusenquiry/getstatus"
    public static let GET_CASE_DETAIL_SE_URL            = "/statusenquiry/statuscheck"
    public static let GET_DOC_CHECKLIST_SE_URL          = "/statusenquiry/getdocumentchecklist"

    
}

