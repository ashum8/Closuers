import Foundation

@objc(CDUserRoles)
open class CDUserRoles: _CDUserRoles {
	// Custom logic goes here.
}
