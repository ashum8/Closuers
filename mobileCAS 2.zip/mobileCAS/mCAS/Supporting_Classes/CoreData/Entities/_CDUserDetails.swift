// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to CDUserDetails.swift instead.

import Foundation
import CoreData

public enum CDUserDetailsAttributes: String {
    case encryptedpassword = "encryptedpassword"
    case loginTime = "loginTime"
    case name = "name"
    case token = "token"
    case username = "username"
}

public enum CDUserDetailsRelationships: String {
    case dropDown = "dropDown"
    case dropDownEntityUpdate = "dropDownEntityUpdate"
    case savedLead = "savedLead"
    case userRoles = "userRoles"
}

open class _CDUserDetails: NSManagedObject {

    // MARK: - Class methods

    open class func entityName () -> String {
        return "CDUserDetails"
    }

    open class func entity(managedObjectContext: NSManagedObjectContext) -> NSEntityDescription? {
        return NSEntityDescription.entity(forEntityName: self.entityName(), in: managedObjectContext)
    }

    @nonobjc
    open class func fetchRequest() -> NSFetchRequest<CDUserDetails> {
        return NSFetchRequest(entityName: self.entityName())
    }

    // MARK: - Life cycle methods

    public override init(entity: NSEntityDescription, insertInto context: NSManagedObjectContext?) {
        super.init(entity: entity, insertInto: context)
    }

    public convenience init?(managedObjectContext: NSManagedObjectContext) {
        guard let entity = _CDUserDetails.entity(managedObjectContext: managedObjectContext) else { return nil }
        self.init(entity: entity, insertInto: managedObjectContext)
    }

    // MARK: - Properties

    @NSManaged open
    var encryptedpassword: String?

    @NSManaged open
    var loginTime: Date?

    @NSManaged open
    var name: String?

    @NSManaged open
    var token: String?

    @NSManaged open
    var username: String?

    // MARK: - Relationships

    @NSManaged open
    var dropDown: NSSet

    open func dropDownSet() -> NSMutableSet {
        return self.dropDown.mutableCopy() as! NSMutableSet
    }

    @NSManaged open
    var dropDownEntityUpdate: NSSet

    open func dropDownEntityUpdateSet() -> NSMutableSet {
        return self.dropDownEntityUpdate.mutableCopy() as! NSMutableSet
    }

    @NSManaged open
    var savedLead: NSSet

    open func savedLeadSet() -> NSMutableSet {
        return self.savedLead.mutableCopy() as! NSMutableSet
    }

    @NSManaged open
    var userRoles: NSOrderedSet

    open func userRolesSet() -> NSMutableOrderedSet {
        return self.userRoles.mutableCopy() as! NSMutableOrderedSet
    }

}

extension _CDUserDetails {

    open func addDropDown(_ objects: NSSet) {
        let mutable = self.dropDown.mutableCopy() as! NSMutableSet
        mutable.union(objects as Set<NSObject>)
        self.dropDown = mutable.copy() as! NSSet
    }

    open func removeDropDown(_ objects: NSSet) {
        let mutable = self.dropDown.mutableCopy() as! NSMutableSet
        mutable.minus(objects as Set<NSObject>)
        self.dropDown = mutable.copy() as! NSSet
    }

    open func addDropDownObject(_ value: CDDropDown) {
        let mutable = self.dropDown.mutableCopy() as! NSMutableSet
        mutable.add(value)
        self.dropDown = mutable.copy() as! NSSet
    }

    open func removeDropDownObject(_ value: CDDropDown) {
        let mutable = self.dropDown.mutableCopy() as! NSMutableSet
        mutable.remove(value)
        self.dropDown = mutable.copy() as! NSSet
    }

}

extension _CDUserDetails {

    open func addDropDownEntityUpdate(_ objects: NSSet) {
        let mutable = self.dropDownEntityUpdate.mutableCopy() as! NSMutableSet
        mutable.union(objects as Set<NSObject>)
        self.dropDownEntityUpdate = mutable.copy() as! NSSet
    }

    open func removeDropDownEntityUpdate(_ objects: NSSet) {
        let mutable = self.dropDownEntityUpdate.mutableCopy() as! NSMutableSet
        mutable.minus(objects as Set<NSObject>)
        self.dropDownEntityUpdate = mutable.copy() as! NSSet
    }

    open func addDropDownEntityUpdateObject(_ value: CDDropDownEntityUpdate) {
        let mutable = self.dropDownEntityUpdate.mutableCopy() as! NSMutableSet
        mutable.add(value)
        self.dropDownEntityUpdate = mutable.copy() as! NSSet
    }

    open func removeDropDownEntityUpdateObject(_ value: CDDropDownEntityUpdate) {
        let mutable = self.dropDownEntityUpdate.mutableCopy() as! NSMutableSet
        mutable.remove(value)
        self.dropDownEntityUpdate = mutable.copy() as! NSSet
    }

}

extension _CDUserDetails {

    open func addSavedLead(_ objects: NSSet) {
        let mutable = self.savedLead.mutableCopy() as! NSMutableSet
        mutable.union(objects as Set<NSObject>)
        self.savedLead = mutable.copy() as! NSSet
    }

    open func removeSavedLead(_ objects: NSSet) {
        let mutable = self.savedLead.mutableCopy() as! NSMutableSet
        mutable.minus(objects as Set<NSObject>)
        self.savedLead = mutable.copy() as! NSSet
    }

    open func addSavedLeadObject(_ value: CDLeadSave) {
        let mutable = self.savedLead.mutableCopy() as! NSMutableSet
        mutable.add(value)
        self.savedLead = mutable.copy() as! NSSet
    }

    open func removeSavedLeadObject(_ value: CDLeadSave) {
        let mutable = self.savedLead.mutableCopy() as! NSMutableSet
        mutable.remove(value)
        self.savedLead = mutable.copy() as! NSSet
    }

}

extension _CDUserDetails {

    open func addUserRoles(_ objects: NSOrderedSet) {
        let mutable = self.userRoles.mutableCopy() as! NSMutableOrderedSet
        mutable.union(objects)
        self.userRoles = mutable.copy() as! NSOrderedSet
    }

    open func removeUserRoles(_ objects: NSOrderedSet) {
        let mutable = self.userRoles.mutableCopy() as! NSMutableOrderedSet
        mutable.minus(objects)
        self.userRoles = mutable.copy() as! NSOrderedSet
    }

    open func addUserRolesObject(_ value: CDUserRoles) {
        let mutable = self.userRoles.mutableCopy() as! NSMutableOrderedSet
        mutable.add(value)
        self.userRoles = mutable.copy() as! NSOrderedSet
    }

    open func removeUserRolesObject(_ value: CDUserRoles) {
        let mutable = self.userRoles.mutableCopy() as! NSMutableOrderedSet
        mutable.remove(value)
        self.userRoles = mutable.copy() as! NSOrderedSet
    }

}

