// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to CDDropDown.swift instead.

import Foundation
import CoreData

public enum CDDropDownAttributes: String {
    case code = "code"
    case id = "id"
    case masterName = "masterName"
    case name = "name"
    case parentKey = "parentKey"
    case subParentKey = "subParentKey"
}

public enum CDDropDownRelationships: String {
    case loginUser = "loginUser"
}

open class _CDDropDown: NSManagedObject {

    // MARK: - Class methods

    open class func entityName () -> String {
        return "CDDropDown"
    }

    open class func entity(managedObjectContext: NSManagedObjectContext) -> NSEntityDescription? {
        return NSEntityDescription.entity(forEntityName: self.entityName(), in: managedObjectContext)
    }

    @nonobjc
    open class func fetchRequest() -> NSFetchRequest<CDDropDown> {
        return NSFetchRequest(entityName: self.entityName())
    }

    // MARK: - Life cycle methods

    public override init(entity: NSEntityDescription, insertInto context: NSManagedObjectContext?) {
        super.init(entity: entity, insertInto: context)
    }

    public convenience init?(managedObjectContext: NSManagedObjectContext) {
        guard let entity = _CDDropDown.entity(managedObjectContext: managedObjectContext) else { return nil }
        self.init(entity: entity, insertInto: managedObjectContext)
    }

    // MARK: - Properties

    @NSManaged open
    var code: String?

    @NSManaged open
    var id: NSNumber?

    @NSManaged open
    var masterName: String?

    @NSManaged open
    var name: String?

    @NSManaged open
    var parentKey: String?

    @NSManaged open
    var subParentKey: String?

    // MARK: - Relationships

    @NSManaged open
    var loginUser: CDUserDetails?

}

