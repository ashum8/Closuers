//
//  TIMERUIApplication.swift
//  mCAS
//
//  Created by Mac on 19/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation
import UIKit


class TIMERUIApplication: UIApplication {
    
    //the notification your AppDelegate needs to watch for in order to know that it has indeed "timed out"
    static let kApplicationDidTimeoutNotification = "AppTimout"

    //the length of time before your application "times out". This number actually represents seconds, so we'll have to multiple it by 60
    static let kApplicationTimeoutInMinutes: TimeInterval = 15 * 60
    
    var idleTimer: Timer?
    
    override func sendEvent(_ event: UIEvent)
    {
        super.sendEvent(event)
        if event.allTouches?.contains(where: { $0.phase == .began || $0.phase == .moved }) == true {
            resetIdleTimer()
        }
    }

    //as labeled...reset the timer
    func resetIdleTimer()
    {
        idleTimer?.invalidate()
                
        //convert the wait period into minutes rather than seconds
        idleTimer = Timer.scheduledTimer(timeInterval: TIMERUIApplication.kApplicationTimeoutInMinutes, target: self, selector: #selector(idleTimerExceeded), userInfo: nil, repeats: false)
    }

    //if the timer reaches the limit as defined in kApplicationTimeoutInMinutes, post this notification
    @objc func idleTimerExceeded()
    {
        let nc = NotificationCenter.default
        nc.post(name: Notification.Name(TIMERUIApplication.kApplicationDidTimeoutNotification), object: nil)
    }
}


