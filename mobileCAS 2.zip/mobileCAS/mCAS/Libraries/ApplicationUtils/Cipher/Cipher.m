//
//  Cipher.m
//  mCAS
//
//  Created by Mac on 20/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

#import "Cipher.h"
#import <CommonCrypto/CommonCrypto.h>


@implementation Cipher


+ (NSString *)getEncryptedPassword:(NSString *)password withUsername:(NSString *)username withToken:(NSString *)token
{
    NSString *password_md5 = [self md5:password];
    NSString *password_sha256 = [self sha256:[password stringByAppendingString:token]];
    NSString *password_base12 = [self base12ConversionWithUsername:username andPassword:password];
    NSString *password_final = @"";
    
    for(int i=0; i<32; i=i+2){
        NSRange range = NSMakeRange(i, 2);
        password_final = [password_final stringByAppendingString:[password_sha256 substringWithRange:range]];
        password_final = [password_final stringByAppendingString:[password_md5 substringWithRange:range]];
        password_final = [password_final stringByAppendingString:[password_base12 substringWithRange:range]];
    }
    password_final = [password_final stringByAppendingString:[password_sha256 substringWithRange:NSMakeRange(32, 32)]];
    return password_final;
}

+ (NSData *)AES128DefaultEncryptionWithKey:(NSString *)key withData:(NSData *)data withOperation:(CCOperation)operation{
    char keyPtr[kCCKeySizeAES128 + 1];
    bzero(keyPtr, sizeof(keyPtr));
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    
    char ivPtr[kCCBlockSizeAES128 + 1];
    bzero(ivPtr, sizeof(ivPtr));
    
    size_t bufferSize = [data length] + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    
    size_t cryptBytes = 0;
    CCCryptorStatus cryptStatus = CCCrypt(operation,
                                          kCCAlgorithmAES128,
                                          kCCOptionPKCS7Padding | kCCOptionECBMode,
                                          keyPtr,
                                          kCCBlockSizeAES128,
                                          ivPtr,
                                          [data bytes],
                                          [data length],
                                          buffer,
                                          bufferSize,
                                          &cryptBytes);
    if (cryptStatus == kCCSuccess) {
        return [NSData dataWithBytesNoCopy:buffer length:cryptBytes];
    }
    free(buffer);
    return nil;
}

+ (NSString *)encryptString:(NSString*)plaintext withKey:(NSString*)key {
    return [[self AES128DefaultEncryptionWithKey:key withData:[plaintext dataUsingEncoding:NSUTF8StringEncoding] withOperation:kCCEncrypt] base64EncodedStringWithOptions:0];
}

+ (NSString *)decryptData:(NSData *)ciphertext withKey:(NSString*)key {
    return [[NSString alloc] initWithData:[self AES128DefaultEncryptionWithKey:key withData:ciphertext withOperation:kCCDecrypt] encoding:NSUTF8StringEncoding];
}

+ (NSString *)sha1:(NSString*)input
{
    const char *cstr = [input cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:input.length];
    
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    
    CC_SHA1(data.bytes, (unsigned int)data.length, digest);
    
    NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];
    
    return output;
}

+ (NSString *)sha256:(NSString *)input
{
    const char* str = [input UTF8String];
    unsigned char result[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(str, (CC_LONG)strlen(str), result);
    
    NSMutableString *ret = [NSMutableString stringWithCapacity:CC_SHA256_DIGEST_LENGTH*2];
    for(int i = 0; i<CC_SHA256_DIGEST_LENGTH; i++)
    {
        [ret appendFormat:@"%02x",result[i]];
    }
    return ret;
}

+ (NSString *)md5:(NSString *)input
{
    const char *cStr = [input UTF8String];
    unsigned char digest[16];
    CC_MD5( cStr, (unsigned int)strlen(cStr), digest ); // This is the md5 call
    
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_MD5_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];
    
    return  output;
}

+ (NSData *)decodeBase64String:(NSString *)base64String {
    return [[NSData alloc] initWithBase64EncodedString:base64String options:0];
}

+ (NSData *)base64DataFromString:(NSString *)string {
    unsigned long ixtext, lentext;
    unsigned char ch, inbuf[4], outbuf[3];
    short i, ixinbuf;
    Boolean flignore, flendtext = false;
    const unsigned char *tempcstring;
    NSMutableData *theData;
    
    if (string == nil) {
        return [NSData data];
    }
    
    ixtext = 0;
    
    tempcstring = (const unsigned char *)[string UTF8String];
    
    lentext = [string length];
    
    theData = [NSMutableData dataWithCapacity: lentext];
    
    ixinbuf = 0;
    
    while (true)
    {
        if (ixtext >= lentext)
        {
            break;
        }
        
        ch = tempcstring [ixtext++];
        
        flignore = false;
        
        if ((ch >= 'A') && (ch <= 'Z'))
        {
            ch = ch - 'A';
        }
        else if ((ch >= 'a') && (ch <= 'z'))
        {
            ch = ch - 'a' + 26;
        }
        else if ((ch >= '0') && (ch <= '9'))
        {
            ch = ch - '0' + 52;
        }
        else if (ch == '+')
        {
            ch = 62;
        }
        else if (ch == '=')
        {
            flendtext = true;
        }
        else if (ch == '/')
        {
            ch = 63;
        }
        else
        {
            flignore = true;
        }
        
        if (!flignore)
        {
            short ctcharsinbuf = 3;
            Boolean flbreak = false;
            
            if (flendtext)
            {
                if (ixinbuf == 0)
                {
                    break;
                }
                
                if ((ixinbuf == 1) || (ixinbuf == 2))
                {
                    ctcharsinbuf = 1;
                }
                else
                {
                    ctcharsinbuf = 2;
                }
                
                ixinbuf = 3;
                
                flbreak = true;
            }
            
            inbuf [ixinbuf++] = ch;
            
            if (ixinbuf == 4)
            {
                ixinbuf = 0;
                
                outbuf[0] = (inbuf[0] << 2) | ((inbuf[1] & 0x30) >> 4);
                outbuf[1] = ((inbuf[1] & 0x0F) << 4) | ((inbuf[2] & 0x3C) >> 2);
                outbuf[2] = ((inbuf[2] & 0x03) << 6) | (inbuf[3] & 0x3F);
                
                for (i = 0; i < ctcharsinbuf; i++)
                {
                    [theData appendBytes: &outbuf[i] length: 1];
                }
            }
            
            if (flbreak)
            {
                break;
            }
        }
    }
    
    return theData;
}

+ (NSString *)base12ConversionWithUsername:(NSString *)username andPassword:(NSString *)password
{
    int j=0;
    
    NSString *encrypted_text = @"";
    username = [username uppercaseString];
    NSMutableArray *temporary = [[NSMutableArray alloc] init];
    
    for(int i=0;i<16;i++) {
        if(i<[username length] && i<[password length]) {
            j = [username characterAtIndex:i] + [password characterAtIndex:i];
        }
        else if(i < [username length]) {
            j = [username characterAtIndex:i] + 0;
        }
        else if(i<[password length]) {
            j = [password characterAtIndex:i] + 0;
        }
        else {
            j=0;
        }
        
        j = j%255;
        
        [temporary addObject:[NSNumber numberWithInt:j]];
    }
    
    NSString *temp = @"";
    for(int i=0;i<16;i++) {
        int t = 0;
        t = (int)[[temporary objectAtIndex:i] integerValue];
        
        int a = t%16;
        int b = (t-a)/16;
        
        if(b<10){
            temp = [NSString stringWithFormat:@"%c",b+48];
        }
        else{
            temp = [NSString stringWithFormat:@"%c",b-10+65];
        }
        
        if(a<10) {
            temp = [temp stringByAppendingString:[NSString stringWithFormat:@"%c",a+48]];
        }
        else{
            temp = [temp stringByAppendingString:[NSString stringWithFormat:@"%c",a-10+65]];
        }
        
        encrypted_text = [encrypted_text stringByAppendingString:temp];
    }
    return encrypted_text;
}

+ (NSString *)encrypt:(NSString *)plainText withToken:(NSString *)token {
    return [[self AESEncryption:[plainText dataUsingEncoding:NSUTF8StringEncoding] withToken:token withOperation:kCCEncrypt] base64EncodedStringWithOptions:0];
}

+ (NSString *)decrypt:(NSString *)encryptedBase64String withToken:(NSString *)token {
    NSData *dataToDecrypt = [[NSData alloc] initWithBase64EncodedString:encryptedBase64String options:0];
    return [[NSString alloc] initWithData:[self AESEncryption:dataToDecrypt  withToken:token withOperation:kCCDecrypt] encoding:NSUTF8StringEncoding];
}

+ (NSMutableData *)AESEncryption:(NSData *)dataIn withToken:(NSString *)token withOperation:(CCOperation)operation {
    
    NSString *const IV = @"0000000000000000";
    
    CCCryptorStatus ccStatus    = kCCSuccess;
    size_t          cryptBytes  = 0;
    NSMutableData  *dataOut     = [NSMutableData dataWithLength:dataIn.length + kCCBlockSizeAES128];
    NSData         *key         = [self AESEncyptSaltWithToken:token];
    NSData         *iv          = [IV dataUsingEncoding:NSUTF8StringEncoding];
    
    ccStatus = CCCrypt(operation,
                       kCCAlgorithmAES,
                       kCCOptionPKCS7Padding,
                       key.bytes,
                       key.length,
                       (iv)?nil:iv.bytes,
                       dataIn.bytes,
                       dataIn.length,
                       dataOut.mutableBytes,
                       dataOut.length,
                       &cryptBytes);
    
    if (ccStatus == kCCSuccess) {
        dataOut.length = cryptBytes;
    }
    else {
        dataOut = nil;
    }
    
    return dataOut;
}

+ (NSData *)AESEncyptSaltWithToken:(NSString *)token {
    NSString *saltHex = @"f07be5c468ba8bfb";
    NSData *keyData = [token dataUsingEncoding:NSUTF8StringEncoding];
    NSData *salt    = [self generateHex:saltHex];
    uint    rounds  = 10000;
    uint    keySize = kCCKeySizeAES128;
    
    NSMutableData *derivedKey = [NSMutableData dataWithLength:keySize];
    
    CCKeyDerivationPBKDF(kCCPBKDF2,               // algorithm
                         keyData.bytes,           // password
                         keyData.length,          // passwordLength
                         salt.bytes,              // salt
                         salt.length,             // saltLen
                         kCCPRFHmacAlgSHA1,       // PRF
                         rounds,                  // rounds
                         derivedKey.mutableBytes, // derivedKey
                         derivedKey.length);      // derivedKeyLen
    
    //    NSLog(@"derivedKey: %@", [derivedKey base64EncodedStringWithOptions:NSUTF8StringEncoding]);
    return derivedKey;
}

+ (NSData *)generateHex:(NSString *)saltHex {
    NSMutableData *salt = [NSMutableData dataWithCapacity:saltHex.length/2];
    
    for (int i = 0; i < [saltHex length]; i += 2) {
        Byte k = [self hexToByte:[saltHex substringWithRange:NSMakeRange(i, 2)]];
        [salt appendBytes:&k length:sizeof(k)];
    }
    
    return salt;
}

+ (Byte)hexToByte:(NSString *)p_hexString {
    int l_firstDigit    =   [self toDigit:[p_hexString characterAtIndex:0]];
    int l_secondDigit   =   [self toDigit:[p_hexString characterAtIndex:1]];
    return (Byte)((l_firstDigit << 4) + l_secondDigit);
}

+ (int)toDigit:(char)s {
    return (s<='9')?(s-'0'):(s<='F')?((s-'A')+10):((s-'a')+10);
}


@end
