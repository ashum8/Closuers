//
//  ReachabilityManager.h
//  Rating
//
//  Created by amit.swami on 17/07/14.
//  Copyright (c) 2014 Nucleus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Reachability.h"

@interface ReachabilityManager : NSObject

@property(nonatomic, strong) Reachability* reachability;

#pragma mark -
#pragma mark -Shared Manager
+ (ReachabilityManager*) sharedManager;


#pragma mark - 
#pragma mark - Class Methods
+ (BOOL) isReachable;
+ (BOOL) isUnReachable;
+ (BOOL) isReachableViaWWAN;
+ (BOOL) isReachableViaWiFi;


@end
