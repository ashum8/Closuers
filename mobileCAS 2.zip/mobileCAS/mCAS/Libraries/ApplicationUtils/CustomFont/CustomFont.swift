//
//  CustomFont.swift
//  Nuco
//
//  Created by Mac on 10/12/19.
//  Copyright © 2019 Nucleus Software Exports Ltd. All rights reserved.
//

import Foundation

@objc class CustomFont: NSObject {
    private static var instance: CustomFont?
    
    @objc static func shared() -> CustomFont{
        if instance == nil {
            instance = CustomFont()
        }
        return instance!
    }
    
    func GETFONTSIZE(fontSize: CGFloat) -> CGFloat {
        
        switch UIScreen.main.bounds.size.height {
        case 480:
            return fontSize-4 //iPhone 3.5-inch iPhone 4, iPhone 4S
            
        case 568:
            return fontSize-3 //iPhone 4-inch iPhone 5, iPhone 5S, iPhone 5C, iPhone SE
            
        case 667:
            return fontSize-3 //iPhone 4.7-inch iPhone 6, iPhone 6S, iPhone 7, iPhone 8
            
        case 736:
            return fontSize-2 //iPhone 5.5-inch (Physical) iPhone 6 Plus, iPhone 6S Plus, iPhone 7 Plus, iPhone 8 Plus
            
        case 812:
            return fontSize-2 //iPhone 5.8-inch iPhone X, iPhone XS, iPhone 11 Pro
            
        case 896:
            return fontSize-2 //iPhone 6.1-inch iPhone XR, iPhone 11
            
        case 1080:
            return fontSize //iPad 10.2-inch iPad 10.2
            
        case 1112:
            return fontSize //iPad 10.5-inch iPad Pro 10.5, iPad Air 10.5
            
        case 1024:
            return fontSize //iPad 9.7-inch Retina iPad 3, iPad 4, iPad Air, iPad Air 2, iPad Pro 9.7-inch, iPad 5th, iPad 6th
            
        case 1366:
            return fontSize+2 //iPad Pro 12.9-inch iPad Pro 12.9-inch 1st, 2nd and 3rd Generation
            
        default:
            return fontSize
        }
    }
    
    @objc func GETFONT_EXTRA_BOLD_ITALIC(_ sizeOfFont: CGFloat) -> UIFont {
        return UIFont(name: "OpenSans-ExtraboldItalic", size: GETFONTSIZE(fontSize: sizeOfFont))!
    }
    
    @objc func GETFONT_CONDENSED_BOLD(_ sizeOfFont: CGFloat) -> UIFont {
        return UIFont(name: "OpenSans-ExtraBold", size: GETFONTSIZE(fontSize: sizeOfFont))!
    }
    
    @objc func GETFONT_LIGHT(_ sizeOfFont: CGFloat) -> UIFont {
        return UIFont(name: "OpenSans-Light", size: GETFONTSIZE(fontSize: sizeOfFont))!
    }
    
    @objc func GETFONT_MEDIUM(_ sizeOfFont: CGFloat) -> UIFont {
        return UIFont(name: "OpenSans-Semibold", size: GETFONTSIZE(fontSize: sizeOfFont))!
    }
    
    @objc func GETFONT_REGULAR(_ sizeOfFont: CGFloat) -> UIFont {
        return UIFont(name: "OpenSans", size: GETFONTSIZE(fontSize: sizeOfFont))!
    }
    
    @objc func GETFONT_BOLD(_ sizeOfFont: CGFloat) -> UIFont {
        return UIFont(name: "OpenSans-Bold", size: GETFONTSIZE(fontSize: sizeOfFont))!
    }
    
    @objc func GETFONT_LIGHT_ITALIC(_ sizeOfFont: CGFloat) -> UIFont {
        return UIFont(name: "OpenSansLight-Italic", size: GETFONTSIZE(fontSize: sizeOfFont))!
    }
    
    @objc func GETFONT_MEDIUM_ITALIC(_ sizeOfFont: CGFloat) -> UIFont {
        return UIFont(name: "OpenSans-SemiboldItalic", size: GETFONTSIZE(fontSize: sizeOfFont))!
    }
    
    @objc func GETFONT_BOLD_ITALIC(_ sizeOfFont: CGFloat) -> UIFont {
        return UIFont(name: "OpenSans-BoldItalic", size: GETFONTSIZE(fontSize: sizeOfFont))!
    }
    
    @objc func GETFONT_ITALIC(_ sizeOfFont: CGFloat) -> UIFont {
        return UIFont(name: "OpenSans-Italic", size: GETFONTSIZE(fontSize: sizeOfFont))!
    }

}


