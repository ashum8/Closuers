//
//  JBroken.h
//
//  Created by Sathish Venkatisan on 12/10/13.
//

@interface JBroken : NSObject

+ (float)firmwareVersion;
+ (BOOL)isDeviceCompromised;
+ (BOOL)isAppCracked;
+ (BOOL)isAppStoreVersion;
+ (BOOL)isAppBroken;

@end
